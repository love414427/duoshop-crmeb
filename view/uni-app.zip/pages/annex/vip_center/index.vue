<template>
  <!-- svip会员模块 -->
	<view class="card_content">
		<view class="card-section">
			<view class="header-card">
				<view class="header-avatar acea-row">
					<view class="acea-row row-middle">
						<view class="avatar-box on">
							<image class="image" :src="userInfo.avatar ? userInfo.avatar : '/static/images/f.png'"></image>
							<view class="headwear">
								<image src="/static/images/crown.png"></image>
							</view>
						</view>
						<view class="text acea-row">
							<view class="name">{{userInfo.nickname || ''}}</view>
							<image class="vip" src="../../../static/images/svip.png"></image>
						</view>
					</view>
					<view v-if="userInfo.is_svip == 3" class="expire">终身会员</view>
					<view v-else class="expire">{{userInfo.svip_endtime | dateFormat}}到期</view>
				</view>
				<view class="header_count">
					<view class="acea-row row-between vip_save">
						<view class="save_money">
							<text class="name">累计节省(元)</text>
							<view class="money">{{userInfo.svip_save_money}}</view>
						</view>
						<view v-if="userInfo.is_svip != 3" @click="scrollToCard" class="renew_btn">立即续费</view>
					</view>
					<view class="save_list acea-row">
						<scroll-view scroll-x="true" style="white-space: nowrap; display: flex" show-scrollbar="false">
							<view v-for="(item,index) in memberRights" :key="index" class='item' @click="goUrl(item.link)">
								<image class="pic" :src="item.on_pic"></image>
								<view class="text">
									<view class="name">{{item.name}}</view>
									<view class="info">{{item.info}}</view>
								</view>
							</view>
						</scroll-view>
					</view>
				</view>
			</view>
		</view>
		<!--卡片下方内容-->
		<view class="vip_center">
			<view v-if="memberCoupons.length > 0" class="coupon-section">
				<view class="section-hd">
					<view class="title">会员优惠券</view>
					<text class="desc">会员专享优惠券，全场通用</text>
				</view>
				<scroll-view class="section-bd" scroll-x="true">
					<view v-for="item in memberCoupons" :key="item.coupon_id" class="item"
						:class="{gray: item.svipIssue}">
						<view class="acea-row row-column row-between row-middle">
							<view class="money">
								<text>￥</text>
								<text class="num">{{item.coupon_price}}</text>
							</view>
							<view class="text">
								<view class="name">{{item.coupon_title}}</view>
								<view v-if="item.use_min_price === '0.00'" class="mark">无门槛券</view>
								<view v-else class="mark">满{{item.use_min_price | moneyFormat}}可用</view>
							</view>
						</view>
						<navigator hover-class="none" :url="'/pages/columnGoods/goods_coupon_list/index?coupon_id='+item.coupon_id" v-if="item.svipIssue" class="coupon-btn">去使用</navigator>
						<view v-else @click="receiveCoupon(item)" class="coupon-btn">立即领取</view>
					</view>
				</scroll-view>
			</view>
			<!--立即续费-->
			<view v-if="userInfo.is_svip != 3" class="type-section" id="card" :style="{ 'background-image':`url(../static/renew_bg.png)`}">
				<view class="section-hd">
					<view class="title">会员续费</view>
					<text class="desc">续费可继续享受优惠价</text>
				</view>
				<scroll-view class="scroll" scroll-x="true">
					<view v-for="(item,index) in memberType" :key="item.group_data_id" class="item" :class="{on: index === type}"
						@click="checkType(item,index)">
						<view class="title line1">{{item.value && item.value.svip_name}}</view>
						<view class="new">￥<text class="num">{{item.value && item.value.price | moneyFormat}}</text></view>
						<view class="old">￥{{item.value && item.value.cost_price | moneyFormat}}</view>
					</view>
				</scroll-view>
				<view class="buy" @click="pay">立即支付</view>
				<view v-if="memberExplain" class="agree">
					<navigator class="link" url="/pages/annex/vip_clause/index" hover-class="none">购买即视为同意<text
						class="mark">《会员用户协议》</text></navigator>
				</view>	
			</view>
			<view v-if="goodsList.length" class="goods-section">
				<view class="section-hd">
					<view class="title">会员专享价</view>
				</view>
				<view class="section-bd acea-row">
					<view v-for="item in goodsList" :key="item.product_id" class="item" @click="goDetail(item.product_id)">
			      <easy-loadimage class="image" mode="widthFix" :image-src="item.image"></easy-loadimage>
						<view class="name line2">
							<text v-if="item.merchant.type_name && item.product_type == 0" class="font-bg-red bt-color">{{item.merchant.type_name}}</text>
							{{item.store_name}}
						</view>
						<view class="svip-price">￥{{item.svip_price}}
							<image src="../../../static/images/svip.png"></image>
						</view>
						<view class="shop-price">商城价：￥{{item.price}}</view>
					</view>
				</view>
			</view>
		</view>
		<payment :payMode="payMode" :pay_close="pay_close" :is-call="true" @onChangeFun="onChangeFun"
			:order_id="pay_order_id" :totalPrice="totalPrice"></payment>
		<authorize @onLoadFun="onLoadFun" :isAuto="isAuto" :isShowAuth="isShowAuth" @authColse="authColse"></authorize>
		<view v-show="false" v-html="formContent"></view>
	</view>
</template>

<script>
  import easyLoadimage from '@/components/easy-loadimage/easy-loadimage.vue';
	import payment from '@/components/payment';
	import authorize from '@/components/Authorize';
	import {
		mapGetters
	} from "vuex";
	import {
		memberCard,
		memberEquity,
		memberCouponLst,
		memberCardDraw,
		memberCardCreate,
		groomList,
		getAgreementApi,
		receiveMemberCoupon
	} from '@/api/user.js';
	import {
		toLogin
	} from '@/libs/login.js';
	import {
		openPaySubscribe
	} from '@/utils/SubscribeMessage.js';
	import dayjs from '@/plugin/dayjs/dayjs.min.js';
	export default {
		components: {
			payment,
			authorize,
      easyLoadimage
		},
		filters: {
			dateFormat: function(value) {
				return dayjs(value).format('YYYY-MM-DD');
			},
			moneyFormat: function(value) {
				return parseFloat(value);
			}
		},
		data() {
			return {
				memberType: [],
				userInfo: {},
				memberRights: [],
				memberExplain: [],
				memberCoupons: [],
				isGetFree: null,
				popupShow: false,
				account: '',
				password: '',
				goodsList: [],
				pay_order_id: '',
				payMode: [{
					name: '微信支付',
					icon: 'icon-weixinzhifu',
					// #ifdef H5
					value: this.$wechat.isWeixin() ? 'weixin' : 'h5',
					// #endif
					// #ifdef MP
					value: 'routine',
					// #endif
					// #ifdef APP-PLUS
					value: 'weixin',
					// #endif
					title: '微信快捷支付',
					payStatus: true
					}
					// #ifdef H5 ||APP-PLUS
					,
					{
					name: '支付宝支付',
					icon: 'icon-zhifubao',
					// #ifdef H5 || APP-PLUS
					value: 'alipay',
					// #endif
					// #ifdef MP
					value: 'alipayQr',
					// #endif
					title: '支付宝支付',
					payStatus: true
					}
					// #endif
				],
				pay_close: false,
				totalPrice: '0',
				formContent: '',
				page: 1,
				limit: 15,
				finished: false,
				loading: false,
				memberEndTime: '',
				// #ifdef H5
				isWeixin: this.$wechat.isWeixin(),
				// #endif
				type: 0,
				svip_type: 1,
				svip: null,
				svipDef: {},
				isAuto: false, //没有授权的不会自动授权
				isShowAuth: false, //是否隐藏授权
			}
		},
		watch: {
			
		},
		computed: mapGetters(['isLogin']),
		onLoad() {
			this.getCouponLst();
			if (this.isLogin) {
				this.getMemberCard();
				this.memberEquity();
				this.groomList();
			} else {
				this.isAuto = true;
				this.isShowAuth = true
			}
		},
		onShow(){
			
		},
		onReachBottom() {
			this.groomList();
		},
		methods: {
			onLunch() {
				this.getMemberCard();
				this.memberEquity();
				this.getCouponLst();
			},
			onLoadFun() {
				this.isShowAuth = false;
				this.getMemberCard();
				this.memberEquity();
			},
			// 授权关闭
			authColse: function(e) {
				this.isShowAuth = e
			},
			goUrl(url){
				if(url.indexOf("http") != -1){
					// #ifdef H5
					location.href = url
					// #endif
				}else{
					if(['/pages/goods_cate/goods_cate','/pages/order_addcart/order_addcart','/pages/user/index','/pages/plant_grass/index'].indexOf(url) == -1){
						uni.navigateTo({
							url:url
						})	
					}else{
						uni.switchTab({
							url:url
						})
					}
				}
			},
			// 付费会员数据
			getMemberCard() {
				uni.showLoading({
					title: '正在加载…'
				});
				memberCard().then(res => {
					uni.hideLoading();
					this.memberType = res.data.list;
					this.svipDef = res.data.def;
					this.totalPrice = res.data.def.price.toString();
					this.pay_order_id = res.data.def.group_data_id.toString();
					this.svip_type = res.data.def.svip_type;
				}).catch(err => {
					uni.showToast({
						title: err,
						icon: 'none'
					});
				});
			},
			// 付费会员权益
			memberEquity() {
				memberEquity().then(res => {
					this.memberRights = res.data.interests;
					this.userInfo = res.data.user;
				}).catch(err => {
					uni.showToast({
						title: err,
						icon: 'none'
					});
				});
			},
			// 会员优惠券
			getCouponLst() {
				memberCouponLst().then(res => {
					this.memberCoupons = res.data
				}).catch(err => {
					uni.showToast({
						title: err,
						icon: 'none'
					});
				});
			},
			receiveCoupon(item) {
				let that = this;
				if (that.isLogin === false) {
					this.isAuto = true;
					this.isShowAuth = true
				} else {
					receiveMemberCoupon(item.coupon_id).then(res => {
						item.svipIssue = 1
						uni.showToast({
							title: res.message,
							icon: 'none'
						})
					}).catch(err => {
						uni.showToast({
							title: err,
							icon: 'none'
						})
					})
				}
			},
			pay() {
				if (this.totalPrice == 0) {
					this.createMemberCard('weixin');
				} else {
					this.pay_close = true;
				}
			},
			payClose: function() {
				this.pay_close = false;
			},
			// 立即购买
			createMemberCard(type) {
				uni.showLoading({
					title: '正在加载…'
				});
				let query = {
					pay_type: type,
					// #ifdef H5
					return_url: location.port ? location.protocol + '//' + location.hostname + ':' + location.port +
						'/pages/annex/vip_paid/index' : location.protocol + '//' + location.hostname +
						'/pages/annex/vip_paid/index'
					// #endif
				};
				let group_id = this.pay_order_id
				// #ifdef MP
				openPaySubscribe().then(() => {
					memberCardCreate(group_id,query).then(res => {
						if (parseFloat(this.totalPrice) > 0) {
							this.callPay(res);
						} else {
							uni.hideLoading();
							return this.$util.Tips({
								title: this.svip_type == 1 ? '成功开启0元试用' : '续费成功',
							}, () => {
								this.onLunch()
							});
						}
					}).catch(err => {
						uni.hideLoading();
						uni.showToast({
							title: err,
							icon: 'none'
						});
					});
				});
				// #endif
				// #ifndef MP
				memberCardCreate(group_id,query).then(res => {
					if (parseFloat(this.totalPrice) > 0) {
						this.callPay(res);
					} else {
						uni.hideLoading();
						return this.$util.Tips({
							title:  this.svip_type == 1 ? '成功开启0元试用' : '续费成功',
						}, () => {
							this.onLunch()
						});
					}
				}).catch(err => {
					uni.showToast({
						title: err,
						icon: 'none'
					});
				});
				// #endif
			},
			// 调用支付
			callPay(res) {
				let that = this;
				let status = res.data.status,
					orderId = res.data.result.order_id,
					callback_key = res.data.result.pay_key,
					jsConfig = res.data.result.config,
					goPages = '/pages/annx/vip_center/index'
				switch (status) {
					case 'ORDER_EXIST':
					case 'EXTEND_ORDER':
					case 'PAY_ERROR':
					case 'error':
						uni.hideLoading();
						that.payClose();
						return that.$util.Tips({
							title: res.message
						});
						break;
					case 'success':
						uni.hideLoading();
						that.payClose();
						return that.$util.Tips({
							title: res.message,
							icon: 'success'
						});
						break;
					case 'alipay':
					case "alipayQr":
						uni.hideLoading();
						that.payClose();
						uni.navigateTo({
							url: '/pages/order_pay_back/index?keyCode='+callback_key+'&url='+jsConfig+'&type=11',
						})	
						return;
						break;
						// #ifndef MP
					case "wechat":
					case "weixin":
					case "weixinApp":
						jsConfig.timeStamp = jsConfig.timestamp;
						// #ifndef APP-PLUS
						this.$wechat.pay(jsConfig).then(res => {
							uni.hideLoading();
							that.payClose();
							return that.$util.Tips({
								title: res.message,
								icon: 'success'
							});
						}).catch(res => {
							uni.hideLoading();
							if (res.errMsg == 'chooseWXPay:cancel') return that.$util.Tips({
								title: '取消支付'
							});
						})
						// #endif
						// #ifdef APP-PLUS
						let mp_pay_name=''
						if(uni.requestOrderPayment){
							mp_pay_name='requestOrderPayment'
						}else{
							mp_pay_name='requestPayment'
						}
						uni[mp_pay_name]({
							provider: 'wxpay',
							orderInfo: jsConfig,
							success: (e) => {
								uni.hideLoading();
								that.payClose();
								return that.$util.Tips({
									title: '支付成功',
									icon: 'success'
								});
							},
							fail: (e) => {
								uni.hideLoading();
								that.payClose();
								uni.showModal({
									content: "支付失败",
									showCancel: false,
									success: function(res) {}
								})
							},
							complete: () => {
								uni.hideLoading();
							},
						});
						// #endif
						break;
						// #endif
						// #ifdef MP
					case "routine":
						jsConfig.timeStamp = jsConfig.timestamp;
						let mp_pay_name=''
						if(uni.requestOrderPayment){
							mp_pay_name='requestOrderPayment'
						}else{
							mp_pay_name='requestPayment'
						}
						uni[mp_pay_name]({
							...jsConfig,
							success: function(res) {
								uni.hideLoading();
								that.payClose();
								return that.$util.Tips({
									title: '支付成功',
									icon: 'success'
								}, {
									tab: 5,
									url: goPages
								});
							},
							fail: function(e) {
								uni.hideLoading();
								that.payClose();
								return that.$util.Tips({
									title: '取消支付'
								});
							},
						})
						break;
						// #endif
					case "balance":
						uni.hideLoading();
						that.payClose();
						//余额不足
						return that.$util.Tips({
							title: res.msg
						}, {
							tab: 5,
							url: goPages
						});
						break;
						// #ifdef H5
					case 'h5':
						let host = window.location.protocol + "//" + window.location.host;
						let url = `${host}/pages/annex/vip_center/index`
						let eUrl = encodeURIComponent(url)
						let jsurl = jsConfig.mweb_url || jsConfig.h5_url
						let locations = `${jsurl}&redirect_url=${eUrl}`
						setTimeout(() => {
							location.href = locations;
						}, 100);
						break;
						// #endif
						// #ifdef APP-PLUS
					case 'alipayApp':
						uni.requestPayment({
							provider: 'alipay',
							orderInfo: jsConfig,
							success: (e) => {
								uni.hideLoading();
								that.payClose();
								return that.$util.Tips({
									title: '支付成功',
									icon: 'success'
								});
							},
							fail: (e) => {
								uni.hideLoading();
								uni.showModal({
									content: "支付失败",
									showCancel: false,
									success: function(res) {}
								})
							},
							complete: () => {
								uni.hideLoading();
							},
						});
						break;
						// #endif
				}
			},
			payCheck: function(type) {
				this.createMemberCard(type);
			},
			onChangeFun: function(e) {
				let opt = e;
				let action = opt.action || null;
				let value = opt.value != undefined ? opt.value : null;
				action && this[action] && this[action](value);
			},
			scrollToCard() {
				const query = uni.createSelectorQuery().in(this);
				query.select('#card').boundingClientRect(data => {
					uni.pageScrollTo({
						scrollTop: data.top
					});
				}).exec();
			},
			checkType(svip,index) {
				this.svipDef = svip.value;
				this.type = index;
				this.svip_type = svip.value.svip_type;
				this.pay_order_id = svip.group_data_id.toString();
				this.totalPrice = svip.value.price.toString();
			},
			goDetail(id) {
				uni.navigateTo({
					url: `/pages/goods_details/index?id=${id}`
				});
			},	
			groomList() {
				if (this.finished || this.loading) {
					return;
				}
				this.loading = true
				groomList({
					page: this.page,
					limit: this.limit
				}).then(res => {
					this.goodsList = this.goodsList.concat(res.data.list);
					this.finished = res.data.list.length < this.limit;
					this.loading = false;
					this.page += 1;
				}).catch(err => {
		
				});
			},
		},
		// 滚动监听
		onPageScroll(e) {
			// 传入scrollTop值并触发所有easy-loadimage组件下的滚动监听事件
			uni.$emit('scroll');
		}
	}
</script>
<style lang="scss" scoped>
	.card_content{
		background: #F5f5f5;
	}
	.card-section {
		height: 600rpx;
		background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAu4AAANPAgMAAAD4RLKmAAAACVBMVEUYFh8jIiovLjUkKlVWAAAgAElEQVR42uxaS3IjOw70UXvFCOI0syVWvWIE65STmSBLVZLsblsuv5kXaLlhWZ9SEkwACVBv2//vv99vCT7BJ/gEn+ATfIJP8Ak+wSf4BJ/gE3yCT/AJPsEn+ASf4BN8gk/wCT7BJ/gEn+ATfIJP8Ak+wSf4BJ/gE3yCT/AJPsEn+ASf4BN8gk/wCT7BJ/gEn+ATfIJP8Ak+wSf4BJ/gE3yCT/AJPsEn+ASf4BN8gk/wCT7BJ/gEn+ATfIJP8Ak+wSf4BJ/gE3yCT/AJPsEn+ASf4BN8gk/wCf5/G7z1H/r5M4Z/uefNbP6OXz8FrP8FCf7Nnjd79Mg/TvnJ+j+B98O9cX7g4n9/8UE+3gff8e/Avb5+/Yzr/8R87c074H2Mzzrix/djPANvTDB2z3nbCf+D//rHz92Bd+/+zpp9Lb0PbMzFdvn27t+ND+Mu21iQ/I7zDx7oP/HTHwn+6Pi+wJv72FeEP7b6DtnqoVZdZ7fT/fHkMe7C7zf4107p/DG34x3xkogFux6/nT/95rx+X6R897i5PeO8n+45dubiHzt+rN82/AhmFSly7Ez4R9f3ue648I/Spm+nemM7Q369cSljPj4eA/yOdqy03rdr7Tu55om26dgSi+T+ju9r50VtrZpx3i+1dsRe+zkU+76ofkiV48+1zeAWWxF0nf2oRI0dqCos689HhXOmmb4uaFf/RPS5n1fQH9MHaeN/kC7O6/RbCLnecJ19J9XtedDHI23eidTQliEOnLTpS+NcZ7e9yvbtSYGyv24DWcvGgYdju/rHjyHYP2D9x+CtrvJr9dbPVoX+dTYQ2qmFFgfWevrcnQ/Au/vDPWwq71/609/vIPxveliUWy8R9xbBLwdMoWnKPdfZYGt91Fl7m9Hj8WfgF8X5WmfJGIfSXZXNxsz6F9lb0RnPynydGeQBvIHdQXTby+pU+qGYuvyPonuVjSruwYBwdPHFiFPSf+ik9q6JPY2f9w3Cpu8+sMvsMZf7KTsuBeOmnHQAD57T3XxC/jfV1W4F/4PyXEox/WPKvMYGpwPt7a++CLOa6yNtQrQIsApRDwk07nXxVGZjq0r532/PynjcJcmbAN6qT/BWnJQg6diRSN555fZgib1OrT+o+vGY8Sn85nKvsDd5U/aFTG1wkwimWSVQLiFEwvRbzyFJ0/fOLyJA3tk8rn6FPQkAv9VYO6iVqVXC806Oi+J0a5eGBlC8kjzaX29BHWzE0KyhX2A9VhF57RC0NxA2WUDPo3yqHgzfdb5rhWN4lFSzuTUD5BuR9V0NzAX2mAqlSc5ltR9EJjw/dKfg5SVKq61ZgW+T7WMpeaVQ64MM6pLeY/teO+TVcJedKtOCXW+NBWgzutiPQuCuZpC8wn60YMrcmHiXlxZrYB6manP/XmtHKTmrzkkbhJMDzq83vl6rCuVLp+J5/oHCZttxWFmWtK/wEffED4Xku6yqv1CXcVbxq0CtRxyeV1IszIDaBDB9VmM7JQBxRVujcFbGHEij32rD870eEoydU9BY/MHr2QZG1gTOIkE6+FNVbg/aQH8q03AL/D6rfePApvvKJ327c1+gXxoFRcrIY/GePKhcQaztNDsbyrAWHCuswhULbLg/vs3ikn5D6Vvb11T3whS4Svz+Jc9LPVTygQtlyi/1vg+gw/mqHrn+YZT7+r/p+1Lm7z12p8YMwXnQ9eC8GFKiuCJJiTUPFy4ilTKad1ZxNy7WC/btOywvpeDT/tvOmnFqCoUexWaGLrINKxvTZMGaTZviz8bEhdfDq3xv7b1/G91tl3yrNK22hwUTruqHiQIeL9PzQ1qxzn3yp6fEWusIFo7WIJOtdfxRYfvWXrbkIzhfLFwSGdkXa3yfrvqcGxVhpbZxKPayNWbC+pTGuKgxl8IDLVJBFw1b373wmsXvvs7BUF9KEGWsZnx67pH1v98EAT4dmz+FTg+jXinKh9IsszEZT7rBB+MbbOjfGqdiwaDAeauxFtJEffRkPVVlqYiUJaXvB8Tw+mSIVL81tisDn8CGU+76jluldC+H4GzRebTjCXCUqAPrwfn+7ohYaXEbk4EUwnz3aJT+bQsZhLeXV60a7BoJsWpINBAMz8rgFD94R/SwyC6tP3F6KUyPTGWOzIsMCg8hvBRI0/N4WLHzqmXnYF3OpBI/qJ265/t71jO3gzblHafPcwTtVOFbJZQqiytjW9JH1eFly/qODDaPxeKIrPa9Qh2nNl2DndGYteX5R+TN2U0hMMn0JvoMeoiwQUfudGdvq3a2bq9a0+hZ8drnAYD3nf52GvbNYRnf9eT7Nhr0sSYZK1d4HlnYexxNYznd5gm/ibX+suWsxUMVMHa1o6uJPng+Rmqq8kqND9/6oKsX3UcbbGpYB6AatoJsUzU+0NAMxYE0pUh71fJS87RoDoBDto4xvT/ljk9ixVim2H/eTgcJCHtWrFD+cd4jNRme19hpTr0tJENXlnvNMqfZaKEQ57Sv20ryUapapM/bgdrZ8/BlUUzT84wfrIKQi3R8WT6i7GeG143zM4bzS5a/idkDuwZLRackdYUpAPmOvmiZiMGywLuebo2yDGtocXjpDFOO+8qmvMaFmEw3vISex532mkUNd9xaBJwSeRFmP0xuwt1tP9LT47/epOMawrJyRV085MyPnq+Sx0bWIN2MmKxMz6vahffa9oqVHAtwxZQJseNSAR7eZ970W82a1GqObNMopOljuh8XghO4Ay3ORVFNEbYQHMCOu0w0rK34Q+6C9yp81l6x1KmNSlFpP9zd/XgaVcQkAtYS2vyCSofn6U/xu4QC63G20trgNIf5kT5HPuBdeh5mcACukazNgc/XbfM9D5ZoikqUUW5JuR0r31RArNAcRYqZUPyWBzZK9cIw4mwG7SA8j0tyj3FXnEfGYVJCKWscCHZ1MV+3Fp7XClqMFEWettgUzUl0QSU8H8nnl75vQ89Xn8+22bQUjuY1lS8632HrqmzDnzIPTSgz6YjmX7Z9KeAxz5C7snVnBmH7cDjQWCNfW3Mbg//4JqZ9cR6EIed1pm/cA2Amh6COC5UzN4OdCJ9qetcgF79sceFSVPRHJPt5DD62W14RV3xqZC6vBOcRz7gCN2yGRJkhPT3v4XnuJLaL4pIjxRbnjqbdjBr4VTtmzdkktZlg2lhDhOaHs7WxsuV6kyRx3NryfCmqUgxKpN9emBEKMzF3yCjnceHGXlaxULAv9OFXrfPz6uryT19AGCs6x97BqloBA4kFz0/s8XCPWqaw7RT6XXmf8YqmryvERmRk5v+i+SVLbfmq3een5LratMH+oivXxPHGOg7st1Ggxde0xHLeRpcHmHxbSEfAG5HNjZxnkuEIga5iK8KkjMaTOwIffs1Sk2mniVDZ2qPI1iPtq/w/fLW1ojkrLONQN8SiBtscpsLVKGr4i5DleUQAARc2tV3tq6YOrF+dQgHv/4rt82MVOWVO58l09s3S7kTpUZeUd9rYyxhPRrpuQyeWyCQSvEjwna0fHI5GUOKmq73Ey1GYK6w6QqR7r3wRn/60RSHBhtcYrs9cwU+bTPcpanikF0MlW1+EqHzV7zd+um7waJNL0UNtLKoA2SXlAY48ZO/ENRkbKXQyFUQbauKwPZ1Htp+0lTPewvZHitJUXjWaUFmRuNF3INw0xdnWCavqAsHPig/xI4/SFXRr4RbgERM3Kydu8Dy3mKofpGmdZybIQoUf5yZ/fs5yRAP2eo0+pAWxo/7Nw4HJlBGSIXRBtFwoCfA8Kz5Tujok9WbcBc1f8UiLGSvdRDqxs+VZFTei8ln6BG6igvu0xae2OALs0dlHm9eIss2DP47e8Qk2QgDYQs9Cg2zTuGRmE5G6Uq+wfvKkgj043E5dydzC53WgT1+x5ddAivvVeE74KQu6SzY1fmqNMz3+ako2okabHRRn9yAogWtNTNPMf/qCnEkBaBurThDYyAK6y/WAytE/uYHF8OilkebE3KXU9LXLwrD+jKW0oO5gtdCYo4rrnJfq4M7n7KAwUdKTrgI0v/fDPSjkfMEaAJdsYBaYFyWDGAaADcj8SK2Osc7IYsiBNxazde7N+JSl5OJgxbl1HkmGrm36+sYSyKGbuU9wXFtxEIHc9NVElxPYGTALcF5AccHY5WAFhOELSEmmCAIlzRQjtPr2NJaj6vAJW0W7wtFNFSEUaHBjTMlUvyzOp+o233Qb7pA3hSfghEU/umxhHg//69iC9NaMVYm9sSIQM1czaDlf5yS2fs7qBIoJiyyiOI6vQJCSeyGygMqjE75pSBlEEdbJvL4/70yLca2qGCX16Xn6WdsF6DVowkcqW1p+qNzIrFQ51Pycdb2vx40u1unSf6m5lt3IcR2aT+xNClCteiMC1tdkEwHSqjcRIH3l5TmHdlWlp2e6LzApj52SX7ItkYcPkXLwWlNGm24vhRfohO9Lc8BYDsZ7fvbHCywkEUzCQyE65bcOpQDtif7oNB4/ZY1tMG1KLPbCvf5n5VLilXxUWlrms1EY2zEDgkFd6MJuTAksZSulQ4PyppRWUN5gjnnUOju0yfC6R9bhBUHZb8cdZBjDyeUPSrEMz4KRijwmMpK9aLRtW6Qg6V0xb4rsDTuEtOUGI7Xh5bMHJUj5xfYSS3zqRGQFR4hvYtSPEOPedjhzzpLfp7z0EyVK0EfwQsENiECRuHLyChvbqSEG3bctKK8EIAYjm3BgD5QXwEdQHiGsTs/mgfI7ZP+I8oQIBAaUMT5nMZtWFp8mbxL+L37wC/B4vYlDWk4gwNQtUJ4p1S6l1WlOg/LaoHBy75An91r0Cv4NK/4J5TtVB4ZQ/lKluMBjziPpbPO4OTYwx0yvRuvJDegdzjEbcCbNdspTHIPyI+grmqMkpaTv936p4p9gXrcuekrGNxI2tiPfTY53QAhB4A6Un+SWmKQIr2CDoAkdl53Od5SnNAbNN7qROhenh/rw+5S/63Ej46Yojw1G+Bv9m77DHYgn5kE0aSjq/qaMD/z5JQyDBKJvUJ51QyzJFEBe/KNDA0ctnITfpTyesb9m2ylvQgV1N/1HBh0LR64dA+kN9rQzPdA1dcao699eYE1bUEIkCcofhmsdKhPkYbNxGuAPysOLwC3b35es32ao2YHsd6eqI2ymYEPnmISVe79x7AYh4UMK9GcT9H+8cGxkXRYMpFiaziDxJcGNzEHwoN9RHjk1iYK3CgNp9vXvSjK48BEECBQ4VR0NrC3hQikOTOYYyJx1BPNMtkeXGa6AAcZ3UoQTRpDukbGbVD1NuAbcMEOAuseNNw0VedUwCQEsMShihGX9je2X5UbOsdGb7saCCMwGysNUgWi2iP4ifQI8UVaCRf4okL11jmed8rSaQCXGFQhDjH6UQ3gtqgNvzfhXcAeszJCiZcLWr9Tyy9JkoPkKPgPzZzu32+JjqVow7DeMSQoHRROGReEJvF/fNjBs1zBBDuoWoZdN+pfwXUQmnEvjFcAEgx8iC9TyG6aIWYAZq+DsJn3wc8mRMEKThVQfQc2NTwBXF0dwLrCzRb6XUCrIGHTGiTBjo9M4TFpiSjSixAjFELGGdnSMqTXQMRhToz+Pq8qVAN28RgzyqcYITPBNQaTHsjXVx5OpY7jbYrhs1B2gPLjP3DzahNg80u806aAe3k77K1XfXdsA5wwYyrWm5rE4wxBBV9Phw0jnTJ6ZACyQDrFoPOmVJodjn8uN4TWjaqRhpY41+DlQQU5zqLjCLtE+YbgNU4VJHXSmKIB4LUPjQP5cnFdpRv+dbphR8wzqlya6odsifPiVMHoQghLEHwwKYZg4Nl7/ufQnXKE0MKhvVFri7JD/CkJymhUTHbszD8qPrhcT8VCXYAhnobhQYL4NRtVgLPUH6EnXg24Q505ai2ACFAMovUzGF0wzsGAwYAnhmFSH9yX90SbHis8Ch7dJzUFND/3DsNnic0V5P4Iyp0JC0rBT17RQlQb4L4cNe25dTn2hNqVmKeoMBFHjP+IK8ClpkFvUHJBUjqhITPDVa13vSlCdT6OG5+iLE0lomotpSLao4Bafz7xYUB6jCDF5k6h1ToLfOEloOGyQWwJ/B0WfbWwEOM0oeNFCsxPfigrT4FE+QEygnv45KsLw7CXyHk28BQGo2qVnOmnDV29QIQrewMVlhNvlAPkp5QnxyiHz0phsDa/Y9bzGQVB7VCzgL9UOQonUhLS3MVpinsfkKNEfkqAPxR/oLxstUZW9Hh+N6oUwlyc3pLQ2MYGRWuS5kLym60hJxUg2ca6qXsA7ZjhmxJZD//vLDKdNXq+o00XhISkIV5p6lCRnWqqF5xDdDuq3HvJQSF9JESQGBBcMrxi7gUatKbICd4u1SWgnNwgLI4XxGf0ijhbJbM0WbjK/DhsB0uhnGIfqNvSHY5KNJyFl3CfhYPgs1L5R3NAeljIcvEBHjsA1hfalOTZFBMISAOC0IrBNUPdFiZFN063YKDI88k38OBBJGkYPpOUrVQ5QuMkzozmVV0+aHSUvSghQ1+SmgOqWRwu/hyxoLXJOfAgZZfSTiF/KDbURyAwgyMWBDAzIARkik7OF14vADXnkvsMbMuCYbWacMadVR51r5KvWiO2t3jhq3O6042g8nC3KHPLZ+3YctZjT0ZxUxvcssjmmWTOxNd6hJ2n9/lJT3aqlkT98q9WPUsu+cm/o6Liyr5ZV5/FsrHf37vdbnM96C+9M8S7X237Nie3n3LZUp6yt5MTVfXG3pVZXtfXh1/HDdFxO9WSmdV+Hvgssc+0Ta/arcVz2Gjp/dzbWu3uP+/fzWu+eGB8KrburY58wVPa2od447mTQ9fuL1dQsd+8V93jk/c7VeJ5rO67EcTPUwHpX6279dLbt997esj9RT7LlV73EOQe0Yyi31fOK+/gWtKteOfPAcZQrZnGv/+7ywzGfT/A3WS4UDvbcW66lpjI+17NZr9Opjmr57b9J+f3LhXaGxQe5R8mJVq6C/IfNp4orwQDg8kqnofz4P6r+5XTcZyyfvvaaD//g4Bf/9OU0jf9dLoy7/3SD0Mcplnkr+5Ibtvj3uGAO3LDr4t7bGSn/z1wZQfm5nWGxyXawdBd4K40/bB4WdzxxenHv+5kpP/7hyo8XuShPXxfKS0GZfB9mtPt2fqpXDDVxpYz8n8P8o2/T8imW8qHy3ZeV3+vM2T7e67o8LiXD1SyVe28v1s+xrFsZuUqMAvWvRW4LkgoIlfBLb9fzGhA9ey0qMa+4wcVZ2b123/jw6X5ddH18OOV79u1FYabnr0slLRHC4YwiIy75sBZN/kVgytpJvEoEDGhBYzqtfpzw97hwIAXK4+LbWRqv+dcxC3sdHRCO7mqxf4VZKPt+Ft8m3BiVU6792rt0xx/+6eMWb/xZYBOUHwIH0YHY/M+UH+riBGxOQvj8ufGAzWz9EfSFlEdKpp8JNpuaLYwHLIzJkUfPmQmVs1GeEnqUahwiaOtzpSD+qTDfInM4d/Cs0C2PkB8H5seZtI0A049y2V8oeoS+0y4PJ4LNva5Ey4L6EoWjjlo+dsq30+jKMKEtVE0l9ssDaqaEuVWePyflaUVF/Xt1g4QJRXoqZXEeyt/7BxYWqiBMf2v6CiHefZ/zCCxbeujKtivzHqDfP+5CtejXiRwz0bzewpWifl5U6lrCQQi/JzCfnv/DiFqKZrdVK7B/G7PmMGCETRPma3r+LzcmbXdFv5ocGP/VvemuYiQO5M4U5dNZQD/JgoXiKl2ZVwjqGvn1ppQKR4H1TNrGFX0CZcGLslLyw+obyCpEGboxJYTscQXQT6Hnc33u717FE/pzhEL04vJ6MKdhmtPA58aFet4Rl5/9e1deCshvK+WWbL0ihuBi+coMOC57nWavi5R/dZ5YPoeF3fZRUigafOhMGXDKO2Oy3E5ZKnoN+ORGRio9He4ATmI0JmWUr23l1D9q7vOS4jpVenWnobrCye6iVWA+t6dHWRtxDw04qOhLxmdmVPTboFw0JrbxoTgrOVsqKJ/V7frEn+xkQtDsvfWP1t5r8RPTUp/1gokLqJj0Tw/8YGRaAGI+7YB62hLQGOzESruJrXaRh5za4SKgyrom1nVt40fgSXre6iIJK4shayLlneStZk5AGJjjAMUfWQWHegflP7wqLCyaT1xJMr5+y13gpErde0cc+Q4jyx18SEdCJKOh8BCu6JRbWEua6VHJgS/eQnnDu0EXAPJ9AkINr7fv/4gKiEmOf2/t1W92Q2v27YW3RZzbVVCw8Yu2IaryK6noM6OoGK067pMd/y1rtgvsQWUnG+Qjw5+nz0Dy+27lU1r9mm1NSS5lNQXfAaFFTgAakIFr/Lemi5EtuMs71crF73QjBSYFCeRYQ0S+Zuud4IQjdKPKW6zUmPInp5/n17uXmJjEdFv1apeCqVvfXt51L6eLJWHHO/g1W3gxEE/Nl6rEiUMdLYI/OVHBW7pr83wMuTgWkXtwI7vXytpNX7FN1HPwxOB3Qblnp++wS4qxVDSpoi4YAh4kjKiKI84FVmOZd45n3sE3ak0//re34dWkmIHWrF7fqe45ycbB876wQ98BDiXEg9IxaYHzRwPmMQEKGLw4fy6uCPwIMwj/7a2/UGC9hLLXWCr/j7az2XEbB4KwHzEXEqBOuZBA9DS5kAB92osHkJ5y66umnOwlmfHOTBLTkW2RrK6u/pGcwJaRo5bKOZeAPkN5nKWQ/NQDY3xTbjMcncv8caEQAe+rx7ESg5ARPPL+Zp4cHCWEnpdx9PgjSFF8jbBE7g/y2pE3FpvDcwqHioXp60ZNBfrZrDCr25lR7V1WEf5y4MfKOlmg3oSb5PPEVDsmciU18GrRMEgP8UJ9A6GvGUdHJiOj9cwkCIefKlXXj7Ry019yGUuPIFf84zZa3iGn6dw4kdmRoagrywkHoPD6srGGc/FMsOooJtj9NJDfi0oRfLHFa5Kg1QLRq3LYDPLaVtzEOkr4vkr0WWyFKLG+YnQmj2zXsQo5spbVqNw9vWhDy5Jg0FnceCZnVhytcQj5avUMqckBfeYmBsOfv2aEvACfW9C+hrWNZ/ht3qn1RnZEqPWZEuOUeAc24Qp4t8hTOWo7FpxAw0iVLxkjuDKpkxvR3tXgvU+53MZLXAHp58O58ryWPjt76eLaoc9t/9wMufMG+NV816sxyuEEXzGGOObqEtSwt7ADjUrXfkgNvQLW8WxVJvukA/Qbmg/ytc+s7SCfvfv+6qBh0jNZ5dNHTVOdx0vcey1M3LF4n9ujC9b2xgo2wbydj/uTL4k77WWapg/dWaKQr6tPW+vqnSE/5nyz6ufPH+s9kF6lhCd24hJNM5KXGhXt+RtfwicziY8yHz718wYMyQ2prm0Lh7ySe20S08702WMfSVMpoHQFf2ytJxg9TVGZAwexZjv0ri0uKSTgnvxK5BO174q/fXPHrN4L3u4WQo3OZa3xV8ySP3mMtnSu81efkpRHabICJ/aIWuoI6FW3WkMW5pGO7gXz/XNj15UIm719GYIjBBLBk/QoMn7e2EllSwkLU1qUkiB8Q+hGPeV6Je8+KitkDWklnjIcbiHH6XzRYQby6KbMaU62DSvMqE+0wx/DOrv5WxifMQZ126qfwgZbZUEWofuddfgaSTnG+u5HpvK2qXLhs02UIiAIeRAezoxKUo6atbVaesYNViCPrwzkzxh1yiT0sK1WpKlSklH8knxSaXpC9zabaC/JZtL7lcLJY3MCZzZyPiSQZSclXq2f6JWT+5fuhNtCXGpsAav9/xGHjZKvdtKD+uY5mZ6KOoJrvTuvvzs36NZ17NQRdVvsPAnQTbSB3P4FxNkN8xqFPWZiJ/VzkG8uPZitLuaPpD2xcKafLHGbvLi9AdlONHBE5eMQAh3MFqAqsUqnpHLl0k7xZjXMtg3IB59MnoXg66OpG2RcyLMZJTbd3/XyFQYF1+LWWYktBPI2HOn0SCH7cln5sZHXE8Nu8GuUNRPNCcySH/NC8NVRwKSrmQ42pa2LHU5kmMRtqId5cFgPH5e/uSMGIa6IRR6mEhfO60mJNQfgxeVlCER0S4xcNH1eHkklvYk4GYbva65K+4Whu2FAzojVz+gwmM0anmlCBXbEXvm8Oz5lBG04+7hEJgXpwtahSfWFkSX2EuAt5If42xdFq2O6r0SVfmDnfmbCAOSpkQaNKzuruG8nBV7IRxHfVp5gNJoBakE6T94Ngdby8XEEHiUO+GzV/aH1zS2BnEYYgKuU1U0z8sq5kM/Xv/YvXY2GApFrIc+HiXNumoXCuAlU/oP8WsNrY7sCRrB41OuFpUULeYo/uk9GbH8j3RpXg3si83ZyKCcEDiOfw1kqm1quARcTNuExhxTU//FHEbT42TpUon69fvdAXhmX/9b4+qiqbZFke1JdSUD2YnJITHmje/Bkojc1/ot8COi4pGe8OL4HeZIrvhSoR26jly4ez4w4u94K2fH7tQMh749nMoNuIxRQ8U+P0OijxssvvDYma0Yt8WCnaqnGZH65O57X9lBi0iXx5tBFdapYKl0TPpY2azq+x7cyCdiOzzMky7gE8hagvkybXhzz0/cjCSvk9JGBOBROWCVk8/Zw01USLziTuzR6o5JdN4wXCZCrXO5v324JcLWjRAUmUqVVsRcfNM+ClUKNBCW/Mg6fi1yMEk1TVVueF/htQ2u52sdB+lBP4ow7YTrWUqNOzErhFPMclXhPe3y/Ea26pbJJwIrDOZVOj4OwrDB5IrQkcPrgSAa2tLhjR1TXzyt6DVCzR5yB9odz2cPBwC0RqW0xp1B7JxQCmCR+mz9v2lpmQx2Q3UQxJUGGg6vZop/YdYV9HxpF2dDiXp3dEFBSd9MDfmsKC5EWKXGv9AgUTQlCeEMqpLi8OswD0Ghp2oAPSSWtA9pkzgD4gZLQp7qdUEMHaOHX9tJYHJs4segrQMhdVTFoByo0DHCHrNVh9VS1V8sOfCb6MLTFWRzlls6jk1zMo7UAACAASURBVHDiPRl5N4kNLaP5hBTAFGGlJ8anhiXILD42inY6yXDaS1+UVmSHo8h1TJcI6YTVumOJTGc+JEaT000Ojec8cs3MG+s+v9+0NtyBx0nmV6KPQAaBA9PDUuxDH9y44MMfHOnVZC9EmxE5qmOIVpDszuK7vK4TI/XqzsR10x+Vr52eUnHli5tWzgPySVzIx5DOD7cPQUDlWTPn6RWmMIefQF7iCFYqJbzg/WPhpHYceBgzGBSh34czWoQSzqe2PSDb/Y3sZRYj30jDtMYM8mKB6ho50P1I3292VDlGg4nk3NpCkm/MHjTlybTz0kqzKbDTu0dqIzeeC7II3MUg4bPgaHGmU9GpD9Md5ez5wbs0t6RQBgPTRN/H3dSOG5fzrQl5EjztBWR8Uq4OLcDZg59gF7kBrt0sfu8fs93NGWuH1b6IXS36xnGiHs6uWDUdP/1t0q6kr4mcCL4cvWwRyNyaQ3VJyuJ8xw8TVtELiGWCbTqlJTNb6gohUZ9OqJteeP+YHFKKQ5SjlpVAEZcFpTAp8GJsTZnGgT7kQz6SmBh51OLEE05o36nuvR6jfrtlp9z6HIqi7dFDpHMvJwr3zjaBkNEsdLay9tnMvPeMNOcCQWqFFpdAGuymxWqpI58NYwvR/MOFypkD+ewGTVodt+SaN/6XO+1KyMsMcL6jlNqscUcWiMba8qgR0iFrB4ci9iUz7x1jNtAgKD5XpBN7dOyJA4AvJ7W0FHdxDty57MF5vd3IJ51IE8tzr/+UTEyY327eomDmxo/a4lo5bSp3gbTlhI8Uv6E3X7mQYMkK7xuNp+WKAOWbTnzRTiecKXSPk3L9lDYejUq5tR67X/iFvHvK19K5v1VM+HmrsTUtlNwMXBO7BXn5b+IFlNqmwTCd18X/9K5RWE+422A7z2hbclI91/K7T4r8uHXGZ/bKErbJo5HXjFoD8/5WDTaO/kK+0FEocWk3m5w4sbeMUrM9t9DjfrDkpnr+64imgGAy23EpSUdc4mu4rc0Zl795B53L7Ctmj9EW8vIJla6/lVQQwBcqft5MLgI4+2OjYABNE/JpskmKkaMAaSELGGbhn0fQC+QNIr8VTHCFxNmzLZuyZzHkacc+SbFqIa+DItf1P7J35L4jYQnkCcD07cF2jmiiWyDCHBNk9OaZbKK4awRkfbVz/m2cvrUAzmc3ogFcfOm2KS7BrJqDu26D9CpHSLyOvJCno3k++aKDiF6cS8WIpBQpmahpCuRTsdoYFZwBHJudI35mQKfH9pcxzkggRdVtC5afgd+n8az4s1ht0ucHHyE1DuRTfvJF7LE5u96OfX7efJ0H5dKpjAY/EIcSpRiZsHV+3k2tZaxrTPKLP48mPqngtCmxBcuvwM81GjMfXJqTT9834UT5dPKWf2vZ4C7R3i/gIOmlDLyQn4HGQn6ygcHTvExczeO03vQB5F3E2ZQX8p7LNVD4VQ4FmnzgcImyHQT+50VMNtzRqpAwLjOkIqnkcgNhQAsl6XCXnkmGswZyvnBbsoq4nsSbbCI2/sfRjXecrneXx3QlL+T1Lmqr7vs59MCcSoHazna5gHDpC9sccRWCdjKWdKHQJZWVNUIOdpOmuYZ5KU4IrMNRg4JY0wftZzVgcOPPYyDAhUVq4+hyFCjghA8mUlGRACZfhufJgVJczewTlpEdZToMVn2deDgbEOdJoooDsKseGjjhWCtfqxY7T1FS3BY1ff3HPZ301xG7xtksiDr8L3vXslu5lQP9E/Nf3cCQAHuVDS8Qf0025wLezaYDdL5yVFU8D+nq2p48BmhA7rSPrSsdUXwUi6SSQJraHJjnfN8H50Ayj1d6XH6rIEW/14K6SBYwzjYPiisSM9SQ6vaBcDQ0y1E/IhUY/zJEqHl4QJCW4zwOsN5fqSm0sIN87JbaNBVQNzSRCPto88L0rb3i6u26rSCh6BifNPGBJB/mDuCMCNhggBkpqMTDXsZElUxW0KOJMEP27TPSV+xpH6xJTXXNw92wIWsRdoxo0UaNEhrDkZ+SGStRQr2lyTnIObw7BJzuy8vNWA+gPXPj+Y28Cr0d0AKD1VFI3HlXUimC55bcgM+cjT5dsVOihn1jXw++ZIQHaJ7SwxNRUiOzvLHE/7YBoiEVOZ/QNJZKXaU2xE1s7LcXck58q4SR0jzgs+FhSKaAbryrK4nD51HUkTW9u6bw0Vy3oPjkuYQJ4KaLmEHzjS2M301y4jcBK0H1ph2YHlmXGcrAZCCjO0FMamywbHfe7s52Pp6UAwk+n+H1HN4c7sb3RZ6tDDf0Idgd3jyfpaRpGoAVKlQxTp9n6Zu378iI+BR1s3FgxlQEQ6Bk35IEqljfcF6phIEsChpUv0LVbswLzA5ESwBIEJmQg5ng2O89XZ30wjiTtootN3k0AJqUTaA70GbT8a/N5KMIhaTYAHdkSZ6XAuuWbH2gW48Nb9Is8keTeyFb4Q1GAJCYvKNehM9vVJw4Hko/JytOQcMfpMVZRaIkFb9uyENb2ce+KV+YQYn+Rm/6gS4fqzGGRnCuxfyCHfjOCKoBBz3goytDMbypeZd7WU9MwAW0Qlm/cc4P3mtMbyS7ZytxXfFEa6ar6khatnXNm/iJl+Zvv8Jb8Af5sd3Im51Nzm7CoAX5LnFDxhLtJZXHyJ+YRujFjUV0GvsKcGNAHlQA7cGjzldGNTCMMHNXmYp2GbEgNJ9BjYzoC7aJkPftlZoHSmInuBCzhUv33Mj5BMR5wDl9HgNlTGghevOqJdJvIjps5d6kwltVFvBtFh4nq0C94JmXhSxx4z7kuzcqB0mDimcj/9V65f2GTg1jDnma/VRGJRLqdu1/XoJOUdZQOeNUH1oI1JKpAUMfaBhY4DNCBWe1TYnwZGXyxPnZFDONsyNqUM7Iz5yMLImjJAbouUBdBEkO4Ku6JnqHPI//00MQAjTr4ResedDegosF8edGeoMOIbQEPwCASqAb78ERP3tUh/UGfl40isZFtwkakz/dCKWcCqAdIyQCLH77XsFHRpCCIvasU4GfNcin5vnAJCFVwlqzHq0yaBWkrIeC6S14lcsy0srDqsu4OfWv3BcVqKV5NSyy9seP99+jgq+wQc3TkEjboeLK5DYcXSBHg2MgGXMoY2gikISglQAYxasWCFRhMNMHWMZNw1p7WDm6g6KQodhrdFJXqo+NAZIZjgadSQwusn30g2Mk8EXmGthGkI8Yz8Hyt4C9KzCpMZeflfqpr1G5ppTTVPqHCQrv9aFIxn7N+qjvBuMS61rZWfElFOFvcpH8nv12pIZNDIJY6oPlk8+bCCwnrSQt0C58rrkrsKBAtC1rZgX/c8IEn5fzc7TRjyvBC2Yn8nIe6Gwagt8weCqwQ/NVBixQ3V/J30iCGCeAKbSDq6AFy2/gOuQ2WdrAQ8gGboWgHHBaqc0qw7BlaakqsVRrD6v2Yt3bhKoCgWZF+u6KAJ9XNWq8/cCPhFt8j7rWZlUoyozWR1NM4Bvk57Rb6ImDevI7n/DO7HmHX9EsaliwNr2HH1aFGuAeYFi7G2slka6gNxvfSMW2RCcK9gpP4Mt6KgbwlN9GKQ5v4oRoC1iJUVhzj8KbsM5myijwRWMvX23kJLkF2cgCCduvxBq6ae9wNqnATH2EpllwEeYmWzE3vpbtGCCEpNfeLyuLy/ZbGcgCKrrPlHeqS+cEDHyLnqWgyaApSUgYEnyJgP67rHcGCf6yp+3KrxxdGk9y6QStArb0csStf2epTF7qo+t0k0pYtkPCiF9eyNysJ0ZVJoyTCK+eDvwQkbXVROJp4kzJg/RhdXFjXRkdlIYqlE+38n89u2IYuwIo6VnIrfHtu1TOLV6nvzDfSYHwsLb5fKX94NaEXsVJSUU6mt6dR8y7N/7kQ9REENPGytqbl7s4OEbwpnarZmZVI3vfrRIjEP4Ptdu3Q/2VFWL1Pa33AOk6v73crUbzrE4EvKGGQ4pGChP10hADKDLrxR8EdFQOofnGSlduikDvfARIUEUnhySqQAAJJJT3ckf7A8WCuh8C9S4D368gH4K7fXnpD66srRmYNtU8hh7pFWpWRNAevjhKXVfqhNtYn43RUasDxwBwcY0exqbmUMbrBpbxOj2dt+dg1Mdl28mb8ExK7PAh5TvZF+m77EikTaWyChW6PF+OxJssoA5eXeO5CsBDxYwqbsuey5mElNLvvBdzI09Wk2T8e9M2cnkswUU3MHCb+vL+bahYOEfsGaMBXxJRHpITXllfVj5obSgaxgRXB8XOcrn3IBrb95FJTfzAiu4rQ2ra44bXcUPRw6KL9iHiCQmyjClOaBypBskmWTjee2TKDzHTuZoKbDR8SCFYXXqBLFMdvRdeWTGXqv1ggTfXEIQWJvFXgLRSZqmzo431oUupS1DfdU4YmcBcvLaiu3sgs8FcfVGaVT9uMDypWkadCo9hxTKIL0t6l002tek2BLQgfBfExsh8NYoiZ+jBTYLpfYbXRMw7QdeqTGJ84ae7uombs5lhPe36Eg+MMuWJUAWvs3jOfZJ+PgcyLClj52PQTJMROms0QbL8T32G7LYq2/QuwbpmWbR3uLLaBNWiKeI3nJ4ZhnliqpjMyCct93KElBdt3CYm3UbKjKFYFKExI6lFr7Ka6p9QN0OXt5C+5ooNnNso502eVHM/DfqEopWUa/SiMrlfpTpP/wJJ66UXtpXbpCK4g8wCE1b/zWP5t0+w6cBTDZ/uzrtVFvJe6GRhQA4n7yTKspcxvFXWJC10jentMp0zIpJu013SKsFGKUm5pu0IXmlUjjw4jBoM/Giu3t1TS7XGow41Eb1mo2QWnsfye3lDcZelHhvm4EDNfMC5lxm8B4WPmO/NlKwISeklF2xa1owaH9c/A1O8N4wVYHppb4JZ5a4SZjSH6hcfO0IauE1rPW+1qenFu+Rgu4RkI9X1i9p6cHyLcSxsVAfjVt3IdTz6maJ7rWCnDCoxoo/gmxWfL6EKa7oNClDSprpKHROcUrRfp0hHfRXjXXC8ebgtp/Z3BSp1WHZUyU7FrXor6T7CcW7r9stL3zzCjoQretUzoWH0V2I9K9R7liP3dc0IMc49/hQjDla3fvx5f0RJCT4v9ZU36SHvVZP4gkV1aDgeK9RiDg81uHdjFmd3t2HJ1MuzRd8qYbMl0VOJfLpalllRUQVeB6dNgEnMDo/nh1R9/uXrD+tfO5jnkxs1e1fxQ0U6Tz5fj1VFalfakmBlKVVM+kGHWqxkaK6FJN1PqwLLidFD3PVXt1IwTSIR7hVc8xGz38pmMWL++Ky5KKAdVdXmORNwBvCEz7w/SHG5WPTSQzf1Jzc4Ubnbmm/IKmdIysGUVjX7qv5RtrpdDAxyP7aaMsc6Dkf/tcXAbLE5vdg+M7IPUun9psp+/JRtk4Guamid+fzxcXNCcUvbx0Krjs9jw+wBksbqZ4rOx+pm+dn396wG0ZcXjT/Yzw9bQzWG9e/r9amSaLo2CauLTWexau+zKJuvrvS8GuZr5TTaIlXdHbDcV8Hd1vA6+Pzpow7+knuFjQR75p6+gsaZqvu8ZgnoI9xNXPGu670FxG1sYS8MObweI6K2Z0TRpWgqrva+4WsFFJ0C1DymHcV3HRzb+qx0SrjeKmrFsedJSsX0eT80MaZmqzXpHUKOCHwwUCzs6GkAFZU6nLcY0Ncos5VItvWeTcJXTn//K2JdxgQnamBkhz5rh4XOl3c4HHsPW1JdGTvczlB7H/VEm5gMw07z7RJ2de5ZyyJ2jGi9Y9hCaPKgklgRZMnPKhmKxfQs5qOGG25zAle9Nf0kXTw5+PCxH7e1NTw/QUDyRPHjC5OR5UTyr1ZdHctz2I09h5kDwP7+XqXRnPBEjhd72M+c1VKR+VajAt+LvObgtkebRYp8VGAemNdBuXk4+oFG/bOWe+fa6bIfZ9ijH59y0IhTHuiPB/cp6hG6Ytd7jJWjPgT5J4U/yON/Vnt/z5cPn7dliPEMnNoBkQ/Epz2teE6i9cPY3JW6e423OATsJxW4kiY/VbvbnmbkU5x+tu/HD7a/7YPb7FJJmD0pLx/cOz4TN/Hk5PaJXR4Z6v/u83/KO/1clfkhJr0fWTvh27LEucO/e/BzFjjfIuwzSn9H+BO28TnH/dBTnyky/5JJ/2G3+We/LuEv4S/hL+Ev4S/hL+Ev4S/hL+Ev4S/hL+Ev4S/hL+Ev4S/hL+Ev4S/hL+Ev4S/hL+Ev4f8fwn/9Sf9A+H//pH++fv3ysj3Bv37KPz+/z/+XnTPMcVQHgnCQmP+2ZO5DJPv/swT3v8qrr9pk9wCTBEubGWIMZOLurq4uG3a3OR1fgM3Unu+9txl/lKppWs+3K2GnJJtNg296ndP9HGL6Izw/YXUdFXbbJiTLdpytucJOCvpTbCOqbLOh5tDv2a4iNZ3bRfWwzVamUwi9bQM2TtzZuOaEZ5AHTTHY5vrZDoww5h2DmV7IMZUqKqwyd7IXDleZTQ/tttlE2aGsPbqF2XH0Xqf6acKNSEcJ25DGk7me8W7dqwfim8nYhklgF8+3jWo7mT6IJQ8wvzGnmmvNZtPw2wHm+7aVPhduNPx8nDuYj/nITJ43yXSEWWtZKZBb7X2bZJPjtSPMd1x/tOH/KbbNCWu22Zogf/Qs5J9TbFu343MscQfhsIowwZY7gmY7kQe1bXlQ/SHo33+T55tGK4oMzx9n0bGO2rn9drR+kKGdOWyvmNKxRZLnvP3mEnVoL6tIlVMj9+KNgnLef8vCvcT8lr3Q2jQBl8ZE3mQl8t035n0dsqRIieW7xf3ZffTuGwgvYJwipcK6iTbLWZmH59tvh6fcYpetaxpoiba1embv3H0D4eiZjiRmAi4rIH5Zs91+614YFoBy3/E8tVZpi+f77TfejlqFlPLyPALBO3ffWOrbmDyxbnOgclS2ICLLnZtvRZPAnhHwWarSDr+I8v6eP8PzbNI2dnjW2Gfw/MGUCc8rYV+eFw3lGTyvmesZns++iTyV50WQ2Z4/7Pkz7gueNW4Q3nyTIvNC69F8E7lW7UCbh3duvnmQTTSvaas9v0nYUKJUecvpJZz7tswCS49J1bk/lLibF+upXjplzXPXVmNnne+ojSrLQivxUDJIV/Z8tMzCyF1bUSIZK2KEbZIm4J6M661yU7/75vJNW4XAgxTGYRsWneR02VbVVatOu21b4fUioIgb83ns8jyzWszLfpzCRt6zPVDz+P3QxEnjx/MyBcs2wFTA1l1bJnwMUimqIZ9FbKOqmzGvj6cptuOubfdKmTrYocyV5wUfeb6oyRXs+/eWbSMADHKI+GAbkacfd+J949Gncsu2A3vviDnF8Ny+z5p743qsK5KchaWFfMP26PY87xp+Ec8XtAJ3GHy/pNGVhGg+crNW06dDQmarBzXLnvcaTj1sIHcIi1O63LCVnJTfWaRhsRXMF9lUwusGF3sF6Xa7liqlnbyJJVm5MeYlGY6BrbiRfygzsHS7Wds9sJg0cVietx0ecIP/NT3PMrIDqnu1ArpCIAUs/+tAl+dRyMywiApFVnHRebiJm1RUrpu0BWkg8LM8RgSaPW87uK2merWBnVZY0pQpwlm/RVuYPBV7XocqMbDncbNvbhbfD8x4PjP8Xvmo0uUObSzzCR+9xFoxC2fp0VSduJepgypQSgBdolOqxJhyKIG/3RZ7HgGj0TFYPE+18rMHJiFbIMEjCgI35p1G/rZvt8BA+xmaaTwnQWaWE8wDJjhSXhewsHPDEvQPQWHq9dWWoQcwMm7mQDuMf+awYAnO9xr3AeMfqEzm6/wNXfrVths2o/Dn5nX47Ae1NJOyzg/PW/jUk+A0A4mY4YFvtd7L4W9nr/wrdDTcLucjia2SfVnlcnke+DhfG0z1vVYujdEBgiAQ2gxIdHh/bCx58OwE96scAVdf4a2G1Kn9a618r7krAGLE7osN69n8fA2e5+6mzpCh2i8I+4Lru7vufK9VBGDFnF2YDvgyUlFFVJ4H6igbSAiLSAXtw59CHrx/fqlFqEtQSsHHY1nNM5HDJEhcmIzIOMMKO1ve8pitVBcCDFyHoR9uC1BmZp1T+B/uPEu2urcg2HkoVAXJYphs4E0KIvtCTVrEm2TNR1tc65tOGtkBEHIUWGXsU7uIemRmTg8Z9ZPtfs9XGHVoS+H+SanIJtlPtjwCZIrJP2WQjSC9EYbiDCU9CwkrVB3NhQkFoZ61mYMmU6tnuLl+qm2eZzAWR0Bu9MRbJ5yqTtYQmDqLtslcAaguvsnZwKE0gMHN+rN/pDU8sACGyW04O9cxlGZtz/17LkDbMGAUZQmCyS0yhVS5BE6NjH5720x41UWyNePHKr2M4GRIPC5ueL74OQRwEjqzj+pqUc8PNa4MYfrulu8n5AB2iDP52mvYTFJJgDYkjt7SwxWYHPd6KzbXeB0GETshjbL/6nvbUYUc+u7AF5zpOhX1iQrLgEhShFkNLZD9V1xju2e0JLbJ1muYBO/tLbogj5Hw1aCEKIQ2AwRP56A/wIMTxhEBU1mrrrHgSWd/jHoC5ZpGvry7DT8VD9VDbNRSDzfGiUlQkqnfRcoAF8AwK+coqxGqGuTkJIgZ5XvbmNCZZHLkYCSyV4ir1w4GLRY/OJHzZS4q9GCGCLh+WM/pl0KIV0DrnW2JPa8T1JDDrpZmcI+xegpbjDNUZQuYuw78yAk/0FJuUWtdsUPpY8ab2z+k09aeQxRXHvMgb82h3fgKk/ZH5KozANZRMA6rzqBUmx9Iq8PImMW8px9f2YNsIpF9agyleORBIiX0vP9EiX/EY3EZSOO6zZkTBwaF9kGm43t/uR+QzxYIdZT78fUvh7r4xwQcr182XXir17z9ZXAJMjCaBptWM8Rv94cs+LPjALURoUiCYULZHy2iYGuj1kalHR6/rPLy1fDFYFaf/eX+FQgj9yL8CzajhPYWsLDn8x/Ij7JmQZGvz0eRixiMNIg7b+2VFr/TryPoIcZyHbngUfjNaesj/jA3kVkeRtlcpc3Q2QaEDJjt0tfW01bO/jEf/V6/X7R8hf9VdXxFJOufo6qww+vh9yHR8lhxGBSbX0bVV4TriwJ+sd/SELFDEZf+VxguJgpmeRaosvvBp3jLuV+PQbmJ2fvo+8B1Wb9+f7Pvp978lfHlr/Ya2uv7zT6dCvsTrl3xwlrZk6F+X+uVt3mN9icOjt2fX+yvfPszErCN/vXN62sYPz4+uvvc/0XMPvHrsc378hx20hfTwHlf/z22mRNWtWrWH8Fm2v/+rg9hNudLnp8ZNnN7ft7B73N7ft4KW/95/p/n/3l+Ns8zR5xxm93zT9mQnjlN1uY1vTy/tslaTwNZoWG5JM3SrsZKVQzk+VT/G9QzRdt4CCQpYxMLrfW5ACRtU7Sp5kUxWMU3+0NG9DQWMWdp17+K1JrjbYpWr2UwpQbPIQXDafBUTmDejds16NJHHoF9Ja+zAAqCQ1m3vWt/LCqDeRhoDe7XkWdeowxUJcbK9aneq+/l8dW+psIORNmYMDAqGBemaG/RBzlmnfVpo5SwS9rrGC+nd5/2FQvmjFN36Mu1yk32HQ1g42K1DmyZi4hSjjxYx6lb9A0RgF9MNk+xTQqpYIeneqEmBaiekRAOxrf7yVyDaxdGuoN5IrI/IxMEJi4wvnTwisZe9y/3PWgoJS+rrajPH7PN6mwIQL3qQYggXbiTGs8b9ENKsre664TdB8rTHmptXTGVzFhNrCPxv9m3XxkSpPkcNVUnHsAmWfQQjmVw0hLlOLmeydRljb/2nb5Q5BZLFmszzFjRNjImXZgyEQ3KjFA8I0LZ3Pqdvpk8ElYjDLPoim1IUDON+mlP7KRgnVHf7IEl1RAV2PrZvsIATta82PvJiEge1iMNpbPWRyS1GXbFcsetPiO7bbhCmj7bv7QBQMg5Tjp1d0tin2O8fQ3Jo0/g+LiXnkYEUr7C6OT/WL8G7peIiFBjkAg7noDXZSEy0CQACmujGvulT3O2xmfFROpy+EP93cMX/Rnbi4ywFUbL47H2gE3Q/HNwVST3mKYTqRUCSiMoXPGhPhiPDaC4+Kc/sDHnxGFoaN/ZmGMJZbxwBB9PHOUESZE+1mc0qrcPDUfVNTmDRYXel7bBFO0tOSjHdi4LKR6TLddkV7Xkv5pBVv1Uv47ww/5OXk8H14WMSI9n8PyzAm2FYX08oyYTCl64gAQYq5r4YcWcD/TRxYkMSFeh1ckUCJd7qbApiPNSNlimxNBvMs3L6oWaVZNT20lhXff+Pu9BegvjNhftNa6BBR+e/zmHGb3c7IEKbVZAEKy6S5Q6iBM/7DEJeG8fleJyQ+Y5KriZWlWT+Z4KS2HVKBWfHNJGoJfKx+y0kyJO2JSCQSN+DzlpeXMfgtQQ8LPG7QOhdkzqq5LyAds8iUldndv01j3ms6F20KW69GkrsPPy1PI/7WabJEeuQlGIYAHKHSkjcva/peEcVPa892Omqt0dbrdLlV/SBS4XlP7RsdnRKZxwsFmJBzTzYJB2knjphGuYCJ+Ca1nY8bu0LB/u7xX1cq+MZbr+wfHTvkqVtHXbZAJQSXvAg+OTUUX+IYD3HnP0oG3Q/zT8bSvcvddopq1NAjRd/KW5fm7cURmgWOgCcI7aR6f17HFwYiFEuRmJqYI8h+OVck1cUP69iHdzXrsba0bnqSvWT4x9+FJNLkAGeeNVmek8uKrCuiXVyvg76N9pcCiI8a77II8i8jEudduo+oFxWMT6PMiu5MeOu7ZM+38fN26DLvHeqVbT7ZQTprpb/mlnNNkq9EnEKRHl9N5WBiXjvabz8F1jNGO7AZZeJqgKGzadfPD/xBA0vMMuH9wOE7VzN8/XiApyk9oaMu2DiEtg8vZIjrDDA+9qsm8b34PxQd4i8CEU81Sy1NiEYsTS1QvbSLOsqvNuSC864R1kKwFIVjTIk45jL8e1DZY217eMyUbOik/MAJPoXpJfR8RJVEaKHeNxyFp8GAAAEopJREFUc+ovkX+2SmfqXXKCAEBSB/klPzH2DqzLxPLnY9jaAIyTl1QGBb/z6I6Iy5zVAcsa9fLJX22cPlZ5QtYF5fnAj8iXyB8z6J/UBg9u+i3jzktQ+qMNRP7YQV9vIBvF/hwql15h2E4YIUPgPseZxPt8IGI7yB/CBjfTDIRCX1Ljun8+xhKjIafAGOSPF3jawuVpmKliNpGZuHdqCEgm65fPZ50PcG4C1DSAjhmwzLZGgxr+eGwPD5KDJgb1/mvTRuZBptvAgW32bJKI/JqqfVMOOFSJmikG+Xa4OkQQ2MCrzS/cv+5vGKPobWRI4EUpt5EJIXwp3YTWEvn67fOBotzooxxSt9gdn48+mkM1gEFFb3j0VRoYuNafj00raRl1mKb5HmocOPWOaylCo+lOv8CJOXVf9hDWbEDEmoyNyL5QGxuN1+f3ZWvbDupnmvT2OvtdXx9TPz+Wzsdj++A26ysi5Q4aTU/ZlGpG12NKrNtePUXZpSSeFIIahUNs1dQ5e0R1X8NXeqEEhXfRTPnyuB8vertVCw/GS+GdRGuSf/fJ73zRxUipLW2WIPSDPjE4pKkPgt9KH+mrE1bflgoY6LXQ4jIlB8HO3Z4vjkmSffOd/LpGnzCzXhgaopiaWWbxccE27Qq2SPBrIZjOQrpcyu9r0t2aciGty5BBaRPCXyM5lNlLJL8yBg51MLRxxWiQy8S5x9MpXq+pdCWonn3hwWzkEzArBmPrVmOaIwji1p/NL/sJzdHQ9y0JBeDvEQUPeiG13VfGuF/PuXFvYggUPT6Suq9pq/+EZctyEo28sPZCaY6UNfdtydRLSzWknZSHN0XgF99a6DXZAKcy4Py65WtkuFlifWkcNK0BPUfwUDut5s6imJ7+sT1UxAGTaOS3LYcOlJbHHdWQZ5afIPWGIKkUehWuvKmhrUTIcwE3jnlA/5Az2geCj18YQ2Kt9frjg8+3SRU5hJys1k9O1MwCfEwWL23TV6in6ZJQYqnc0jK2j4BP2+WZAmx6J0EzItlM7Jzoz22vjXKn4/rz8WWUCexl/tjknGlqrCPiOZ8+0mgq/PwhLkWYKrLJJPE7oAicEYgfwO8/AdtsBHPfmCoZa/f62g6oUWobSLnW5+N+GBlbYMOISpQCDjr4KuLbPKD+wKXt86wJneyy7JWNbnBnCmcE4rYBc0dKU6sQKEHgt+c0IqGBvRF3Jb7i4zENugm0l88/g7ykBsewhKYM/D3DzVZ0aChS+g4gDv/04to8OhnRABYX2FDDF5EFxXSIkCMoWzo+QhNm6KlGxIdj2MxAw92NAZ/NQ2EWGXBsEcy3jzfyQTFY3gRn3jh9L24PGE1dQnxRXFkGaDga0DymwxXvBcT+h8PIi6D/8Ok49Zw9kOCdXQ6VcycFjG1xVl9jLUKSDNszJ0dInPVCnvfm+jqW+JDxutTteWMEbnYZ5rIxjyit127HM5gTtvl0DOt7L+glaMoEvCNYbduEaVQHjWOMQ0GM9mc1ib4t8nQLadkX896+ScfdL2R220sShQWgKyrnQZ7kDgmwuk/HZD+tyKH2oYu1JZNEkbCAyxj3f7mkZNhPf5gniQw/jOsgfztNLAvkHdflB5ZEArhCerC1gKA6yKvF7UncH45xkdv4eW74DofEoLoHnW1MEQgXZkMeEPm+gx0Erv6F/FI0PdyIOdImLt3fAgfW4cnI0g2NHZ9HW+ARTOfDsamJlEUUrenkYVC4tMDO5A+3hO/GyakgOOkBu/1GHsLfZs+eIyZAv7f7p9ONiQ/uFKYJuIE2M9rn9E4+G0PvmzptXjkUXxyJqMBjSOdBReIR5GSuOW+6AYT1L59XewInc7RFjl5z76oekZeNCWLaKYM8ajn14Ss+HMvsKD+c4jqefRkcQIzucpE5/7NrOD1kc5RC1j+Rb8YKNjrLqpfz2CekTvES42NNzOk5GMkN0jVIIl4+GS9r/rjs6kJq2ycQHOk7EnNmmSJ4GNURZSmdEtz5YWoHeWUePTFum26FK82goOt/kE+JDOxsv2HWlCk+GqtW7BrIGoO43TuajY38nIl7M5kciJlv/7r8jSw9X7MqkL+m0jURAcz/IZ/xutGyF0hB8Ijs89FY5MM9btNJr0Mh64CqiTNhiSJOUz0IsOXMvQYd6f7P+CRbDhuZVPasEGThbnihxDEXGjDchVBQgWTRMNWbPhjP3CmfljNxkG48MRV3J+11kKfYs3ohr8i6JwURnXIPUUyBRY1jRPRZd9CsIUKo1DeSdSOKI6f1PVXj7ocgnCo/GI/GDVQJTyEFhUqegai7J3iLvD5+D/IxREfkYgUnsub7msIwreCXBcE9jE/xbRuCha5Z8Ckiyea41f5gfLxm22bRhPbLtObYR7YT+QVpzqzpOiHEaFPB4aFBRpX20DrZZ6AARxGYa22uYA/Umd/eI6C2XglLfDKmHEbgT3fjmsG2uWAa8T2I0udxBhXmVvfLSSCPFL3Rzv9EHtdzrriptbvIhzIYO7AI9B2iDxPaG8W0748FatqHziRMmpX6tkUonkuYUK0ufdtU6tdo51vkD4ORuWD6oVsL/CaI0FYc2LOZmLa0pLCbapcKgfmUfYD3xjoHyAemRmhT1KMI6WynpRX10nSWioaTxRbIu+EtmKkPc9ROca+Q3eSUkhUM7pugUSmZYczx0VlVSaBIqr3HPd8cU2GzEDt3BtGU/WGNZXsByzNbwd3MVCsMl8YQyPgcy0ibBPd8MV18vVtt522khZzDHFLwk9UsKmzjvTe2i0cvBtaZxOELEEspSUCgwW0TLVnIOTKfyTtXjnGW26DTvLKTF1MOV4y/QcSSMbcxVxHcOQrxeNxCMNcg9NZYRVuTadY1MjHNiqYngpfkma4MPyEufiGfQ05pHat7wEroxo0jXrOsjvEhYlpVm/uZahTzy6Y0jTQLszBi6s3xFKH2L9wXHu6wpCupSN01ePJtOVN9nqy6Zv2rTsF163CQVJgl0oTN3SDiDjZmUDHOtoTo6Ls1GWRP8l5vjUlWJ5fYzlkmLzQXtLavsYiuzDLoz5wEFMcZdOZ4kYt7/WFBJSWG0t9yHyBiyJT9OHtoXCDyoUzwlGJK74xrMuJWJ0nBo622waUexiKecGRW+MvL00hRi5ZtckA1h9QS+duy5fLb68geUwyixFmMWuLJgoMswXzXW2OnYDq6RoQoNXxFLIbHb93WmSuzylkMbRvsor5PGO1RcSaAGPOk34J1KeYsbPSc8sKbiJntlT4Fbe7PO+NN/yUkFrDwE5ZdppMl/4c1bOaZpoUMBRWh6bssw0XT+1n2V/dkWBs1aUN7SctH8LD3g5Wd0Ugf5kUJuk15+53xUbzFI/DCOw/N2w1cJ1RjdlLt1pezEG82PwzyHA6v4dY07tN13j70OKvuuOy4iLzn5NiEeZD4VFH13ngJXrzsodAZy9jNvGs89HdM8vwabWPv2Ihf19CVmVMsx9sulxHj73U6KZzpTl5aQ8QR6ZkjUGVcS4T/GkuEbkQNFnSzD/LxQgj/OK/z1+zxHT+3dpVUXTLPr3P1HiazazPcUkMv1LM2MyPGJw92Wzu4GwZx3uO//z7WJZyjW4P2OcYP9cnzsqfozXz9zRo0+z0V4LGMC2FTPKadZOkx1lx7gvZlwjTYVInuiC5T4lRBTshw/I/xwAdUxylu5zZsMM+B2WOdFwjmjcNDI/7dxvfs048XaMw4YX02QQGCq+O8DYLv3XX2KKQt8/L6u11ry5Ebh4EkwANwbyQDe/8zLZpFSrRstycTYL+qgmTCbo8s81mkrGmDrNNf5VDAh9dYnHBLqPuIQIh3Kf4NAyDh56NolJcjbIRpnaEiwzVi/BoZ8cDkBna1LFK+NB9yvJQ8U2DUqqhXcRL3IsfNPqxLchCTCg2j2qybMX3P905QxvJqOHica0YHo0FtPL0IbFRwIBfNsiBmQPbDElEGg3WiGjjuGxZ8kT/zjnCi0F6c8x4oYR/domZmKivdB108cBALkuagcRnmB1IXhjWgFI5oq3sKulBFnFoEBi5TJFDPcH6RY/8jP4tngg00H9TRqx5gvR98yLhW8M6ZAhZ2NNKRXZJzDUxrPtdYvEgafWFk2CEoaJKEJx4pMify9JusgsFPWDua78hmR9BuTz9F6w3KUsUXiyGPaDlXkOP0v1RO/F/rU0m9G2r1P9h3tvO5ULg2jPQix94VbSuCfnqHaBWC/G8xMgwa0kXHh8cXsQXZg1Y0RpbxYgJYX3TfMWjBCMCSnY1UgsXAIRnqGMVHvsmHIgXBbOHziu7nwBcwqYJbfQ4Bi+CMkfQUasaBZqVXBBJmC1LjPckhXzy91JeKHt/qujhkB/Pwr3KmlgwE+C1GrGizgtgkc8+hIHq2NE8ctGH/qLCS5TtolqR5gjgjnEDgQwnIGmOaOtrx8kVQE/kqxwE6Rn+jHh2GxIWxn7C/r3ztOfSqrHoED9CkEZo9wwF3DrYwcMx8ZF5VKU7/eWfITyERPDwrZNjpi6ywIwZmDueP+1uStAgj9ILxW3V9VVdHhz5APJIvI5gO0D1Q9s+rIVngNA6kUIc1KXYMG8ZAlR0x0I/1xhcZP7WIy1wf9xvBQXHgWs78SZQWzYTNGM8/2RGUc82Uc1glAi8/98rIc7AlFRxD1q2mAu9kLUV5TEPTsj4qKGHGDICo+FVVfbatOGAyeDV6nGEyObRH02B567hoePKeqAHp9EHRzZKux7G4ZOP3JEc9heKzslvtKN7pkaT9kkdgsY3cuKVTabl8JBctqiyOWWoxGUVa0CxtOcWoeaJUJEzmGoPMqpi3cjUYqi3op1EjA7os74yIyWGSSzaicPn6/ZHt0qTQQSKliJLXN7OaWPPYPDCtrjObzWc58khFGwiVZXcwl8+oQrZCwsrhncyCOsDtx0rtOICo6otZkGbSQE3BVF5VzpV5JqNsHp9kc/FFJUEUkFxwspMzhAjc3OQ0WFX6dMiFSAhFlCrt2tJv5XfMDhaTXtrKtlRzJvEgI91INnJz/VPTNMkv9m9WPEbW3rxCO8h2Jpd8Rk2GoeV/Womg8nok47CMlwUqK40iobcyFjmkztTw86jNJefXvKunVcpYUr2G5kR2PrRm/V0RiGIlMknF1LXe6at1crcyBgGizZWW4mNQvVLq/LDL0FiStyx5IBlw8pXQ07GlzjorGyBDowDm8hjppm1gjBs5dzyPsqF71anW2mlydYRS+oBq8/GiEO3hRzEbE8/cMJbXW1eizSVmBqwuf2xd/9gMlEV0LKNkXs8o6tmwgmTUAjnSX4ZLt7LK58ttvEy1Lq1fdC/faxvTtdqdbHn6pLXgokd5RhnbyHLfwqw1hPloo8naE0d3UeQgKyVq1czSilcYjJnFM3Zu5bHq1KytY2y3HXLeKpiWnQY5eEhbvUz5fLTZulxjWRN7X2kXjW+pxw/RrqaLfI5kKwagVYpGPdkoPp7JVqcfjJYErD3uJHTNmxe/ynu0248eB7u2buUcisooJutNmVbkck78uqFa4OTAtX65kkn4YraDLt0xtV+6hahk7rHVdviDLJMpuettzq31VR4Am41KOFnBlhVWArJ98ZxSlumspX3QIMM/fidbryurCY6znDadxFi3bqXooXSV6IsT+rXiuKwaO/I4J2/usqJDdTPEvpTfheKWlbzaG23fql53qtL8dDrYZkDZ7tKCo8Xg2Eyj2153eXES7Q+jF7/ouzXZkrHquWrjDRWwwFkty9OLj9i5TucKPvtLXyRD9Vb2OTdIg0lrCVzrTnMuaZMSiFzt2RPK6RJtdHIppAqd6tkNZhrTzkcu8uY/fvWumZNM/LwnXYWp+fSdbbunzd5GpE3apCl+84/nn35d3ntrfN5IdmDeHV3uQ3a0tDwePV+2Wi0uvQmy2Y0vBtrl2QKMrdDsRecxUYLftfKwPLtHxXRZaalFTie60hO3rJ+N8OgWbUVD9ZridQV0KyHo7LTGdjstbH44mYt2Pa2B11k3dlLQrrarbKfPyx7WM4H1xzKxb9bQR2//EgiypeP+YQ/QXb7c/nl9efHbjUXapYTcJojdYna31g8wjWDS/9ptMdtW12/CVrX0lK/0izYuxP5O/rGG9e3RZR3/XZRnP9XfubV9v+WNge3JHex54R+ow39ypf7Kbf/sCpX/BeNFllPT8Hfw317h7x/5u4L1fQN+6cF+5J3vbvnHsJ99/osI1L92zb9yUn1JhQRBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEMRv8R+g7d19aES6MAAAAABJRU5ErkJggg==");
		background-size: cover;
		background-repeat: no-repeat;
		position: relative;
		.header-card{
			width: 750rpx;
			margin: 0 auto;
			background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAvMAAAHHBAMAAADAKMrCAAAAKlBMVEVHcEyDaDuJajn048T77NT037rp0Kf64rn01qX43K/86Mbx0Zz+8NjtypOr71jVAAAAB3RSTlMABgyj0rdL3ZQTlgAAIABJREFUeNrsWrGO3MgR3YF/YEYGnK/gswFnlo2zYkdO7cROD44uPgMECTgWeYQyA2TDcGgTHigXzwQzR8L9ATH/cl1Vr7qrmxydlreXsTgzuyuNtMPHx9evXvXDw1FHHXXUUUcdddRRRx111FFHHXXU3jrR86jnrU/F/pPfedTDc2LK77mcj3rOupwfHs7n74P+/HDybzpdjnq+8nieLgTtw/kjMn/2V4dwPx/HMx6+CNfTxyXJX5/L6Xww9VmLAfXInx9O97SGsL8cuP8oogPs75L+fCD/o5L/LulF5l/84q+/OeqZ6/NHCP4d7EnnLz/77X/7th7Hsd6upmnsD/RzqN41/rhbXVIFHZ9Sla3hWtGfXJ9Y7/j48C6pD9++48OWvP3bT6gP/A/pP6Hy//u6hit9eDqH6/8/Z97fkxxvQC8v//zP276a/YGXeV6k5uleteGlnsappao3rnZf9/FKN/5H/3Sud/6Pw+XOq+xcyUWXtpTLV+Kb8nsvM2NWFYPU1V/rdTGew5D8S/6f/S/t9GN4Wva96/0Z+GfdVH8ixT/fszdebX739umgLzePsn/eJoJ7AuzTMk3LPE/8TVL+lqJnKLrJaj6ye63BAyD3wLt2uMNwjuZO86jza0e3mP/e3GK4FnfvNA+3R7Sy99mVHtkFwF8VeKsU/4aOf20AXtCvg0hUr2ilPd3j/OWztztwvwnV+Rv/xT9nAZ1YT8gn5G9HQt8zHmRnwjPnCXf/jQEe4PfE/55YpOX48F/XrBcIytKzv+tKQZ7vgQLIZ+AP9BDUh4GejLZ/9V+u9PXKyAN9/9OgVVWR8HKflR0uvi/+dA0xHjfuvx8vHBNs0d6T/g9Px12wn4X1/lXFhnFn7KcpEj/i7jnuLwNXYP3W2lLzncvAmzXFSI3lvNAOrNdiugv3V8hXij0fROdBac/w03Vg1aZnRQffDLg/qsD6wv8WuejhTpQ7NK6Nb35PK+3mGnu6vPj527067/Gf6THTYxbM51lAn1OJH0ly/HctWE86A9YT51sLu0dcWE+4K+udwN4Q5XPWd9B6khvV/JJwKYT1GfKs18MA3jOTaSln1AX8gWnOuGesj2pPF1Q5r8V3JuHeh9P52yOb+229+ctTSS9Cj5X1hmcUe3qdLekV+ETrSe0/xnpmThNWVgfaB5FvDOlZ7lXrC+unhPEJ+oG4g3A9CD68FHGeac6QM+mv+Bt6U6S9v7PkdwW1b5zDxw1GYXzzR15oT6v4xuvNT9/u4LsHnsC/icgvRHpPd3/MjPicAD+NDLznO4u+Sj2xHmo/JvaGPQ0Rp2mM1AvtGfk+0xw5c9b6Dqz3jCxE6jeW2IHhVq3BIhrUnOEXqWHNoUsxGIMzqNbj9lKlp08n/JAPD+y/umzRnv3NL3epDXN/EZNji1m/Qn7D4dSQ+zoBvjFa74j1LjYQvH6xnLrekJ7Qdkq+zpVR7QuwPukm4GaE9bTCyqOILYQ/hrjSAnv5S35vMJYdbrDAgCj1ynp/al+T4my0sn6Rfb3Xzc/8heRmBunB+pn1ZrZSzw4HUi9qIw6Hqb/h6oPWq+KQtcFCttW2KetjFWJwyg1jKTrDrC8GSL3aSV1or/K4MuHhf+RfBIPTwd44tTeNg9Sb/rNt3/yawpz1Musb2b/fdmk9s/42ZZRfgqNfLPOh82Ru1ODA4TA12roet7Q+aZmV84byBvZOllgr84WYm2LdQotkwNFXLPW2cybWX/lL8PX0p/zOwphL1nonkgNf37OtZ86A9eP4HwrvV/GlZ/1P/rVLbJjq5HBE7dnPi9wv5HRWpn6cxNwI4ZXydVuvG6oen54vAPeFQiVwvs87KoduUs0NPL04nG6l9aw1lcg2s77QNvbKwAvqlQg9P8w6UNmWqgy0d9B6hw8bz8ef4ldbHe3FW8vP5qfCDlfPrGerM1udt8y3/pKX2tGwPmj9mHey0g3C2RulV39jcO9MUkQy77LEqIP/Dg6nCqSvxM8P1RBExza0sDfqcvJetjP+pnO2n5I7Vs6DHMT4jxfrdfb04KX+V/sW2QU9bFQbaWYV9Eh8UL7FS7D1NbR+I8OJwAf06bQcGfp+Jfad0XqzxpYqChs1IOAaoDZFDG/UzYvqSIoAwRkqdaSaEInKRdbD4PR9lPq6pXX2stXKfrlLbhbYy9mCD8rnAZpgzzqfGpzA+jFVeYSjkpwJ6qC93NVNY2196dThxPSG5EZe1kqv3AWPK+PqVewH1vorwgTxO3KTGNqrvdGeqpGUg9vA2mr9/754XLtLv8y+/HIP52fNEWDrGW72NyD7nLSyLWKEcYTcj23MbzJ7ye1sL9LTm2LG972a+jy4dEkfG5IERb1c0R7mfigG6+rhZ6h7vWp+M4jgFEp7RT4jvZP0hio0syM5uK+/WGm9pJavd3J+SWQ+sp6EZ1myAEdis0TopZNtk4ZKAmIstbGTVaVvRHKSVtaJk0dyFojPQiMan5C+KlSyJUEoQOWg8XD2ldhKBZ9oz96mQmPQRdYHqUcvWwelxwm+f/VIA5OVt3z5eg/nsdzO8gi+ftrO6sXdjFPg/IhedkvokVqyqw+5pauhNBH9rJUN3VQZqS+KsxXYw6kI6xFbkprDxnOEc4Wr13DHGEvVehgcTRF6KE5vTsafZkPQrxzOvo6KM4RFltqc8MjqF5PhjBJbtuteluQmhV/8gSyy1tpH1jfrZgre2pAeKl9sJQkmni+U9YNhvSaVkt5cESLIqhA7KpU1oziNkj4ss3Ki71955E/5nrMdrJ9FdCD0oZedbhNYnzpLamCxympuWbOzr5FZ3uF9g9hS7U2PU4PLMYqPc7dZPfex/LpuZrWdKqLoBFcfAsyr6s0A5rPi8L0yxLC+yPyNLEaYNNQB/fevXhD2pxT7fYIj6+w6v1lCVp9ae/HzK9qzv0myywaRMchvC5mxqnxjXb1qbpLgMNlLXRKTAKeAtWHCi82MWf1whdaH5DKwvhiSEVX4tSEwXgU4rK1vXq1SnNMO6BeNcNDRBtKL2Mx5ghDSM6V9HFAx5cdVgFNrJ2ulvtEgvMmVvrSsdzHAKTrNcFbmRiRH4vqCm6mY1XM+rD3sFWMScB4HrmYpM9myNItsn4X1nJDIMpu7y8sO1i8aG4P1NzOgkqx+SQdUrbp5D36bUJ79ZRZbMtpgTiS+RDhK90TvuzeG9bGbhbPsijKZlFR2TjVUMceJ+c1V+A/SC+tBfGst6Te4bDDbyDC8jkHCOAL68yrBeXwq9LIBQcYjMbWcZInV6dSy3ofAcb0anKlV5Os6mVAp93sMSZDgyFzWNFXWz6cOR7P6LvRTOe0rzKZYbTg51rmsenvtYU1wKZlPsh+BF/eAfO/QT3mxx2CZTpJOuXn18pIqDuvNDq1n+G/iKhdrcoT107y1GYEB1262DVn9ONZ5K9uH6C8EOLVrwm6EJhuQlF2i9Z1lfVfc62SLQq0Nr7OFSW/0OqjDMQanSoKzQsdTnTZUCHD6yHo608mz/nEjSHh8usMRfwNLz5AL6ZHhzEmCQwI/qtVpzWxQlX7T43BD2CSbESLrndvwlyUcjng+cTZIzzZMvXoVjGZV6nkLgs5jdUOTTqgg80OWWxqpV1uvWg/W1yI4ST+7g/UaWGqAFrR+nkJyuc4tVemzPThjPpftI+3ZILtgbmArQ1rcRGMpYypYjTK4ehF7mPouH8uyQ5eRX6C04T3UPmQI6GVjZKyxtDO9rP9ksk6lUj8J6/Odl3tYz2rPQ3GI/qLNLDvLtdzA4djQkmkvYfamw2kkOIOrrx0EH4OqvJXtxN6U0eCI1EtWn1mcAa0s+/kwo4KtFP4PuoFPpyTC+jih4gUEo4E16ePOOcyemfWXfJXdZS7VV67SG+QI1tSPYUBlZrN8J2JWknSzMglvkOGktj62USGu7+KWhHVSX27sAilS1gdbbykfR4Ss+4R9pb6+SjeeWYOjDXcT0lf07GB9vu9yr9Yvmp0lY1meTs2rFGeUsWwr00H19WJxVoxvQmJvXL3Elo2Mw/uVq+/AeKepZYn9fuLrN7bgAEeZOjHVjcWJqRm0vkKgn+y0jPvO4hYcl+5+Ylp5knGGkxr7p2v9crNavyxpdDkH1ts+1m5GEL2v43RqXGf1vW5jMSMqdfXNKjYjV695vTK/xH4zeS3zHTgQ/AGUH4awAwe7Ea7G4VRmRDUE2psEx2lYj9iyifyRmcQ0PpfDwS4EGcqG0DLGlpjN5r5etuBoa4XNZ3d2GaOxIr13aYLTW92xF0CDs5jV65Rqk/SB9cWQ78AJrEdTVelezDgm0e3F1MuGHTh2tGCknuobYf0P0vpFJ7MwONHVI6KPcrME0iPAyeMbhX09oMK2szyuN3uMra+UxDLNb0oZZGxtBakSra9MgGN4Lz4zDkqyXWeFunpGvku2W5pdIGpwhPXnZ/D1t0j6SPnbhC3G03Zkz1QXpa/HqZaoXvb+rceyEtXbARWzPu67jI2srrWlC9vOQjOL3WcrZ4/VtRgwmDVSr9iHpF73I1yrorLLLNDXz+Akv9HPq4LDrp6X2Wfw9ZhN3TAksf5GE5wsR0ByYOeyCevjWosmEAtVstuycYnWN8ZXKuPjRLyMM9l0D06lMybEZ5pcFiGrV+y1rcL2EGX9xlS2jJstHeaaYTYovew4fkOsP/1Q1oewXja7mkKCo4KfhpYk9aOSHqwX19uuWS85gh1QNdha/x1r12Iiu5FF2Qwc2yRTq07AEgpAUgSCTsBqhPIwiM5lW3XPuZ+qmoU3GttrHubtg665fXXq/DTgM7rBx8x3XbQj4DLbtaDl+kjBYQwwKYesUy9Dr4zxKsy+uZ8SHrJ6oZIvZ2+7Hih63/Ou/+s/d3G9iuIn/gmms/MMijhs9fWq3wrKMgCcfhia1rOlPHj4QIhw7CorOokwZ1MN6nVxA7Q4L4KYngDwn4T2D8/fOO+TH3qJ8rip56ofZer/uo3rT5D18IGAtTwPsvVHESfZyFlucp2VoYfTcqyNrnMPx1mwGAuFMwxLydW783duS7G6Ni5UK2VZWm/MjIAjlvvsU4kzyrIrPAwqiQt9481Pzgki+OZ6rF3I7lXfZv9018NzJqxxWPWQqGTqCweOPOWNwQFtiXMvacuepnpd9bPKsp7EUdqykyRPkaHCOk61xdhb/6h16132iXF/uCgPQb2YR4xFSKJPmTIrzuhezQj5MXsdwutXbrMkzcSOIKMP2pL4MiZKRht6nj40qqYFRyk0IS9NoOL5z5URAZ7LTs0IqVNs07X0KaGKzdltvrMV4iB8rt5sWYiDF7pJturl6oFLoEP1cgKv+jb7Mw6HXle5yxpZ7wTx09vqEedRmYQaVRHj0bGfw8yb23Kp7QgaJAmuelxmp6lN4jwUYK6itkav5WqarN/1yYGcfEPGs6Ww4ASAIxJFXjj3b7PijM1mS2WLD3A3OPm46kfyCKNLDtLSPTYymwyVBLIeFpxZ/bwhwrYA2zjvGc3dwraEuV/p+Fv10aq+M/7r8YyQXrxSHltWFmPau42t/wwXDqFxm/3zXU+TcWE7O7zBOCaoqqusmi1FJtkiqp+x5+cijD5wyw+BLAaJIL9KzoEDO8jUtFqmZItHAQ6Sgw+niNuu9/yNpnEdbTlbhso0cYXWr9+5zZ5mtjzfAdafdVhW+RvNUGWAg5xsw4Qza6okmBHgRihohE58CIxPpcX7ztoZ8dWBejn7p3L1FMNNEX+sSluGVS8/2WnRuVffmZ28IHo39fE2+4e7/uTcq9nSG+t3Zzo7HW0psYY+Dj0j4luF6ue5ZC0dbxkVKs2TyGPWZ8SR26zjJA94EXTj2KpfiehdcJDg0pyaCVkSn6BSsj7vG+UtNUL2G7fZk//CrndehOMAtKn83YjL2q6HxzWu+lmh/ay0Jc0I4utqVmB0wHeKbxBlzfG+bzJUGl+T07fUIL2Wtm3k5FMINdDtkL9k+auHRxHYM656HMDno/9T32Z/os1CJzlKk7E8Zc+9lRsMCSoMvKZmw9CreUuTgz02PQBmlZbl1DuVSqaeEb+w6leeogpUBm0eT02T+EiJ+s4cdZZcQtwFlaHnY9/g5D+f8f5tFsGf46Asa1NPm2sx9gCW3nUm19hvyl9mZql6r1DN+GzV2HeUwoU8Mx6haw+9iSW8TjmqHrqsXKqY0new3jKbneqyIHEGoXBihso6OcT4d0+blUcrZdm3xzeOOquIyzoyS5RTgkuimwaqVz9CI87TiFAxtlkFB0H9rpCpUtBlOfWrM51JFY/66unYD7t+gAlk0EaQTRwxebX+0m02b3ku+2vb7yYNnmdg6zeog1GW7beR1E1wP4G74arn1C+zpmVL35m1InivpVpwaoCjvj1XjkDzvJhtRBQHh2Yh8Ye4pIqpXxxxCSgw266Xk5e//r6rzZ5qt+S4a2iWomBN4ZCsL4pw+mrm8YgFrq/sCPKlXmKEKqZKpmg8K7sRqDJdnJeLr3kGZ6WtXm+z2oKjDhxLkyis5zfTwiRc9PJhL1n87m1WmJvjfZgF53S2MyDLo1X+5PAN9n1xo7K6p4K3XNSQsFQxqg7J/KV24LS7ERJd4Ym5wadJskoiqAFHpj6YEYRFyNjGP2d14/ihlxkb++HrnjZ7ai0F20CsA+cEeRa1wc3zlfyl0pYNVRY+nLDp88Prc+x/D0Xvk/6v8NRTmJ2gaHhA32kOYnI2HEffqBVn9TfZQqOCDGZnT2BpUy9PvPxZryzV1+3brEhUB2lLVaf81NszdvTBEv4IRqUtW6qs8pUO1cvAmyRrx/9febwKYRynvoO5O/7lHJKfs1/XgqtnmITdCPKghR9W/QiTpEn8ol/Uj4CTH2XoBcth6m9qsyflwSMkSnTPn+H0deZDnESsT2PRhDMYhTaUg8+zH8LYT64ByroRdONEA46c/AJyX8++qEYQ1nj1m55my9VYS6/MWoLqyvHol3fLhzBS/c9Tf+s2e2jXnBAJTpU9oA6ezfjgFv2W/dg3HDgC5jPzN5d1Z9+UOaJ0DHlZEsadnnyBcha/nj+/Swv+hKcX0ozBwSfKElKB6mF/cqosE7NDzzgJcB1cjdsmU//jXS8uhNNNPa+z3PKk6k8fGxTKerRNL5nNhkTCEpwa3yh3OXgvAlWqAtJPLASZkpcIH9fQQ8KlXc2FxD+nuzI3aCbvxypTnwxbsvGCEIfHjlUvISo5AJAll/Hv6+Zt9sBPQKz1BnBgMT73+jELVK+QXsRZTSqPxXWKfL1D9b4GJCiznfiPZN8YwkFNTaol8U5ozm4hKu2SsxirAQR1c6vVzcmWX8MTo7Oxn10DEURZfG6ePBDOHW2WTH0ZEcemOeuWv6xMFWYE3fI1wBEvwlyFB5v9QxPrKAKiNwdOiS07V2TREWCmokIW6P6pmnhpwun0KjtNwQfiSinAXfHussmuv3ebVdY4oHrGShrVCLuPy+YHLlD9VmOcmVMvE9+7XgRr+ZurkHi3aMmf5A1SxxtVdfKKgiYhO5PXZS2XT4MxLX+u8KxLSuCoIWJg8RPSsqPOPGwJI3D9D7VZbX3iin87TA/m5ixSDSILlmGSzRsRquqnEtwMgy8647J3qIbioA29+s46nybpXLuy/MCmlIo+EJDzQPWrxWVDIUjEN3Thyhf1OmwdenXYv75u3malGuFA75k5cHbzgrRajMeoy+KhXx37TLdlMNYPwlrWvvrYhWMZKg1RdfXQXz8mWMdkW3zO3oYeUomieunDEeF8dfumcZcNxQjC1tJvkad++7qtzebbVBEmgf9m37UO5FREmZXBcKe1qR/7+i4LUbbN4JTlitjx3u7nS8+K7KCIiZTKhfwCm+BcxqtGZZ9s4UrR5gpKenKdFHaXvaY+O292JcUzzvv35m32YDOCdP1Bmb1ADfjLsOm57rcoTu1IKW/1upkRhZmLqR94n5obD1rdPR0XTlJ401r1hlImm3pQNdz3j5VcPVjL1TPGE4feh6iWPPMO3vS26sf9/PfrjjZLUVYMf9F3tvsu19MjS9TNVQinKH5ShDPEbY9mZofnB3eFdbteC12TWs9SLPAGnLSFjS+BZtj09BlhCwTOozIZW0FDIHBGEYdg4xVt/L19/YLTWP3dx1nQlqymKCQqTH3gLbFtxgaFow1/6jsjVz+UNTiTkfb5B5BUnG0UdwuanFBvKUlvgZerZcWx4rF1WrRl58wI1m25sFe0L+BNn0/+eG9fN7TZUxaOCLOVKou0bKzA2czaXdWdVc0IA3u35pK3BIuAb0VA9ZO2/Fn1k12o/PE/OvntSZn3CT+KkCexmj/2GFcZqmT61GCuM+SUh35UdJMHLLtg3ufr7m2WDpyQJjnNV998R8M4uuqnawWObZ8l63sk9Dtrna6M/tDT02V32ckihC5DJQ6cqbXqZcFwiPPYp6QFULJrHtpi/LTOBF/omu8NF6TJ4sLiwrL5WQVQZ+D5Gvr99XVHm2WA6k2uvtUHEtOym3Z372Hqx8pi7E04Ht/QVj9oTU4/WEpZSTNf/dTp1IeVA7IzIbGZEh4VyVP166qlFChYLM0I1zbT4hucvcB6EWXzJ873xWwovYb+syz21+3brIAaSTbY3O/idG03nsGCo+RxT2lqbJRIQ5l1hfXQqHrXMTO4xKyK4lMZEi8FcV31ahoGsHe8pfLF1MW1gjTYETpIUmgbpySeEc44AleOPQ5//wzrvn39XJtVWbZ0WxLMK2sfKBx2gYSpr/uLZw41PNJz0d0NlV/qL4dFuzimovbJeinSVDxpCXBW7XISfJTYd4Zr1fPprrKsMfZhks//z1hKefrIqr/+Y0Z1mKlNLlfX0O/3brNstBSPsTrP3jttZ4UFBLWim7gRNEMl4amtylDN7n0NMTu4oGaULov8qIXoIVlxq7fs1PqU0jcAZ2XJBIA9LTh4QwPHnvw9Wv7W+CflDSO3V+1bzuzNeK0bwreLq8pDj11/O0tVIZydTcahESTXK7oGHB36sWFG6NGMEPUp3y8za65zDrepUpcVO2ThwFECJznPsLD9Sf03hDVPi27yrTwawcrYxvwHkBbCyW90r+dn7S6r+HX7Notxf4eION+DdNbVT5j60HjmeLPNV3db+dP1MRZrMc7DNcs7kkBrhjoWDL2+vML7zrrG1MucX7/p8525wCVpM/kbhkstWFxXJw7iD4L7GXuSv/5s+svW7ZKbGVni6H+qzYIm9i+jCrrsWaLLTV+S4aae1U/btpUtxhj7vtHoyo4QvhAO235anCBrbsuubTHm1Ku5GFMv4NKlxH1EvEqJf/5IcWTJ6aOZ0BSqfPKb3aZ6nLxM/a3b7MmQuDWeaV42P26PKMhKc3dIk3zTaznQACX4RpsRPp+RpVALeFlZ9pPse7GAKcBhcvD/7XpWtEora0qrmc9WGs6eT+tBW9PDVXfDSo8brM+1C4j3Mf1r6M/dpv5nu57vhHnXxZZyoTpbzQhEl8XLSbax9iIwIR5YS2HBe3tfxoy6HG0fCsse7yVpKSW665NWCsl1OIGgD9gS9SAPokvjbwTRk7EUd66SCAKhXR0LZnHc791mpfkp1IFYyZ+8C6nqRsjzvpvDeGxq4Q7gzHP59jUYo1Bbj7QSldkiLSt18qqPdN9MPVA6brOJ/mJkqFazuj5gRbDTn7w8POPsezf1Ia48ql70+rE2e9btlv49VEJcHrUDxEN7n6Haitvs7ABO0QUCNnmwz4owIYODrtdS3U/F29ceFEo0rgwH4Of7kp7qPfPFltqM4J+xnyeJm3ohEwTtsvTJe1zG3pS6O7dZ9YC8ietdYz176ytcP7p3k/SRwRmrOxWnHqX1eCnMzAervdcy8zjdoi3S7o2bavdrUjhy9mAixZtw/Qd9qMrpm7P+SesTG127rtDK5t6xfuVdxWmkrzvaLOpA6hLjU98Jc8a47C5pElv2Yx/fylN04IC9ca+hYlLAZ2Xl1mjZ/NAIAoDZ6EUw9ixR4RYHVXrqi+9WrTp7urc0hLeTqP+tQ/+QfACZelwWN3/0sDre1maVwPkfaVeWIzeOROfWGuUJJAj9LRI+gDB5Ag4E3aMKQt5lxIgXG6kCpmQD3XaXy+5MZigYy1sOZVGZG08r+7SUPRqvlSK5/g6NAPwNuiZDnhWL+hE5h5L9ajT97AwHndfs2EV9zkoh9FEv7qauuJQJDsRAVBmB9c1oVj/oMziJFohG/cInfwhN/q6b/b9z/amIhPbHoa1s5zrID5sKui6eSdLrnenkLDdBT+9WuDMYbVrUr5FQMogaS8TVCxzBw4XpC9rKoqkyfxjgzizqr7+0BniikhSvBo04JUzIF4omPx0BeJN/2c1COVpdB03ZspNMj1FfnDLCBMB5206JZQCVN5MbW6LAwbCGNCDqE87zG8admTKC7mX7ZI8G2AMnsZwd3rKi2nQfvgUSlf2ZhJOvia3+/znjTIIwdp3sJGQmGhz/9+luVgjin8+NMYmOEc79NtdHSgmGlj1BX7rVFElUqCxlSImyoon6NUBwVhVH8CVOzram4rQt43pmT7ED21soJYI6g1eb/JmEJxAUwpy973pR4SeWwaGVCRMJ/7KbtQ2VyYHIACeiERYjr9EITeX9pqUpwCJHPE1+Vm98vMT0WFaK58mCGZ162a1uVOyifhYyicZ8/eCGzZpZrW3eIqROKNhX11DJFrhOMDmMeIi5qDcJF5Z08oS8+5vd7Kkup8e95WArb9lH/SJ02QaOMIM4OAcVY4zqbWYzIuyZpecqnOBDNayddjen61GA3TaBzDauZ2i9qiu+heQTLJV5Ui9oHs54WCSk2aWbBboUjOnlnP+4mz3U2/dgmwat6mG02Xqc6riScz1uWJHSXe4FXWfRFtUROIq3GUoIUCSgDS0cGrpmdkA/O94NcXD8DJis/9j0DLzBlxAHsSZxcITrb8QCQRTy9Z5NfPYIe5ZeOoHxZi2ih7vZE6dAhmpnAAAgAElEQVQPElVb4FiaP9u5ZSP9tLRi9R5pKbdsqOpd1Euyn+UrXhTBVlRWxKyRtJmc9zu2XCs4s25S/FYBKJvVG2eT4RFwsM14NfUNhVuWJpYExaHkU3/99Xe7WThaO2UExuD0sHq4y+Lkd6vqeVzfyvwlD8RJjlEiQaWxSlGPfnYUwXqxVM4YGHuQqxN0dVEP4zwgjSGiK2zZQBHfnGp6jXoudFllikscfuXZ+1AtuidU5vLX493sCeaa2mQcjiTewepV6M+RSYrctE2zPU9O0HJKcUWl8/lZKpnrvCTqFevn4MM1KNebs5cpjtun058DCkdFETjqwUoW82t8drVjgBhVDXvOfvV6vd4WO2TIyZdimEvON4w+e9DNHgo7O3Rs1rGojh6JEHWfWG0L1MHSUZVlTDZFv0HJ9RDrbqOeEpH3Tpi5ZR1axfqXP3oVx+SxpWqm89hyExx3ZMtWjCyHBKJ+RJdBFU52BTOL/xja9boOy9PdrM1vgt6ZmK6JHsipw3qFgURBV/RSP+1laQWbI65exwirz/VTr1Y/5qxUq+FO+mkIYEE6v0EFvHVIzzG/wtptCPP6dYUcEtVTTN7k9zPPrkPnmr443N95lr/qZhmKIAvaEPNRBWdRv8dFZIwnAZ5NUyl3zEHB188ywckCwEFdz6BKyq70xSwMcRnY5+yYhjfylj7ssWUZVtYzljuVhzdKlqqLWw+2rCPjiRdUUBXkQChOiUUGZyXM0E6O+t/vZlvp7rPhr90Yk0AJpKWTSJ53I2Nb9LBFRkMokd/MIkNB75ainuEImvCja8wQWeLbEC5ain36BswsXwo3ewtthJJSmNZfX54117sCx6JeA12XVTXvHyeBvJ91s2ZlHSHGXmmu16t3yk+TalIsyy1J3BzFPV1Won5SmaeV322aMkxO5QcYPyIVdefIEy7adQUA863sNb5o8aFB08tZFtY4T7Q1lnILPcbSRj3fa1jP7rTPKI92s6jqzeHUOlo7+8Z9DX7KvsBR5uBU+ksWsLPeXTbp5HIcDMw+WdSPYxfzEvZRh+Xlwh77KU71m1vIXiePop3r9nF4BVz99SJ5foawT3iEMUVzFhlF+fo1I3++Hnazp5chOpy0Zb+bilEfCpzJm/r2EkQqg+PN1/CW5knboQwApui5SgDaNmVObmDgon6I2Z6+QeRuMLq8fh5U75517KShonp1TNhVjiqmjOQZc/0u74/QrtQBPd3NYhuuSn/RYnaPqAThUDX+srSc6trZCEKwqMckB6D6SdTlONPX1BT1XHtdqHvpbicaVb8m8jcm5WrNMCQco2S9uGRleCLJ5CZeshzzQnO4Dufz+Ztu9nBjSylwbCN73oGMF1ddVg5VuaWSuF4kpV4FZ2rQxfQgcDfvxBEgUjQKbd4ne4LRMN17GwyZvPIVKnwSnhhvfrW4rj5z0ZyYn0krUvnI6zWrh5+aAp+A2J/zyW72VOGnTtDV7tm9GdabcrfKWzLNgucaDfBMQ93bNDBrTS4CW4ozszOvfj2VZcwjiitzL0LE6IJBsYGETfBGAVTTO/MwZXd6EZzJJMXR3FEqTSkAuQpivu4Ir0T/kah/VOGwR0MocUTOdT/vFOsZVr9H5Fm5VcGZJ5/qPQRHt1Ry+IoGAbge5c2/ZbLCtTbVIK1iPdwe3UjTvDYV5A2GITMZWJ0+0Eky2g4HjsBD6WQ6l8mVN7XlqSJCDzWNDwX9BR8q7Kaaqr4AYxyresn0Uw9GkGBvCbPUHckkQeiEyjFcRT+6/hvzROa0sgRcsBx8OZsGrn+osFdxyy3WNzS7FzaEb6nWrEs0OXgKqNk537kKv1IH6eCvqH+kaSxc2cMQaFzVY4ApfuKBP8WDS+5mxV12UTWQH5SMJxXCyWBQuWRP5Sb8OBMgl1LXE88w6+3YlJd6ydaRzJgZGpyneX0p0BX8tY3zzbYZ0S2rsgshrOZp8lI92pikOIPlfSHBjBku+fVA0/hUHd1b+M0ujjy9oTVy/SIbWdQ2pQ97kcBpbQczhjjiSpgEAW6TTF5V4WJl65YY9YOKufKGNVuOoLBHTclRz5L3L/abBccw0mW1/VBnhvp+5hw2bvgtBnhzyvh+pml8CFG8teRR/68Wa7kU0cDxaiw/7klMuB7CtAywhJBx+42orMcsYISB2bWjyA3HqN+80OI25qQ+vHl4iYQo+MkbCh9aUAliLRiJZ325zso3eImbEBSNEI5Tjv7Rbhb2pkfEWh4a9X5HVZSnHJZUcS/bWgWYwUcf9cmrQwnsWIGWvC0nWrMXU9SoV6F6RD3lG36A6qm+zU0cUV+/X+x4gBYJFHF1U0EtU98WN92pCSm+YzGD+X6kaXzoICGySU7VReh1LcvuO1lxl11ULKOlDc6+KxE9EAayZycSJZAX6IuO2somq2nov32u37RkedGKD4uA+lcPOkbgzorJWGBWtfcsC4Sn5F8MQ1tiKwvuEeZmDCc4vh9oGp/Om8SL4Owth8or1nccqkUq+lJ+8By0XJm8wGW26cgsBRGPkEESR1mvlfxIYZ98T/V62cLJaRDXB+WlG3HKOdzLqgPYmCXqV8i9XH91iG6CMl7/9+hFxZUP3bGSNr6faxoT2JJK+uAKc/7YyoI5aA6bOlNapunHfhb7WeR6+FkucdID/KXDIjDs2lBlPlilIdpY02b0AtA144j8EyV8lld4bbhmXdQz5qm2y8lKGcy+U049X4AxCVxZXif1/XtNY9mDf9R6LeZ6NWALJPGOQwXpoV4ZQVhUdKY5K2Ra+TxJv2hwEY16QBKo8V0d5UYnCa9BAp7nxlEf0ThsWFEJj1Z4bg4qCI5czikEyvXGoiuP82CToK+H9f1c0/gE9Ow4xHZNJmaNCZXTm3NMniVCXW+dGtAp8vGmpDozbUwlrwdCBQ7QeFG0uBmfma3UOmrxj4wj5PyNm1mly9J3adTLBri4lFMU9Bc+DkASTpX7l6j/169nOHzwHUn86HS7jUUSOVTFwZ5aQZBFcTjgC2rUyyS4WeJmsxvkOoebWXfyKcWE85Jhwqj6WwPYPGBMMeAPU7U3E3msuHQTfEadh1fkWllxfNoJ4X2cOgX4ftDNHh9VMT7UYJYubjMSPzsqz757BRxI1i962bYvnoc0qPlkXsZrKkr7/lv5cRi9MgKmKkNoZ+Os3m36zJpwpLN/qcXmNtJgTaFPa26iviJA/pwhvUBEIPlcU6B1eErMI+p/tZs9VR1BnUk+hwosul4qWvIAZ7l7MMLdmRPrrtSyPivyRkj582y+MCikZbTzZ48kcX463MBRulkBxzM7JCA7MJUZNlExrh/BuELAwrVUvqyvn/g/xx6fwmC1iQ6GjgJl+a5R/9tu9rSo9xsqBDyMxOPsrKgSjq/qp9Lr1QM1V3gMLigcQnOJ5BNru0Kuhfevx2cePYcKUT+6AidMLtUUwxwbdDrwEhXj+tNYAWxwc9DFCgY4wObk6zzp5dqGIab6wqCnHdXNh0Ulvp/5zYraXChweGJ8HEcvQbRotO9xL9tMErjAKRTQ2RMIJ0n1Jno2Y0dRq6Dr9XytnjnIBCcU9ms/ueRjf5MqxXsQZzv5YLSXfb3rHlwULORD1OEZUn0NRYwROFisOOY3ipg/DkfC+TzoZrmuZGp+7GXVJuDoFF3xsTPE2OmdlZuBZZEOkIfxujLJrRkMmw/lXPVlPicV9kIPR4kDOlXYEG4W9TBfUxfx1yZnrz5U/2GS/+ZBmuMAb3jG9/+pY0iCdaesygIo84EpZeu5nZM1JYfj/P6t36yDGCPavfnaqXZILaieG6lY1wOL0B7/MuHAOdVADCErJsHk0yETstATOI8u7qEUZfg0BOtLihvehCj2Q32+EPWCO9vEodajwleVFaWo/+cKxa9UwWXg+gafTW4cKez58ER89Wk3q3QSGDXUTH9qZaPcTQacCQBHZf5Ywdi5iBct6ZO0tiyAMHOpRttXHlyGsCcZwymRKdaX6J1R3QG1bwVe6hxhc+sSDCdhrsmTevpNmSOgsJez17n/KNP6ernUUxCN9H0KRg2TPOSsMUzRykF/vd7f+80CYmyg+k/oZY+jg54VdoQpUQZHAr7LOVfUT1j9AEMseSc3hgGJ6RnzP5QAsxN1HW1nZ4YMNqwnZr7wc1Ts5v0WoZvXW9L9xkklQNUs1dMTVQ9lnnZKw9eLCdXNJJUdBrr24/N7v9lDKCWnBP3plRHuVf52aEg7uizrzHUSCRT1Jq2RKIUmhnjBYtaEpBPF2jT/oTtnVhGcVRgHIqztinzzh3HIAwb62XxSaGzIOMpcyNZR8XbwOv4/11nsLKh41KjnVkNHaYu437H2LXW09KuvB7tZj/mL6k+Hqp754nLBpz5Z2EuiLz+vw2eL+v9xdm25kdtA8I65jCzlAEOC8LdILPItYC6wHAi6hxeE7hKx3ySVwGMHuwjWxthDt5rd1dVVpHUWraEyNbUY9Qnurz92cTBaY0gvdckiHjwTyaGLWzubV8MjocIIsIqs+vawpkm+vhj1n3DLBppS+A5EoEVhHB6hZRGW9ecP/GaprDkN8YyVEbi0Kb1HA9m4h8wc48wyODdT2ewZuvE19bCPX+SUYxK+w9Ww+vavnyTZLSrP9BhepO+WeYh0sKn7DvusESlkEwZUSrOx8eHED4d/faYeRSb7nZJpUiu7a6aT5fM5TK5/YzYreiAY7sMSVSllnMlmUd3KzRbVsLIJXWAWIRzZnEW1s8gUPo3nCK/p0i8ouF6S6pn3biQ7YIVwUUICDZ6ey2LMAQiXnyYVdN3EX22Vk2eVZKjq64m8XMA9pp2mgc01S2df8Nwx5/9kNos6Z+Vs/ZRJwhjHgx21nkHjzloW5RFaGk606gihUlixwql53tGaZFPlgHbh9XVwA2VVA1kn3jeUMlMnVFDVV/L2puYvqja0odO4XL4zWS2JTrsxJ5krgHN958S5PnuSYXZMC8lEPxL7ChY8zz+ZzRaq7Euj/0S97D64gAli3PNwWNK1TfSBZ670b9LVSq43JY5DidIUsMaxOjheo95g9xz1lbv9NOsjknQWWlQTZ98prQN1k2Rj628CUn2k2rI4nSmzvNUuhpcwKIGor+H7fjeLrnfnyUr1J28OclVfeqk52hhs1M6cU1Z9vplO1eYVsWOc+dSpIEZ9q9wdgT/r4LE/ykuWZVH1k5dtDYCz0XiwljPTtjUbmiTaTS0XqZ0tm0ol15MnBiYg/LVRrmXeK7EBD/GizdgkqJE7RP3BuNfXe7PZogLSRzlbbxJa2Oy0LeWOGaw2xX1tOHhE6A2HDqPeZHmJeyIApAST5qxL4sQHIVYY5xsxiV1Qo3XpEs7GdhibsI2vJss6fc1mPrUSgHO+ItvfOEsCEdRq3zXqOdWfb3eztqy3aiCF0/19UY9Rz/skt1quDeWMlsSdBn1yzK9vkz2QGvyVcWoYpPbsk4udDoIwjZ8C3FgHHlKhgPuAtP62il6KB8k6WeYZATjF00ImYAnRIPUIFwcJe/JbB9wxvz2bVVeeUdzS0IztLLz1aDAYjhulWCjqCazE1R1Hhf1g04ArY1fUx/QBsfCa5eBXYIBIYZls0E8ka7MsmuTl7GkqssnNu0xS3mCyYYOMFQGc6zfOylpI6FE+Tqb9MVU+xGFeTdvvzmYPruuJarxbvTPlIpQeRwjIumxQSzfSEVgslwpLGEYlnL1GT5PZHsaBKyHNn/UNfU1GvHuyFsDuoQjOlU4qt4nDXrQ/SFhxI/HWhf0aZlkLFfYTz0nmAyoroa2zlrfdoVKz0Z3q7/M/utn/yfVF5Lt1QHW0OsYGOOMMTyycxl32ZofKMG9IiCXxHZws90wTPYqCBDz7X/AAit0gnX0kP87gXnZnFp0zlyHZm6if2Blmma7DxA25aUoNGWG9rvejpnqHbt1Z4WKT6qmbpaOhVH/8aDZLvLNyHp0ygiwqj56DgZzXYHLAlf24UdIqozOVDo2o3K19e+LV7Bmq5T9Wsn6dmIN/vXkJe4RvSMdY4WEWoYASBw3en+gxPnuyA5ivH4JdDFH8Zv6npgFfjx56O99MqLiqz7vpZwnKOd+ezdKSOJMR7IDKFjeF2ZY0H8n7CFvebA62ClAVeU1w8jycak8em0wRUQ81HL4aj00S33P4uEkzW6/ShdynxJDhqWKWNLGiImdCYh8Qyvf8UPO1+jQBZpqQ3hSoHfcK1mczHiUsXWCAn8xmj1L6ZlaU/o7eRzwQtz6INwnD9flmWzaq9hOilci9hqjHGUlX4Myiw5F+wXtCwB5lOtYZJgIB+T8Q9huNQnDu1HezfPgkqY7Krh+kmrgjQXQV3k5FdQDASTCIyrinLF5U9HxrK0stFX2Ut2azRbaoegpOUWeYMmSbkM1sllWMw8Cs95ZRhqwnCWlPjNauqidVEJyrzMD3fxl72SlCxyxj+JVS/XMjrwDeYng2HRVJWWLLu03JkWoi/vCrXLLXB5SWGaVArm/jk+Z6fHemvjFVPXz8YG8WgbdyivfaYag3jXR3Zg2cnYAMUkYQ4afBksdSXVkLHjIOOw6ZoGcPKPyyq2uqaMrxRQtpK+60Omrm64/hPO/oEw2HRRC6lAP5hkqh55O3dHjg9ELuE0Z9qFWij3SjOq8hj+16QNgymKp+Zxjg6629WQn7Qe+Mx7L7fhP5uZN+wvMwypuWbanGByjZCsse2M2OftY4hcXLoTaW1w/y0KifAbDYnayxrJTCUUVLLNfuKhyc0tZ2ihEZDXvyOF0TAMYlMb/YpahsS0z1oYn6fYj6d2ezrSCI7onv++BwylFPmzwi6Bp6s8deEUQMP6JLUVZfu2a2EvVQFwQyTiiA44jy04xTsN3xeMxDtn8K41WXk01dz8AxxP2TyB3swb3XKpXdZedYL72vRAnHOW9Z9ZDqc9Cg341m0CF6ON+azZIkgqL1vUnDsEKlPg0IobXdbIfXsytuoweCs9j6t+vbqZWLHMpSfo3AtJBMP0UeS3NCyCu3tHz227YN9yx7YuAg3NsxK2d7xG8g1Z9QWmIcYdRr0AN0lnfbyyrM+54KlNJkz9MUOJW7TI1UsWTLwDtUrEnBAM6d7hMxt1h+CymXfPL1fEXsoIl6GICjGTM8/8f+YLWzNVLPLC7mV9hv7PEChiNDgfOkiS1nnDlG1grNmZ8dclWeUu2gT5QCgVcnDxVO9VW7PpugPxjCgY36d/1mCzttdgwcFBcVGME6bTb0Ysn3YTASt2NZXRiP1EgBjuA7T2Wk0kfSP64Xba1xxImH8wRax8PvYWV5BI76zsF6MfZHJENKezpB5n1edNVgx4AQvOysW5NW9fbsd2OBXN70m+VFWW1l+cwPmckeA/0ps7arHrs0s7nJ817yDlb2SSZ87t5MOYEHHW15pg+oL8lLvKZ6xg4Zwahh/1x4qWTb2nNn5HjbVMB1FpFWnbERs/5KcNdjloEuF4BWn+zuWlfVY9dTTta+Pd7RNC5KrS+9uiVrd5cybIl3QL0ogeRxSOIdk+kl7CPb+UGq974/edjgo+3LNH1WSOk3qhhPH1xamibar5tsU2GB81zMRUt0qMW4rSXR7JOX8QTgwGwQNRGgLU9JUz3V0bsJ+t2sPe1HeU/TmHBLNpcdjTZ7rmVmybNW5i/nXhzB6z6J54vWO4366K2jqDHaXNE1Afm966/6LGYkzK9R6gwRkqX6knPOtj2HbC/WU/R1H56tdRCFrK9F7rKwaIDYKTxR0AJ668bjsoXquZmtR3Vm/31N48JkS0Y9h2629FZU2SD1atMg/90hN15VEqDIoVzv+4Nf2WtzQoMk3Kia4YciU2unjEfM9df3jHruTD0bJuPb1igqGlSAKdMeNR5r1v1K4jvhrDqFTqj07KWZracVHn/9gGms6k8c9LQiPqqB7NTONSuzPA0Pg7ssLWXgQiYWOYjbiIpZ11Fdhf2cVDhkDfWNeRTt0GglX9vruz7MdBwqnIGTQLesnn7ibViqlKC+BC4C0ECiY7cVWK/T2pKw+qBjWUgTyIU/Mkb9N2ezJsX3vWwhWlXTzWaWt2yX82lRNt9pgrB4qxNXMzj9Chinrptl4W06eqyH1joq3f8gfGZ7UM7SDQ+KFgW7Zpb81nTTpI1i+ICH7rMeCKEI9f3UMkwhnNzBljuB9QdgLSW43z/oZg/e5TmtirHSz0xVj6uyLG2p6tF30gi6oqxWDQ5SDbvnmrCfeWUwgYJ8ZC2m6bNeYgDjRCOhzaMxu07FoHEH4bAVTJtxMrLkERvOwc/r/IGpnj6HM+RoNga7AuegRE9qQbkmnG/OZgu7rt1FvSksW4sMYeB0fWxnQuWNjrFjv1wseuAXMJIRVmHhQb/F++RU2teoj/xdTHHV6p/d3bLcUi2LrrZRM0tvAhyTV6C5llpaOl6QYSsquWMNH4N1aijqS6U3vtHNHrydTxpQhm1J4gjjiIqMqLJqW8q67K30UyRlS9aY0bXYcS6Lc2mwyKmSCBj2M7zDmfMERj0L+PpW5XLjdbUGrX82Rnf1yuYXCtgghN1dYQ/cp9NjQ5WRKhd1PIib8A1siVV9gf+7Pvd4T9MY/UlKK21ZtLK0lso4GROWq5F+kulUvybuZToVdXNW3P3a8SAzIIF5oAJpcNGej5lTtMn2LqxWw36ZNjatblI93bPqwVNhf2iI2az1ejNuTRB8yTkJoyi3bKA56J4tXkyNz/X3WV/v9zvdLOUchG9onUSqerpmGxljI3kmlsqBbH0HGo5XPRaCvUXJmO7Y2A4IZ871AO6wvP3f9Ql8SSuUTTvhu5O/a2c3MxgXhp+ZszIURTTXxLxKqC0t7QyfcNNQYbLBkgTy03c1jYvSEY6BYTxgNwao78x4zGC21ztz1luW2U+eSAh9yHNdXxf8kvfiXIXR+LVO9sGnHL0a6waE7Ef47Nk4axKlOMKNGZhhUA/6VaGzQngxiliK0Bw8aw0DR2QM4LRqfZPz441utow2DbwtS695qwfCwmd2MBvu5EBik+tV/gCh43FQspIFGqrK0R5KmuCifcyx7UJrpIJC3yqKRISe/Qdev+lKeE1eCMHhpgAEUK1vKlQvJAtn1FkEMbVBT8R6ICRfX/6W3yxZ8hxHX+KYqC+tIMjAOiMEJ7R8BC/ST4LVqyGbY4qxj6bAWclehK0vKerjOu9n2V+z6IPLt36wN9gq9+xzrHEWi1tW4g2Q9Z20xBRGsPj9Ss5EfYpa4XBVz5w/bfihn6qf99/vZg+zKK6dLBc4R0+4zGzj3vLO8PDDHQMkGh1pq6JEsFm8QS5XUDXHGRZxBa+wr2VEUqqvBD15R0mNw0iCTfWc63lvHz2uEnXFBMBef6DO81jV49vyKpoRSFPPxPyOBc6VNXa4Za8i6ZuzWUEPihT3Rhnh2AdDHnPFuibmA81mbwwySFaxyfa4Nk774RayTGLgPsnJw82w/kvZteXIsdvQdfXK2tUbcAlCvkuKF9DAbCC6KNQ+HBRqL2mRPCT16EzP5AI3ticORsOhqMPz+FV/9FoaUu27oZHAatH3VBBelJhxBRP8/sBQRqSQe4Wn/2aFKAsthxsGTtmN53oCtbzq0Z/UocLHr1mmGHPBv079sEWjgHLtyUd9QzcDTmRBQycmCaBb0o8scIEsQTfW7tvK37L4yVMEWkZ0Vb7H2lCTgw+L4i53d/qyFn/2wKULGYSA7XVpS4Qizh79Ri6TtRLNjYEjpie7o3dza+Cjp8/5Qd6sCEmOaxhvvIHx2fItS/GCWch4Ok8QDcdIZuwKv9RsHjjthLNlV/U5B4w4OWyp1kJpyHf7LkWPqB7GyGYMKN6TPFS/wHF7BMobt4L3UwmtnuzOttDYsPiqB9H14qNnVslPdrMaq3w4NgJiB9/0elnLehNjtnN9l9LgnLuZUq8eOP2Qs4kPy52DT/nTaxThUi+hYvZLdDgbd3ozMH46ubJv9gRaatUTszLnWvaeW3HYJcvOPqz7SgrgrK10UKD6eojxOAnVDJ/tZk9jGLcCKvNG0F5/etSytDLxVf+ZoGcs1wy9ryWaTYPVb9lleC2C6WOttdB86e/ZsgdVWam8AQzvRyMr+fpyDyq2rKc0mhjhWkj95nUGIVmrp1s2eLut4qSrXPUHGXjTWF8RoR/kzR5CRXBT/eG1+cc+Q3B6oB4q8R69SXbPBvUIzkm34j0ZQfKn6pOWRxyJ5awfVcvKUURim/z6EJHrXZaHd3FsHbggEicLLogKZu+kE4VxZJXVlBz0EmfWp5PyMGypj1kW09N1uVPVc9Tvj3azLFJup/pDX7JH95RFDlUjHFTYskVwEofGrmsfT5LS8JzCSM85MeRSw9paUWreaWPikYQAk6i7U1U9Hs1i1kBjc6O7i4/g66eFcVh+oJ9Npy/8oEqmHIwM4Dg5yckq70rRPE4iY4ZPX7OW9Mg20hYkLphlc/LFByvHaJl3IjsbQsSVatm41Yu1Ipt458nxk7ki+0awxzeTd7ZfhA5q/dVNdrYozveMBM5ee3RVT93t/keYdOQUer6KPmG+Ef2FQ3CiVr0DEi6t+iLX7Ce7WTN0HRdUcEUYpkvmekbb7qilaBkbDs+VjZNrXiECdGEvNtVndTu7ix4/JeiTl1fZ70VZYzHAF41SvBTDacn1jnv2QPbRZj9eWRWwsdZeSPZo4KrPyGdgGEG2FfbKZ5L2azo66c//+dFuFkJnx61ny4VuKWscCJx+a2a8+uEyWOVL2KNAlivjZjbgtHmBfCrsjwgisngy1mfVQV5wQn/IkiYrC3MjJDy/ev3ml8freboUC80IB7c6Zv9DlyoWv0rCwWN2N30+1rJyhGUl9Eyq/tvd7Ok4xhLve3hry70zMUa0L90zpVeTTCg4Aa+p0PnVS0YG5pswgGcba6bgQgHTyyXSaM+2LyXkbELyu5gl0G720b+nvlrEeNmAFuUtMXhGPlonKYkcQLTmzVbiQDh3v5aVo0uyh1cAACAASURBVKRr9mevWawHeaw3viWixI+Wd8bSrVIaZwTMuzMEx1J99fSFkCDE+qHsF/i5il4NDwGy2U0spuTnrBiQklvOvan6CZTASv2nWnVv+DZvMcIycRd6pSP4aM6sPBxjbNhPUvWvQl3/5av++93s6TIHh6esxytNQ2XyuQa5lMzhvuhdv3Hpsnr2zVYWEA73+izGWCHbI/g1cf6hbs8YodwMbsBhzNg5ITS8PyxmWR2E/OVXF2P4pirzRbFrXAcDz7i7OmcEwlxOOflXKV40dfzoNYtO40Xi56Hu3a2EqqD4O2cEGQj61axgCEHy78Q5GlTjccLhJsDpaxbCExJMSJcl0mwf99UxGJam1wte33ccHx2+bZI8ttBsLw6tZSOLAHEqpq8sYayPsN3yDyrcsfWoSryo6sMnu1n1AOF8ksvrqKAXPHsAZ0cuSQvaj44USelmYe0fs1L1YQSLreq54UhClT1+t0wNUEo+C3aGeK8HQOPHnO36dKZ++n7elpUgy31bskE1AlzmpSP8Od7ZIe2GynNdr7/a6z96zZ6CXPpwGFlQjYaiAtID8tCpvrg5eNbrXfgaG9ZDtdk4EHGT5wzShTzhEAOZzHk3L+QZEbhugfl4IEEwnGePW37pRpwN6p0B1EKg6O+FO31pWn1eW9TIcZ/q9UCAGzUGGnGk6r/dzQqEc3T0YucIcjZaniItR0Yvm+pjXGdGLEa0HDGcnLvN7GYdR1BFrXrr9/5K5jUuu0lgrOcwsNluFlCCyWPd/+nr+1mZnUDmG15bCi1Wai2nbgV5uqn/Ka97tn7Gfz7ezR4SycOOII6BM89piNLvm6le3IfiPGITAFqbOIjzB1a/uPXgolMLzCxDcLbHnqlGw7l8tjpVCBOnoxk/9Sl7F0px7r6TyQMGLKfFgAOKncGWtdQPghDkkNZ6z8qWarabvU2espITcE2qvnN+Mg5IO9RL1ce180ZI6Pg9aGkhIhMIR7NJpOFwh8p92SMgT9YkSzvgzGBjHezp5DdvA7W5uLvi2ON58/5DBXwArnpW4kDRvVYURziX375mD2GdHVejJjHi2ehiXNx8g5SGCH3N7ANNHs7RYmqJjUma0BHg8Feny0VxnNBZ0/mXwLK41NnZPWuhJMjfWYbQYKy/C762dqyXnwQzIJJblm3nuNnXGecnu9lr0uqNXTxycHrYcoUfSOxzqEJA+leXIx76Nyx24YvEKbNdyl3jNUVvqF3Kf6PudM1KhqkwuScPKnINeTi7oebsuTqCOrcyLlWwzgR+0zojsPxMaXnrfp0r8+u/f82KBw6HNEDuDDsQc/D2Oh6B0KIn4KxlLe/ieChJ0CE4xPxgFF6mnUFGRWXMk7qku2eBfiaqq40UKHjMIj1g5CQ8ns8GtvTOZ0EELMHywlkM/Kr6xRxdiekavY5HRnrtCsdV1re72du4obKtYNvqzeLPp8uWjnoGZvfAPOOC71BL3Tgld2UGPXOUu64Il2zMzOBM7j3WyZ8N5t/zOXKNySfEk88Yf1DPdsxPpjNB0FDKi3l3u8GSnRFO8u/26buv3/jsNXtehtUfSqzHgEOsnha5jGaC48gItprV4zdxOIuncPxJt04p9RScBTguUY3FCERnHN6sBP8KWKzVk6mHA+w72PjBFjiPu76oaIbSZiNU/ka+0JFwDKQtrtWLeE3GfDLc/++73extZng2Vv1kLygXbLGAEnNGEPxmGC85vDIFm+sTbMt+8zkmN2A0gD2/Z/GmCphGhwfwq96zX87CBaqd7YVx+fAcHC16/oESsyHIRoTquuG7Ib3eVb3ckErRoxN7Hecnr1lNaXByWdNQWd/vllSgGNs6YYZaglUPGkhSu61kY3r78YvfsvxIkhFHWw54yalHHqppHC9LFj/Xf/WMy6fxu5t+w7uDwIp2PJ3oy4urRrE6INlzLS8hJTC+WwkhB2eLz3aztz5dlpk4/ZAzc1cEZaLxO3N72dI/ZROEr56Cg6XgbxBxQksyhhFcFgw+OzZOz0yGrnxr+WcTa5CHE1KxMhkTTnLYqL1Z+Yskg4bVVCyu/ogFclG+L4ZBJuPs5YPXrBoinFfr/LQLW//oOr21+kYiPsHqgy/95HbigC1x6GmAz3iU5wGnHtLmb8M0YSXLo2qxxTiLGyZSKqt6a/Q8b2VN+yqOzenHev1dT7WE0IyLleedv+92s7d+qIeCUKU8eFPZQ/Z0kk30wb2x714nkTzBPIw9HwED5SgQx8DiPgxA04s5dK8vSV8Q3xD2n3tOal4JUJIwg5ajSzCEsRbx5edM5U1bfYmxw4vds3+X9MZqmvThblY81/1S9tpR9XsvHCw7wtccWi9o6siqd+mmQvA26FIz2Lq9rMCXmzZ7fx2yEKXb5qL0iTTlOo67YcloTqM5uc/7XE78KDY02p0tTrfGz3V3801ljnCT5zsRbuh/3+1mb6Ph2akrwkYuuzPZtQ0BK52hK4RkM5n4iuFGf8n15RmuozcCq9gWV/UbTieMvNguXpNDHCUQSe7Y+pdWA2O+Dfr/SZC1TYDZMrQObL2QFcCn7UlpBhwzoxQGGm9q371mb0M0DEyk/VaW+/3gBxLHoo/u1NvT15Di1S0K5Q3LmV9pACEXcM+WYcShJ+3w/g0+4iTfJWPT87zr3bHRdyBvDwuhTcibCQnUFBf2xTDO2qwHWUMV1blbttdoPcyePOjo57vZWyMRR/iazxHHNlxPv3F+0uWsj1SGgLA3dA2mnIVqvIV/QwdaZomgkiZOg/2mw/eIdwFWk79UogSf3qaefhC+2L9Yql5f1WvITj4RPO2g/lNny186vYmGKjadXqsfa8LXv955Gt+GtWw738DTaBIjHqHPrv/VWn2ZrqdMt+Ns01OQiLug2coDw3uxdFnqEBtgnJD6VW5iQ17J7azEwIUjwtxztlZ7ri8sTpRZ1A6D3lBJU56DWhMBoPQDTgfV4zUrRyRHT436QNX/X7xek8T7mf6E4dmwLCkOxvF6WQUvW+kg9OLqSiv+xRPxmuWGbG5Ud9NlGDzus8yqWX+OJKfaY5e11eeHVj1YnAjrCHgzrB63lC/PvaiwoCqltcARDSGfI92O11sXqFuXjcHO34fBlueh386z49+w5oin+gj5blTa3zo3+sNels8eGM5g8Sf+Q/La2WTZfUfHCTKABz+ZgKzArZtUIghUxm5W+g33eq76JC1GSBJ6+KHzq4ha9cKkbtndh3pHnJrzS794t5u9zYJ5jn49pVTXNuVUwRub6oGaDb3e6jysGiBnecqdk/GmMI5jJPDySSH7odtb1QfEqS3cX2y4pHv7i6ue/lxhA4l0zGIya6LQFU92jPUFG6rSuxjT60eCxXHl/n33mr01PiBIlrXJfvaI9QZE++4GnNWSxN+V/crx4eaLIBDtANQv2XJl3YTDAeu4lH2z57/JueOv9WgpetzcFind/d9N1QcNEmQfQrlnvWFxvc8oHVcGnDi0+tPMaoT7x/Li1+H9/X43e5y6nrVmr8l35zlEDk7Ushrf3uD1wXsYKzwSfGI4eAatRlwhezMwvi864vRVX3+aCqRyVLc1R7wGmFjV8y3rqz6rz8fuiRL6/UNpOxIOlIPmWL9bY+AR5wKQc15vX7O3wTrdhZNUWMKsLRtqvfFru6fsm6oP2uyhn5Lfyjk7LU8z2fNbyoVQbRvYkQ7IcVVPVkabrBQXir2gP7KsEvo1Waaj6kPQp9j/GLu240hyHLg23d+6cX9jSQ3bAZFRBpDUGaCYcWC4UdF+zEWFfLkmkAABsmp0/bGxrZW2JXY2iEcik2tuVWKw+G4urZ/aN7pDJc48RMVRb6q72ezfVglEdsRtqFfW3+r42CZL5WhQ367ELaPonCW9Z6N2ztbRrDq4Z0MfDtmW++anWBoZZ55ZBDNv7ECreyV8yzrUpzdh4QznatY8EtTLOC4x6jl7a0bQVTSMIa9oUf/5+fvravapygjWU5mVu0/IjRzDXRb5DTP/RHUMk9llmSR6A6RCLFLaURJpijQNqdiHkdE7EpwR7FfUU2kcYMFM38XxqVBRhXIWof71HKjvNwTz216P/5CLQWWtIUX9Ia4rGJToZ1t41sdT5Zlo8+MpE9qzs9HOr2ezQw8EUWfE+guDDNkbtIpnTg7kophFFKY/DeIULV5MtzP4fmvnkupPvgoWFg4/D+KaFAIE1l///6xeswj1iDwccBJrHQns+72bRruvSd+SUD+ikAX9gYTk4Nb6SWv6kmae//5zNfuUW/Y5lJ/QttT1/OfqF2BWB2OD7BlpI+yrt+8uoOcmCRtXHiyLfkFFAHfVhPuNo0g2sd7YMbMAprBwtvFOFU5xqJzVW/axcckV+q8jHyPyq4kMDfRwUMk2znBqKBcNHAgzDcdvbeZw2P/jbNZ0LCcVnEP1EZbFQUW9KWXhE9CumghNxf4IX6SSW/YIyTlToGahrFaE+rpNqLffPgzbOqmqM0H4+wP0QShtf7iCivzA+g+ynm7iwNYfTVGfnJEsV1SJAg4+37aBQyNB4WHTMeI9oWP9opr9fKKzr4MqN6Oae5b72JZtk6AriE+ru6xes1zDJJ4DcbZ8uURVgfjsUK/BfhqKQwrQrLHxO0Wtgo21dfWW7R5U/csU69+qQz21stFohYRlU/2nsTkYndKc+nU9jRzlwWvjX85mP63c2SpZf0xbJXZH3FkqN7EmaUaFJclztiYhXUVOn3vEuXHlCUC9lrLoJGTXJNZbmS0d+KqoahfGIeUdSnM9+rwz/4nkjPp/jYNsiViPJlMxRBBB/bUPlXgqIzA/3Z7D+UU1+0Qp61wa1Ej8ciq+izLCAH4UKZZ1YVbfBr4eIXSAizZdzZro/OQYBfRh24YTsv+kMLHNJqfMguovkz/YeLOnVvxvP/pPk15gecMwrHZzgNhAwknGZQ3UsyLuWGI5eDiLDJyUnjyDHqi/ifWnIUCt5ms6bPQDKllem4lnV7oIA/XixFOx8J24UrEqfzLeu8jqA1xz6kXXp8Zi3+MEm+Qe7F9PftItSwXUg4eEgvrX9+r0hXJ2UBFUpFpzOBSzuyQ4o4FzjLnGOKUTyz3nV9XsUyg4ooXjiGfTYHaH/5fXfRJl/f3SSZy/wrUKaeahXMeqxrVsfWDqkzUc3LRvDP8q41KoRQS9CPgg5AVMLo+Pnmlm7ij86O9IR32Kb+AjFBY44+q6mH1w4VsaEg7alrtestAVPZCGs4o3P/44mz1VWHTZENeDvyLiNE1ynCBIXAk4Y5uQXJBqwoiKc5zktFgG98aFehgCbpeE7P6FlsSMgzsCQH03fo8sdNkPNTO1fuuhjwVKk/O0bWwubwazHNaxKB7bqt19CBXY9RnPTz36u2r2HKuC55TUXD+8AAi43LM1w0R9Ks7MN8osr1TJcdaTHNs5YUZ9uPz+IlYQ0pgG6vudmamC7UHmnXZoX7E+cqz3xrFxT1X6CMWSD+gt8msN7fBjquXx+amx/nI2axxkD7cVe/osvpmyzrVsWpsXZA27WFeUh79sEiYCzzW0jWMQL6OpUF2cz8Kbz9OkCuv8srCCOZjIeffXeutNnK2/4gMk48QBJ6lBGVJgzIvj8J2Sv62ao1eZwf/r6G+qWVF3As/jQu7mUN0R1HDYjtWSdb9pziclgBCEkq6UcIThdZISp2DPBDJZxFS8D60PCDZdwV6kegvLfPEPfO9g773LbvJTQa3fEkkfB4t5yo7BgjMNtNhEUDeUZLSMZUrY1vPaNb+5rGYR6yV75zv6XP3aWduLtJqPRctyMCtnph/YxEbGcrTr2d8SRpsG9cpCYPZenRo4WYYlfu0JqoBizwnV5EKo1nu2T0v6v7xRgt9jfepHX6NFfCSZhX4F1WhNBtX103/vopEwrCsI9KCE3FazxymF2OxBsq6E7/tky4BmzZLQFPW7k9UpEe2m9CZFkfeDwknRwRTPZXPW2exYQlbSfNgmtlMeXoUgFnCnjjVGtw7V/LOH+pre2VT840csEuuHOjHJLMjKilZV+Ot6yhQN7PfBuzSji0HLE3uv+9nsUJVzRDM3BFS4H5P8xx4v4rw6DEbDo4f6lj5RoT8H+1qzLsBWB3qsgLvM3pPU/DIUEQoQ7PsHIH/8pPD+gN1pkIATnTJ0AusymX6rpGa1Bhfpm64st0Wb6TieSua7rWbRkH/e3xbcJ9rN8giHehiuXaQ2aRiII2IWDfa8siGmPELzKhPpTB/VpDg4edoBcVlOELlvlW/hM4XhMq1v/exAj0TB6dz6Hz0Kqg64kAxAXeOKIY3bdKchcq5Dhll6hWRXsR9DfE6FpT+fFvW3sZ6S0ueyINgOfVt3B/ooojerfqvqrsCbYVDVh/cai7IU6bNz8zLr1qDZJsnWVhbma76LY6n4trvfX+NNg30/8++vf779lDWqaFGPPykZmSlL1ZJQX6PPhkyGP2SNVdwYif3vf91Vs2D0PbGDcq4xnmtXvzEFi7t2mcsr5pHP6MStiA1S4X6laP0B9cFsDKJbKYNZRHzpRm552u1mYqb5gJC4+hsTjel8X+CnkI9Y34N8Ijsxc7pVrVJGF0cfr9f4bvzvdnxQjonrbVZMcPS3s1lZ0jmd0s0x0YlX3sGuOe+8KCiNv2R1b0b/DLF07Iin0XMEyzKrL88d6m2Ko11Os0+Ssx49B/uYP/prvmNnlsvYHnBa/Cd7uizo9T6xJ7mvUkZCNGK9IaG58vbToP6va9Rj/rTUsLvIFB9zmJfd9UuejdEuHjoI2qkEp5g9YTCaQleBWQg6ls2+lGVzWV4Cz3khdGOKPoj433H0XemJ3oYf/dfCas9Djr6b6KVQ3c1R7lAfSjRfbLrAL9s1TmhUOjhA/dVs9vCsskmV/h71Yqq9XLGS2hS/IGscqZBBpJoMypJqPsnylMvqZTooalkT7OcaIIyA89geZFzX34vEbcvXl/ToO+qzm/By2iuUuQH6mmUlxi2MY1xn85tz5DeC+r9uUH9lpWlINs1om8FDdr8rYovNb6xwsQCJx6n9A2BxRtFe4gjL9hm8hw0nz34AYSLjaHpJiQ9n/0GOvosRBflAZhg/fnzI0XcRgxBcwsQ2lDPqC6FeOjvy0Rc2TnOwfw7lP0X9daxfWjhH01xeDI9M26Zp26atViRqMYisJlncazkLiymAvlREHGFYdsdBw70ZzXpE+2zXLbNeEq6zr8ll31aT3/D9IbuDoStQbvmF+vZr3iupWnPbbhTllmmqA256CRroP897v9m/b9HOb+LuFtSOeKUxNOfzksiXkd5wlRnhDs40veRgX1TfT0dT1bUsqQcMhSFfVAWI4PD9wN2GGnfjc41kvLz/5DVxg/pXMh9MV4g3tPj39VTRGoIldEbp2jaQra1vg+Y3J1B/OZtdJlBjYWTfZxk/NpGQYL8uaI5SNS66N6a6rUoHTsqXBOo9ydJEelaIFtTX7E7fP0HzPXI12wmX0rOGTgWjfu9H3/We/a1tUB8n1MfBFR0ZjqDeyXkj0ndKzj3T+HIIAvl8NcfaRb33cv7k0xtu2CRlrA+pJ1nSF96M56rWlJHgYCRbtXcDQa0hexCgej5sq0Ity0gsivCcpO9pKNd3Mx5FvdEEkRUXXEwDVv0l3AxytO33fQK96rN28Lfb2ayXdTr0LbyiEas2wMSptJtpKa7KH8msK0Whv9sZNpFDxr7gNeo51mfZrM9j94Q+Lt7els3dWQZq620Div0/pVvfUR//YdT/WlqhIjHl+rBAveLeHoyXeD3BJuNGwT3TeO7f7GZlZNoNxPD1poQt2MRPo2GukjfcsZEGZr0wlYUalA4Fp2b9loe/mpazQXw5qZIVg1vd7JbccuO2weul38knQ2J9G7E+20047G4WB/GCQUnRdmYcfljTuIoaBKfYN9zuzX7zFWwbimZrIu/IZe1mEf9Czg+EViQNpnljmTcx1ZHTb2sZm+GYhtYlMn9DVov+BuJQzwe/fbCn9gOo3wT1WWN9drG+yB5bGvu+vS2UXA9HHbUtP0EdCOVxzzR+3rhoGsiLcTdjab/M6NnrSIX8ZE6kK+FSIvZaJU2MSc4TodZqa9IptVdnQWj/yXq9oD6K7hf/fkmkiF4g/86h/iGhXlFPprK+mk0qApVc8yyoJteA/SKAZjN7pvG1u9nst8kjvF1BXpuVspJ8FegH5FcNS+gWI9vX3b9kTWX71JBVbwzdbOAcZ28S+7FvRbCPGg7xmcwq77pt1EVA25Jg3xPFf+joSRdWY72o8pjNF/6jelofTaiPyr6EcIh16dH92dd1+/t+NjsLfRxNi1jTtbmvXxH/BPJgwYzURhWjddCvKyTFWilDJtf1bcI25rJc0tpYrydPfU5BhIC+an6DHnHJGA72FeYQu0NnCA0ZTp7uncJanDp0S69XKNFmPbvbqpral6eu2T9/381mv33Vo5QSNpo+/UUpBXfBmC4ePAqkbB6p/USZBH9V6fEXCc42+ggwyswiOQ/Melp/qkbJuxdVJRHljyzF+3/Q9ln8JTZAU+8yGavQNcGxqLft+mOoP/Pjv3+oZieLKS7NmiWW7fG+Ly+mguiZGd+dIkvgUClT6e6IqL7QLKt26iF1hkQ+bKaSFfWgrarsOdUCUEeQT5IK/r1i/eOjx6iN1/UhIy2rDaiiw5xtqSgL9jEo1kef7o9Y77w3pQ1sUH81m/1mLGPFKlmsok0JC0PBtlgxmABvBOoX1I8YGhNFdUW9dF/o2cQ/2EwbRyO96eLI7JwTUvnpOhSgWOaSYE9SLHD3Ff2nDZS2qveG6Epp/a11St1qdI1LrSMgKT3J/ynu/1jNHruRmuCuzeE482jOt/saNpnlQBPmi6jWJKMdKRocIUwL4lUJxnzoDHyX2IxqdtRVFYsnVcpf841i6/4BZ2VWPlOzBhXxtoouSeZUds+aE5z/UXZtuY3kSHCPMLczdJIytQdQEYX+JolFfxfgC2wZBd1jegXdZVTMjHywSNsrD2aA6XbbTaeygpGREVTzDWcPjON8idDp7/dtNJu9AMafzZxOq7C9+Td1Qla+dJzpteoxkcoC7ZPd3CmNBCHxQDBMQl5q0U9Buv2A81EHdRjrXq/ItK6WXHgP8fJKUIgjhoJqXHUc/VTEW8Mkb4oSatcrra4/aa//a9zr6dPdCHaRmGQaxJ7pm6h+ZhjERnFtpTtswQOWdgQxpYWkMspIFldTucImrIdP55e4/XNcQHEXAPtaYfgnUXicBbaah0ZxejaAsSwPVTJckP5vk8VlVm3WaJkMJk3ZYzibvSgmJVZ+P3X5bUCZRRlJzb3QHTA3uRQ189N9cX60ReECZIXKQXqp+NT8EJIMcZOb4QrHCfOtiWr9g80uq9uc5lrLQKz4lVAlL7nVp0TaMydTWIS+hCWWUdzbqv9Xv+o3Zoj3ZWv08kj1GijmkRI+a1q1jVhjeRmaTTZLT3NGpWeTNOhllqFT9VLShPiZpW8YH/2MqwmmQqM/PqbJ9PrQDKlw8oa2rEUf6H7Cdxi5uC2yZtheaHnXexvNZi9bn7Pxu7DnRh8hZp1LdDIzX/YAlrG4mJE5Cssei5HTn4q+EpY8JEnNTyGZwm9GuPid7OGKqr+S1d90dUaL5suzXbIETBJapjdpIhdAhy03HWDs/kKrfmh/vrjNYjsBJQ+/Slj/b19rbWZpgNnj+SK+QLmoNX2EBq3YlkMjEuAbQvQpMFc/pdQ2cJJgcpsXZaYsGbrfvK5qtki3Ko3mCaoZ9x7q7CWQ4V4SatXP6uQzO63myR5np2je18c2ms1eAOhP0IaVfdvZQG42oSOzEpItV2nHUNbJIFKste7Hc+Gxb7GVWSq0TO2R2vts8FaYWvR0lRUXdT54CjBRcGkJIRd8pXittvqo82YLLzfe2t9aPY5FOP2qXxYP5meQNss8KPmMgo+iPMi5DbVTVWVuvOF4CE5D2JIBbLAWPuGDILqEX/iTrzVrwA0EmSeQs0pSCcktqwJqda3e+XhTnQjfVM86HybVpRmgKI+DbXk3qsI+4TaazVKvX/a2wfvr64C0IcYM0mKHbNBootIiWlOQngUJxjG+xWZbsNM+mqo/wXr3CVfp9R/c6CkeRhDOYTSCsDeDcbTqkVxWDjmbeS8gfHM2Mg0Qv1rzFef8Gd1mL7toxK1ofpk7NhPe6oMvsEA13qoVvqvx7DuMdwR7IMgVNrFtN+FDRiqJsYwWcoWCJLPnglXJGZGbwaMiF9BzBbyksw/sJe0WVcg7rfD+CyuHQsi6gB1dv4e3tIf2cqcdzmYv7RR21qrviyplXyl2wTwcVtTWrHW6idycipGZTdbXD7dYdG3h6RMVJPHBIrT3mH6ylX+V1wfus68fwqQAh3ESkdXG6YLsS4/tEvpmj4Q2N447SS9l08wuMh91P7zNXmgDtpa9kDXLUGkjS19o97xm4Wgb9v+EWeppP1AWXmXQJ3EhTM9L1SuWP+4AUPgUHlRNIkemy29777pq0TOsX5FRAv/0iUkLNTZmdVwBNcLWC2G3dCW7F9JwZkESZFv21Yh4G85mOzBeA0fmPnMQYU8cB/x8/bgZd7LozW8jqyybHi9bggk0MQhL3ZOqojVkGk3u8YD3SZKTP869NvsPKX4k88BLOkzK+5uWKM1eAM5h4rfDVfJoFdpxltlu3TRlP7zNXhbH2BjSYDmffYbZBP07G/W82PYha6fjewuCMsv+oBS7uB/wslQwI8EgGpsKqpf9+Uj0e+p7pEgO1anN146+it0fBrMfGq48Qb6fWlwP1MZVn/4NJR9LwyrjqwPyWWNLjDPUUfbj2azH8jPbEm9DZV/Uqu8AG84eiRrhEr17pcioSzaUTVFqnu2z+GSOt0RWC/aFletJCV9b93T2tugnGgdqx/8Agz8ZEsc48KipsVn7Or7Gf6w93y46y80sE6o6wcKc4W32osCG976/cGbNim7qAzaXWYsevI0Cyq6vcpwgZAAAIABJREFUU0IQUnUdI3L4EEtyvjeaPNzqSxaq6Ei4v5N9yU379ISk0+D0aZoRw0klK8KoiLicVuWCwkm6TJcS1krXAPn0u/V+1lk2WY6yIGf3G+SPfRvOZqXDi3vW1jdyUq9EM5VqImNlAa/T41Upxla68bQiqHpiqvoi+7YzOW2wZcnzxn2aJkyu5s0ztmLIFdfZ9YN9/2wgFf0purJrTexhKkBV/7uTiKyjVXXOsURaJe4/R7fZS2UfcHf9Uk6Zo/h3zjqzNzQlNcjSVZdZfaT9deZpVFTJUrPDJ1Ehxf6ACyFJGf+7SnjgVAx/Q9cwEz+4gq2noGUMZldDXSLSM5lxMYwSBAaH8OvZzaOW06dbLfsTWT5hG85mFdeYMeA2YOZlXaSRl3HJc3+Xh6zp8pEJ+RvJD/DLQZPAEzKNCGzrjup+5+hnVXT9sboEJW+abkMQh1ic9UPqnqr+Sm+c+qfokrQLe8Pfs/q73J+DF3lG18PvYfvHMKHnwhqbzYmqBgtSWXZFPDWP2IViwzNzJxEzSdUD2qNgA6/EcrcJUvLVAt5aLMvRT+Da+c/g3UI7n6rPWUI4V+LqVxuAxwj1eGCEJrAkZ/OwPb7r5/hVScrnEe4rayZbW/X9Xg+6RlBNVzcP4wE1V3GUDd+dYEYfe11erdFV8qQCM0q2p/4riu2d/ZWReo4XB2ZO9lkxJU8uXzltdkKrp55jctggXma63pR9NFkOJAb94uifsPp7nT0Ci/TsP4e32dmqDZaB9zZfnaGxIXM25YfB0Md4Lndr6ZSSH4NG9qFQSMPiDPgQHPFm2NCwjrO7eUYC0/MlQKMHOd2aip5PHgjnaoX6k5x8yyUweHt94+/PL1/4xmbrmGCqvjub5fHiPO7yUvSyXdTw8sXAm5MlWRKPG9ozS8mYJdayN6uBDGzk4fpoHDdh3sPAHha68n6x+IaYGiNHoMmsO3lKpdUZmSmJqA3n4Ovy85sXs/ObGgLaqu/eZr/CNZgKw+SA9JLm+hqREstRaoTm+2UfgqSr2VEoqp49QQMoQoI1WlPP+87m2MdF8SbCBELmE8/CG2Kfcn75KVvH4h9Qg0wW4tClOtnIWbnRHoaB/kY16DpU9+z6ujVV35vNyurx1vPO0pRY6fkdXp5GsLHbZgq0MjcahfglqOIENvUfaTa1uYt8cUfl133g/3HDQexamCzDyQ1ntb2ejC6vqsSZ7POiYOP8NKniqv/+6PEoam1yhnmzF+P40o9PQ2Zg1oVAMfhgZRk843J7hQ3FZQDY7UBX9owpp6CuBTzP55UkdtV7cOnvn6uC8sDDJqdPu0JmjF6/Cm2po9mJvTPpdpBS8iCH677E19f5/f3R4+Yx1000qfvxbHbeerqyKFngdpGiKyt7/XPz2a+3+sLcFRutMvouliVMSNTkbhEEUzZGPRoccUDMPwJPpjIhXDZN06nbW8K+0pbQXTbKhinZiJTomMsjRvXX88dl/5i3fW+q/q9R1Z+KPqslKyN5WR4xMhsavfbJGmNNHOS0A5nLi6wbejPp00HbDUd13JFmeec0Fqr6jSs8iYAhtFpLmgKuYOv55HGbVekmfS6bmZqqzy4M5f6Do3+Sm/p9W5jcXPjoB7PZ0cMVqffA8i0hH6OYaEUdv8azU026QRwZ+MSN6qX+f8wCj+OfHboR507RczE1sqlsLeF54fRSV7D1nDa7kiXIyjmzkvMrCAlWCzqd1ZjQ1+snJ+/KXnrO5/g2O7A54H0oMGZzc3fNoqPsE/MBE7ck/yGT4oBpqP5yUK0ejv4XARk2hVejHqTgbHMWVxe2ikppOkk0MaKSF25UTs4Gzx31GoxGUEwrxD86en4gPWbKeqC6/xzNZt+6xmWzXF5jVzwMlqPcBOh0HEJvIuPl+beRVU7Jpa2hc2et+rt4lsC65KHCrk3mR6WYXZTgZ1SM4P2Ati5X6dmzttbssLWz1+pm+X9Vvdul/eI228IaKJpEw0qQpuASxbKyzDHH+X1Q9K+/zfv7e2CjUKPjhq1Tgsa4uuXCDpR+/ouEC+02/lDXHSUp0z4zxEyhGVT1X2eT2ELgzUha68kfnftnVU+JyA9NYH5V/udoNvs29wMyZ+yl2S4vF7wSm3l37MS+Job0N4bzJ9vKYoLWGKYXfsfNu+S//f2QbKaH+M5uMiPwsnwvSBgeuuo1fdYJG1RJh98kjudnVc8WcrORHm/D2+xbA+TjrDA+ahSy8zooUBzoRwNratG/hyJBIyTrc959HM5CcdQM6g8OgYS8i1Q9r1/7TcetTbdGCPPo2FenXAP3A2tHWJ4V/oubfsNqg/uPTh6PIzHA3FD1ndnsm7Oy0c5+WhAREjsjfvsF4LEB+ILx0VU8LxI71JBKM5OyS7LcJyiVrp79Q+S6PQNIq+k0GmXjWcR+LCL2dmcPkatZ5Yk6kzXNnmnd/WdHT+k6274Y1f3wNvvWd6eE1kNISqx8U6llSWgh1crR1ItTyleMDBs+0g2oD32AeptXXqVBh7lk1lXXuh+5by4bodssX5FG66EdlxChMOkw1u5isVDZAHnknRphJYsN7o+fwHr6lpdd9vdfn/k5ms2+KTMzR5MurCVfPGNTu+JNJlJyeY3Gb5IP/qY7fX7xQ5YC1eGJz77a89eTL6+z/7tjGMNJEeqTCZoCqQ7hpIJqC98x/XqLipLmrt6uWJncvz964K/HXHUKYn0/vM2+cbXL/bVZBKzdr6DDxNZU4rT5ChAp+6+M73V0zYw69Qa/H0vhaJJIu/zqe2Qfb+PZTgagN7aqcO3wwtqsRqbMGuPTdCo2fn9Ms9CU7Puaryf/2OFbcaCjOJrNvomuKdIhD8ZQ2a9EUdHfoo8CV9ZGIqVKOe/3JTwRjdyMD+wwIi5YR4zz4ux9jyP/W7Ii5iytnnZLpmbjimV/16nT72U2VdzkJqoTjtFybztCSb8pefo+H3VMKz1neJt9g5FNRghyFGljxrWVRJK5fMHGo/5SsiFqRx+enFpD5MDcY4K7ggbKmC7INDlaLZX68UP4xc7KvBGwqRcyk/ZfwMrVSfMTz3XZK/zkQjTDF2QhJ/r74862Tl9UPJ18rRZaRKNdk8/RbPZttr5Nc87z+dpKY6gb0zXc52/6Orh45SWTGPeV0i16nkphrORw+Mx7Vv8Qdi02juQ6EC+DhwvhklrgEpGlBLobDkDdEQhwBH4YXCSHy+W5xSqS+nlnb3c+O2fvyGw2WSxW0UTp/vmr/MBb/c+83aeKDV9XWOx5ut1wf/a6SdK6XB3YaJfiBrrQOhe+eUCzg1em5bvy43zUv9/LbvbX4bdD2zL+Mi0b87vvMj1Lm6jV4xUfiPo6+Qm2ByshzlnsZFVEoh63cr3mEPoU6XlytVp87ikzK1ZjFPK2ndmhssQgkpzmqH22JPmdsf6D1rSidxiU/S3epMO5Q0LoveN/45bx/c87VrPZX6bb1KkbXC1aI3DNtQ2+sBszfWTC12I+w5jdDf6xj6mz2O78d12qhZXmQXvd5Y5jbwxE6REB4cceCz2vzWHlZ/cjVbiC/9yJxg2I72T/8++/lnX++SFrr9589t34UO+dtf2XbraRrnFd66mu9WA1SQV/XjOXUh6+SnDnzm0EcLpfWFhEPYI9yz4TB4/1btdr6EvQQ3L2+TQm0bPvVSYWWXg9n+Yv1aqXibmUiPuDb1AdeWv013Dflab6Fs63o6Jx15hRP5nN/pqVNBrxh6vf8fvuXDuQRuW3t6zyJn0tT1hcdQ7md8RmHuqYyuJbeGeY3Wmx0faQZNH31PKzEciV7bCnU+vcYSo36qCLjtnfJvLxDxUsf37cNk+tIT8v709LweRjf+tmT4KThtIAnzyVaHCdc37Nfdk+oEsTuX8ZoZgV3QhJtkCCOS/M30wlsFoE8tpzq+bQ85MSAuoNJhUjYlVr+uh7N4fqN2xGIFM5O/0fRr3I29ymyZ8vUgRop1DQu+J9joXAPfKbXnasZrO/pnshKORdJc+ha+sgRXGBGvWbF9cepDoyixrl2+RxsBGUyybhXiemveX74QjtkuOffunrvRb+1bjnRaK2C8+OF++owirxUY1c3kY/tRfz3HfVE2LUq2bLse5mW6UyApHMsgfBjXPWu1KNtVXp07IGnjqcmuKj2Inb+NKb67cKxk9h9YvGr19O2K0F+CQPYxtsZD+dihMgl1HpAP52alQJboYTs61Aq7Atn8z1yqI8VrPZX3MRVqniRx9YZw2ClVWwh73O6qR7DVrnrDK99J4Ha2vLMbdTcm+QJz3zCXfM1QtwfMs76vPi+4SOnw3mydsc42rvc2GIpwCnX6R6W9SLt8WXbrYpahDyjgzcRvuj9n4PDpggHK91TbwVexrDwNASIZdZvshvbiFe6N+a0OdQC697xSopRv1Fl20f/vqtngs+7p9UfnuqMta+e4PE84Ti+7WfwLJM/gyeVGKp45/rWM5mO1KNKbEe8xkU8XlF47Mra/oxFFUPlJiXw6zrTPqH4+m3dhjBSRkDbCYP4X543gN6+4i926zvbwjvRpqY3JmnmsbkBmK4dGCh1mxyy9/tunFRL89zLLtZJ+Nxnm2K0YvAsPg77C82gFl9cdArNWqs2K9hZs/fEBaseXwSzqnr/QYLwcZB/QehOB31anNXGH2Aj6PNOf169/5sDURpuYYDD/ma3WJOu+u727Y+FOWc2h3v5Wx2oJKxpMHY6ZDfNaVv0rtK1EsExpyHOt7te+jid1iefcKp1/fXgp+PWapcGw0iF6yAkidIov4E6CYbx1Pj/3SGiE1BprJQ+bp6de+GvX5011F36byPNuEsulktamqCffDS8nX8Gb0LEeQ4Hgi/mvxzHOSbLNpjmCZ9n+QTPx64bIr6i5xByyigZg6p9V0SK9xt8CzLktbXHhFtzG3d5LYvbjtBHNX0for4v7/KtuVsVrdda1mxHX7/qYVp8nap3vNGMkFXxwfV285OQCuvxtXJc5VSrXAm5AaZompkDsB7K/3K3UGcvdvXD2F57GLgHMDUt03aTqHo6kioagTYRb1Pdceymz2NQKYSfZi4xhGoiRr1IJPleGXuhPC4m7nTN1IGhqZFU044VVzBMw3qs8QYu1u0F+7LE/oN1P6U9FQ/mmkHMkKE+QnqsfofEto8oWB1wExxgIQQ+PvNlzi7XD/D66nh4bLrduSjQSY3FBabhMLmr8MBiccPEbDw4YVZZxFvs6T77Lu9Qx1+6SB3aICTWwh0DyXJpnkKchSmoc/LBuJTuFY9oG/T60PNRRsRNApC/QDEtoSz6GY9NGZQSfSV/CMCqCHFwFkmtNyaTOFtS8tfyppkt0Nh6ZXQhLwywwk+E/2c3KkL2ZVJtgaR1CvfNUiyhyJIGhhpkc12bgeIZGBeAFNtzeRsXWSeJlMhtRIHfRr109ks1+UYbhWlyRw+ZbyrgV+jfsszszSnw6qsANsMHF6BZJlYz16j3id6M1oLbvDqHqxAtzIU3SARve5Xcrpn8m31FZKLoXzJ+nPkwssAKj/tGPo0KJ4f3AhB1P9nFfVdx1rfWMNHBLzGH81cQucmYkoq3YLHYlBa6NfFkL8Td0dkkxpKEaER8ywsWoocq3Lni7gNmjhCXZtNSTnHXaISiki8YFsbr1YWStspt1yzj83aG2v3dvKnVDj/ned66g0z5BntNcdfaNy3ptLqLTEhQRybWiNPM46WH5Ddw2KTLHaHq8/zseGVdRSbZA+XSCyuSmdYH8RXEfxYHS/JaGm+rIy5ERG8svt5VenElsj3xonZc3Y+b6dS+fZjW3ez92v6QHp/xI4gf/8bHtpCgkZm86dgZusU6ItGMogLeFJtLPAn6pD7XZtv7uKaiyNYXoiTF5IvXsHZlvC6FetL1b/BTaTg1MOyxNQpstRwk4Je0Nw78+ym0jGdCMBptL4423I221fxqGjihXpm4/hpZNUEJ7idG5+61d01WbAy3qknX5qox4KzcSnzhMpKWXrj0hddJAlNqtdNErzmJQ18NC+Xf1FKsLVok6hXHxOS4Y/OcPxzsz0PW8Dclt1s17JGgJNu0qpU4SxVvFaSF1Eam3HHL0me5TsWK1NgSV9KgIJHcdMAbOqoY0lXoSa9TctqbICCLisdKBkXFjeFz5IUJu0JsFF9y+VHHxsqt8kMaRQk9NGvSAh0nxpzW85mHRop/er9R5R+VUobtqyt7mrUmM9UJ8gh5FXEp2aJO+kttiA4kYAaU8F4GT2zF3jVDG8fMZGv35jf9P1UOjN7YoVL9+fl0v1hdtLD+HffbdN8P7dlN+sJNQ+pY+qvR61tEO0Vh28tj4Nmdqlo8reAZ2+JiIMwlqT4+i5g2UxxG/dsthY7g5oZ5oh4H/i2PiWXF27CLPkt9DMkQsCZgAJgXKX7ivE6WaZZ1J9cUCCGs8j1n9DeNknyd0F/vzNkfMDhg2cLIxPkL91TUpa71iQpOeWO5FpRnfa2+sb9uSN9o6Z3fes64FXqVS6VIdkj50QnhhZznrDTjpNa36YbcXZ1pusAji/drBQ2Wcr3h66AOK3g1hUNDt+OKvmVY9AjhkkTfCGk+Pno/uz+Ijk9NvfSSW5s4j1Z1CflEjcBr1Ig8gllF3Fn6fN91N1xFfeOVJHpoePzUoUIJ33c+NNa4yu5fpzN/vE5+ow6fiNKU3P9lnPHpXEZXgA+YOW5Ofixircol4PRBG+J2S6KIeRD9ksnRujjMriuCYZFljd/Eq110rTK0U7ZORzG6PP94W61fp0czGgHVh7ulvClm73YwVWypCVYg+6cewiFIGK/oxq/g8IONhQskbJkQF+CmFmUyNEX9BfjrJSH+wuuGFjwhOCzO2Ie8ghVVlTuCIXgcQntrokSoEEgCizsRkjhOr1ezgmjlsM5WfnvyMvZ7AU8ZhOcxn6NriHRSXEEk75dj58Mm3FlYEha1jQBL58qY9PptcahuCkhuDAeypqXiZ2VV5vx6eRQxqjX889qYYLeMbdT6uMyrTdm/NOQHc64Lxf1024WksKXrylaH0Blj+mszyGT8XdATWHjk1hNyslDeK/QNIeOmABFkdPixGUKUa/AZC2ONOYhcCZL+XLwqt4dRLteq5wGxIxu4QQt+iVWh52CD0calLQ1t60D5c4B0cD6TXk+m625PnPp6eoMEHqbHFRh+sGyik/EaJrKhlHPwA+j3nYK0Tnu4OlmWHNB/9SXNoxxnP4rOQ2cZHcYVjlpxOy57BJc994uP2BqQsaKs3gQiYPjaXPuey9h3c1GHfo3ed2oSyhpAq/931YzxaMzxAkER1HlScnvn+9QpWGRq7nLy+CN8HpdrcJRHwJdQpuPEFjXvBD5zDva4TpQfzI5idxyo4amYVlxGI8fzkb37l+5jPJUYsH9EuXlbHa25OdksTUScgtI5i/53fAsjotMcdIZJqSg4ApSwm1bxOpmxlNLnbNgmIa8yFmK2pYm+1fyOjiC3Cf9h/Z1jiFTCii1I3JSQ10pA87Pzb88PNr5rZuF9UGOvStUoBpZUEJ8jmGxEOLNQbTsFvyEd7XC3Fzo2CL+Fb7vpOalIBRDD8sa3i6TF/L8S+D5KuFanXg05zdI/X1ZJFddzQEF+bkDAz/mCTXECaRd1r3eZO9n04Hl+WwWdf2UFuyivqUULJvWougM+s2Ew09qBTjL7002ViQl5M6axx5fa5qxfS2QHKIdUnlZkVOc8SZ8CFOf7wmQxmAGiBr3ueOGHORxKCXtrjDf+/9so/tC1M+72baggQx5VExDkcmvpi0eiPe1g2Z4Irp3hk/VK2f+9sKW0+LZiFMmVbB0vauIWcpZm7ZiwX/a1taw58WoSP9QZKqQwiWFThwbW/Mix+mf501nM0KN5vrpbHYS8GYVkp2bel6EfHKEghBsOISDtvBaBHyYxv2oZGZlyaSSL1pGwiUg0Rfm5av7VwfsWJGU2oOPKqTgEPzsFyOvRhPzJFekZvpGxzwvu9mWCa8GaJ6a+nXU2t40JcEjixadD0FvstSCpjmxit+8kJtoJAKJjzjewLX99d2rabe+VCYdl0BiVytXhX8L2tiGNFAUbBPAEgIhhdhjOgdYyOhlO9nJPJ/N/vHnXx4pcSWNGn/8BpRUlTEX9Yn0gOLF9VKLskB8L8DiHrKr9b4bQowzvxdvrdamdzycRHl60d8UzncMfZ/wU7Lr0jchg3xI9rOrK+dp2lHi8f7cr/HoF90s0XBr5vouJi5pNEWBAoz2OQsFdo7Wp+b3DkPvPlHzHDm91kkck6wUDO/U1unlAJsXlUSlgHpJzk9F/x63X3tqIkHeCLXpsHA2WIrMUPq5ZvpRjPl6GbguIK9ms3/hhsauPWc/bFoR4oMrZczPWEv69H/Sru24kRwJ2nDrwa4p+pzP+5QjCJYHYwF35AAiELAEQaOOjarMKqCBpqjjPPgSW1Ihkch6AcPvcQJr8Y0nO+izgJl7cLcfee/HiWPJzogAlYnhjcut6gN4xx10Dnewn9NWiPovZSZycExfIdh4nwqQEbXUowqtAcBRv/Rmk1dxpFiye7uqGhMEI8VraLKnntRhVKxa6GTSMXoArG+EqJUydizsMSTj4Rd60E7y8I9pFre82Zd2V2HPFVfsJDaTQQPscQz2qR7z7pWYA+dbvX/EPKLF93+HJr/j9rXOzf51oB6zO2wlf782u+6QHXMWwtKCMSR5iigWOwnQvKlkx++Smu2AUjtR4R4VK/eGHg7cAZvYzBGQfRgDbCYN0A8BTSsW8VKgE+pvcZv8PxbRCU7W73+thUX7rPum62GfiPvOm/1Efe3tW/yeWclBhjTVAWcVkZrO8FOWNJXMAHq3l0XRcf5xwfmYx1vx58jYLjTFFFTOVI7gKycb1J0p3xe6V3lyKUKZjmz2qAu7wN7ivt83VgT+OTzZGN+xWo5jbnztcrOfriPv62rpeOxHLCpwlS0SD65P6zRpkXDGt2PVRYjJE5M+1j6CCZhTHmW8BWpgV25YXEoUOFA9ljOBuyWIQcSIppf0TKHMuMv9sF8hDhs6Ogp//zntT25y6L7zZj9vq5aM3WYyCDt5tIZCW0sYjeNTSjO5B4pnNDdlO+x7uKljpHWB89GxJRBGdoYRV5PLm6+5gtCOucJMm2SQvszbAyI/cYuHo6AmUw/x/v2nF63FvfqZ5fra5WY/Q235LhjJOi+MQ+RJ/l1odydkj5yXYS/5EuwOAJvS0dV5amSYgjWOepPv5xGwuIUJfrFQw4h4RPJZFXiKZbJVcRQ72JkspVPHI88/2Xqzn7frZFO2EJhtBp+Beq9rSRA0ogVeOag/C51g9cyuNxDHcQHCm04O/falzLLDnVOivuQXoCfyhRHT7Pt6S2YiQZYCH3lDtKDcpyDasT/neEu+NNy/drnZzysNmZ24eR436l+woqa1mPEVUKzcnc9sR3McjjZQAguyC4rEutqZq3DcP4B0L1vru8k5LWj/HLwzr0WUhfUTwnpxG5rOLR3xXq1miT5vytp4s3/tTE+zs0zR8v/G7RQ0wLOcY5ACli+Zy2Cgh8ITv0+crCXCmHHHU1lkBcKCmsu8YOxvWc8YL0hwuSPS3TnmDfPC8F6kYYtpP9VG6zOtjEW7HcNJb1/r3OzfJ9PLsEleTlFKjsIdcmZZ+gIlbagHJ4xcz6EoszY83g9SW4lrhRABu8sL3BP0ucSfxFyCyPuo4IyEbwei3OMxneiQDsdaMdlHb/x4svZmZ8KR4YwV+KeoXaJwzyR4ySmnk5+aQ4a08DSoaBqCPo+ADKwjLCYrEP9L8/fFt3z/lsF1WaOoXpCMSGv2vk/0597SWIeHc85d7tw0lTK83cMzss7NEvWhUD3Bqebu76wgy+Ie97rSK3t+wkJbZn+JBC/07Jeo1zfZKuInZ/b3VvVV1sLzarGVGOLh8TGIKo3p27hVGmqQhsbd3tR0EvtDc29fmL/W3uyM+uyNB1m9axaIIVRjdjhxe+EROMailixloGCmhBdQ9Wmmk6/4WckFHVM7DlpiPcIe2VvAX8RTtRO5s+TofvL3cR4WtKYFgKfueFnnZg/UCyNT3qYhHqtirRieyjJkXuIjxm/Nf5ldVrCvTIQTjZbTWCOMpkD/YmyFsNysO02BnoLjSnqIM8Zw8rAH4/02bVR1s/PKGIT19p80VoWy1zz4R4ft197sf5xwBsdJCxKDm+fhSMlDNS9LG61bT7LhvdhZl4gd5jOdLzEZYI8Dko28oOOnFcEaeVJe72lplrjNRcXmI91YdIP9knCO5IjgwYu/hR1PIPVtJ/HB/+8XkHVu9kB9Fj+ikmk+65FhAnNbus4yF7svVv+CrFEOQkbWQnIMe/E1T56mgnIykZWCx5nVHgNYpD2oOezM+FvsFLixFsFPdrsPafhzB1Cyq6E6b+x59q/+Wnuzpus98ZHR7cXSyLmmMXK7w13s+O4cg2JE/0Z0S7nyQuFoxiLKco74TB+hLNwcUQI430Pe2fZJutuZ2f0188lZNnJ15In/i7KLSetd3+wnOjOY0zuHxVfMXuIjg2Tx49OFy6isiHw1Cu24r88/drOJlnE2snlCHux5tUov/DCHdvI2gZvvkwSoiAXw2LaSZUdmdzQ0rXKnx+ty5c0CLHkov5Yz0AOzZzJ7LsEwlgZyJ/O11eOthf+5ciP2BlF+daul9b8+gragb1oac5kUkeYKLEWfUEKU0PaZtwfPnJSuRNSfc7N/H6jHdQUHcacrwIPZ6ZUKbV/y6FfKK05Z2q66vRiFz15qcDlylVfpFwoXq/asToPCUS4ecRLN/6aQ4feu9N067goIqyNayPbebI5RDC+POYHdmR2JhhKqShlJoa55A+ptBf6A+FyKvJw+tX9MYb+y77WnFfLmPUHZp3XyctEcFPcW+6GqJLNBV9a52b//+RV6M16Anczu2R9XNDK7pvI9jI/3HbhVjZ+ZUSlOaq8mS8XYVf5p3wgm+yy1nHERD8yyEd3LOPQEAAAQb0lEQVS9h7zryc6Wzcih/WXrzQphr2HCKe6LuLYzO2Iz8JlWkv2d2wz62g3fkMtDAdnl5w3mnXCexm7jeDZnol1Yx4KrVrQgLI+QEqt/zMPZ0H4mPzFr173/dW62c/266JdNA55bMnBnSDwo9xh0l/eonVA3a9WwQkoOZLaeRhHTVa3fR6H2N2pgex3QDdNPlWoILaBQM/RCim/mM1QvSKi2Q8olon7lzf4aQ4+0eebMy6xlYQBAo4glRMrzW6tpIz20gZerWlBFSvbcxnU4vhm/GN4xeBzFRsy3HeL9L3h/yJt3rZsHMPs2F16lZc2QsWP9EErr3OyB+qHbCCk7RB/ZFYPMJtHvjup7GuakM6pi/awxJUyr9XUacN9o8GOt6FfUF2p1xROkz0VQH9UjsREujT1bVrqTXASlWDiNzlQECNberKLeC1oQIGRJl3hu7VTt8gOGH3m9Og7VYIrR1sxkcuE8taAmGyzfmq/SOgL6btOrh+/ettFNc8VVwgH7Nse5IQnydiIp4B16sLD4v6+e69zsE/VlqMhC+ItptBhjDxGC8i6lV+NfSm7j4VaVYWi7AqYOPoGshJEamf9Xov64SCP1tDDgjQpqoz4ZUUVrRPZ2LA9bOtIHjqc8mnZmWHuzT9Qn1qd7iQrqckvMPuQJ5PkHYK9Y6wb2VXPAPGr+1vYj3OJqUYMg7R/FnKkYbV0Lmj3mt20744tVIMKXscfMF7ALMjG1lc3yFmbNlIrH/x+73CxLvnKMAkCwO+YlWOJ7cZnAyGVc/Uqh5m4DgjtjGFPvNE3FSl2VaSrXi6YSqdu/Q7+AbxqhXn1dqC8qplzGSZlqdqYajASuhjucsEiK7L3ZX9TsFngsLNLIP1Xqs9V1nisyKzxOknI1c1XTKLVegLKVQbzoNczMyl1KOfpAx7A/CsL1pcYv7kmwgguFVF4j6v1hSWISQXz7KZ0zH7vcLHENlpEyBGTOWv07LM8IVoXBIDcIu8qF0GieU6HVk+Zxjm/OJhUXqP3Vave2fMCxbT7Z7Ivsc/WFpyWxlAGOvMmYWIDH+ra4LUDwjT823uyvMtr6vUDAhthrHAH9p0ZS5NUQzFLQNrU3n8AhPUO+DQNb7Jr6EXgEnYeajo2OZb+ozoBJbe7iDJmcI5H84euWoZjUyDlkbkwV9ZHY5mYJ7FifJe+HHAm6qN7DDHcHp0yoB2abuVMA7sodMLYyk4PY7QoVn6y4geZ9pPFN3Imur2NtIWVgIzB2ZeWoxhAzF7GR+9h5s/9H9GXj0TejcqyjsIdJEDVYUxJu+lAx33g7ob5haUWEQHUQiN0GoRnvm75vYCD9FviKEgQsMzQX4JepmMSCKVgkT+ZjzZFNk21uNpYhvo12EGwQH4NwriFAUGC1QqQ3R70ayK5WR7KvEfU+bxzlIKxa3dDtfFEXmw1LOnCyX3yHOubYpqIVEvmURhCPqujAfey82Z8HHduMdDeL8iqnfomoNxFjLAwEm6keNN/gebrPhRWhBmKHle25vcsZBRMXJXwstafQ9UV8Ofs9RbbkPKSIJo1kguX5b52bVW/2J6qxRthXODKwUh1gauoGgEYWr7orO8I8PouvQsS7lMHS0KiLHqR5zAn/cvyE5sLZjSi51p0yhGfhbJ5jHXJKWnzsvNkfgD1anfetUsBTuNOo0DAwElJJnADdBs9XHs8/bpHidF25NPvYAeQ1mpGP7F7NryND1LdW6+AbF/wKLwTnGKX9Tq3nQTib3Ox7pF5D1jPO2xrEOb6mFYptOPKNSCQ06fk43ClO6hRNxppaGi8zXC5e2S9YuYxD8LeIeizVHoH4VnoxF/mm8bfe7NvxxhbwriIDSNLZjByF6RfDJtFdawSswlMFjeH0MfAP/KtmKjJ+dtBEpYy2fzzgM3BW1UpXFy5Y5Tw19GNcXiQW8xsr5McuN/sC6B6CqSFvCmfe4MkwVvAVzYsCMksAXwt0DEcrWu1p/uqqnat3hLiZv+I71k5VA+yfvN988QgD7zPBiKdpLKhO5q5vEvFutvx3782+VC81KkZqFJANxLRi0iSFo97erw1yJGK1P3605e3BoDLM4+rcB+k5SR5loHmMwPOd9ug3gz+0ZiX1YUUqHOUwsLU42r63BLYhMDih/sz1v651emuxkqWZ54+ADMJT5F+uio/IsnrZdmJjMjwx//xcc/A+DvMblbj6D3RkcYjHTPRx8Ab44/fgT9baMD9rxHsdEw1XK2GtwTebxdKlNxsriKpXcTGoXqONawB/gUo3DV2p+soIT5ojIP54+8Al3nzAhsej9oifmLTQsYA/+icfj3HUjin00Ce8pMNfZ0Cp0fJ2Sf2FysiEzvhX6G9Bi/kKOKJ+lZv91Vz2FjrfHluH4kUAxF7lctU4wUZB7Wsb17r4a/2vvWtJcpwIotINZN+gHTALgtXAclYdBCsfgdWw5WSKPAUBLDLyUEiV/5LKY89Y84FKt2m3pW7br169fJkpYvZ/KpgJ7wuELOD6lpyXZN3muLCUM0V+VSmiac7lgzciSlWg3A1XpZjWwm6rEy3zK/91MIyB9eNt1oPPkqzL6IM7TAbF/N3sRsPNx8bpRQnPArEr8krelbsrVQuJiWuBle7lLELLE8Zz+Y9tAfvzVBaR2PqsP6y1l8lkavzYiqlDy5KT0bftgjIZ9sGwXQn32pjNXr1dONu0wXrrENqLugExFDRWREIr5vrYnHHf/IIhxOwn3QxU3hGhtXiE5rwx5CEqwra8+tzstklL6kQ6jGZMKz6Il1DYlROhnrAOuKRpDInMSvnmbFavDbJVQ5dyFAMzm4REtptFCS2rqqbc47TwlOWcklDznlgfEzOYGDl+XPhuekRRaPQP8+4ov8YJA1319UxiY0RM/+XBTJJ7TPUhdETNKdgFE8ECSpIQ4oN15GRKzwi1ZrNXAdpW1L5k9+lgI+zOOA6KktIsLXeY7YJMQeOV8rw2fF7BHEmSMLkP0m8F0sJ6l5ng8nWF3XUiAaRiotb/UPZpiRWu7gl7d04FglXrcxj3ILw2qtmrJBPUISfoRWE240y1yBykfVNStqku7oM0jar/IEVZ2Ej8rCJvVodQTAqQmh9hb1kZMO2HsCy8YuivqXvN9oiXvov6g2fMuvzVgsIGwaHMcI/kHJSmE5fZrdns1ZOqJhS0vuLsfQ9O/9v8uavXt8IYSCnVUsFZhLrAXzIj+0f+kn2hNlHOB3dCpDfTMs0AupRIENQqlM2wHQdXxTMnQRPTjd7HxtGshWXBtTWbvaop9+km+PgoiUmaJNXG5QbP3W7Yk+D0JtKyFJi7DCo6o0HsCXPe6MtnqqKjLpV4KPP4vgtU6k2R9DUtZ+h6z+UPe+tTN3iuS2ZrH1k5z6UDQNgBe9Wsaj3G8X5stMxYof9ohCSawDdGomBOENowhcviKRVsyYi6AuEgiKyQGEg5wipEgjwvNqUsIYIT08B8T7Iy46NDCPWCrhuzOztl/XSD9SL4ODudoa6K7lDzRHQvTCGdoRaGMWE+Epsa+c7evYAuWh6FBljIwdfA8oD+GpDqjyEvuwjUNkkiAd0FWJfQ8bNFh7betEPLf5eE+ZZRzDGt2L02ZrPXQFJm3pw6TfcS3PHPdT3IZ4/El1IJQLGXdgCRnQ4QWK8Qg9IclPF+NAaENTLJ0uRtrCdrWngVEROG3XKXiE0n1d2ouqoOuaJVzV7n3D6fAR7xLEG8Ze8yLZK2cGXqqY7prcZE8VRlKQtFLufBsNSrQfJamjW28JMvFJqIYdguuoN0W6HvAcCQIfxW3k2CSPOVZf21f+hnvDZms9e0nAD0gIoHxN0/U9R2M+Z6l48qJ4q6qJmXEocJXuG3A2eT7on3eafYOymNUbTM7DsPgiplX1Q5NDPACRGvPsw4tWaz13sovmG5t0uQTFFMx4ObU2MuGoKq3IpFYrEgzqkUhaAY8yrW0l4H1o9wJx9QZj2/pBmcYIosDVSkz10i9WhEVpukyr01m70+YFWiWCupXThDagXTZdDPJqbdPpw7EN3tQvQAiHEf8i7Yp/ztPQCqKeFB9K1g7ThbDpW3uBDC62BK1QuIO9NnA3rNaraR0bdePAs6mAAL682+WAbU/SxvTkodfQiuAF4hYcVUJz1W3MbNkw8thy42egYPfhZsH4B7pOBWUb/4U1ru8lSGDgi2ZrPXLcHrvivlXrpbEz3XfBuJUQQvKq0gjaxP+uK0xg9p+XNjs4ckC3kNbXKovFbsA5/AtrEZJS0iBLxmNbtR8ahXtVX3hkrSFQjvOLE+F/3x0+EOESmL+/MD9RUw+1X5fFVSABET9MaGIw8Q6jh3veK4nJILTq3Z7DXbFVDlEkwxpxxrSnlnRRkS/bl5bk0M/ivJmFtiPZrscNdTbmzksLFeexLpw0DcFSqhij25cWpWs6jFu/YySG0eJtviRaGPfKx5gklMgJJF3PEdSXBqr/6xOn4/8Xeewd1MkssO29GU9MizhOwfM0KsC63Z7JXMjGrKV+tqSSZgT/q0v7y1cyFCDc5qp3hls7+i2NbGmKBGCjarLhYi9QNtUErDZjXrkq1dbDUmYA6A3Qg7V4x7EXStVbsRo4x/mhv5rMDftUPCPkUKDqk6Al6Mr882Z7Nu0WOv0As/cU5WelL24dkg5B7X10btj12FlI9gb7/QjbK7Xc2CjSnQi/pQcocX1w5U0hS3DTf09Btcg08QrlylUHM2qzBKFyiynrwizRRO5KYsMf8blO9ZBmTo29WsLVLKGto6rNVPVgI7tneaqOZslpLpDg1GXzggDAcedsv/92hWsyJKSK0GVaf3J0O/N5s9XX4LeGO0K9+mQfkaY/3f2HZY//JuU8xBV5Dnxtud2ewqOO/2nWmP58X7l1NdzS7Qn88/dmiOjsu5Mjgs9pcO/fHQ72j9sGj99x2ag+PvS9H6KDfM+jcdm4Pjn8uCfF3NFuyvHZzjbX3VPRtLnr380cE52uCsWl91jYe1qPqug3No/HU5bQyOuMtLR+fQ+LN4yyGJ/SL94/rPnnZ7eXhBdRoq1k9rnj13j3Osv3kp3fr6ioSJ/7XfHzpAhwW+rFK/QX4R+2lt2a99nB7HxNuLdIzrKdXaQFsSbff2h3n6y2W1luMO7Xk+e3nTsT8kfl2QP+/qzbILhPaX33/+pceT46f3C7DncjXCHvanMqBdzrj0eHqsoJ7qMYmSvijOueN+VLyU/s22ZbyCvyZa5n2PY5Av/mbcQb5UtB38g5A/s9zspdniL0um7aLzfOBP59PptBnLWu9yGE6iOQv+nfrPy7CL1hS1qdvFWXJOrDknWaUeT4gX+c7jqakF/jiG3zmfXvrXo1/hB/5mcK6C3kK+ED+j3+NJsaB+GtoxlQbmgr3rTo8nIb9am3EYb2G/tjDXFVrgL6vQI8f0YEgBO5U+/TjcjGnNtiX0e48Qjy7V6tmHtXUzDm2dZ9wl2fLFOePweW4fd+jL3KbHbmOBcZim4YMxShdzFOSZ/Eff2wc/1zu4+/4g6eXzlRHsHdjbWePQ42kx3X3eVDzoOPB+OfAuG7N1cPzid93/3OZ6DO+imNMw3g28rtHEdujQuyhc++DXcB9Go+2DejN25ejRo0ePHj169OjR478c/wIvpEzWSEuJgQAAAABJRU5ErkJggg==");
			background-repeat: no-repeat;
			background-size: 100% 100%;
			padding: 53rpx 0 60rpx;
			position: absolute;
			left: 0;
			top: 64rpx;
			z-index: 10;
			.header-avatar{
				justify-content: space-between;
				align-items: center;
				padding: 0 53rpx;
				.text {
					flex: 1;
					margin-left: 15rpx;
					font-size: 22rpx;
					line-height: 30rpx;
					color: #89735B;
				}
				.name {
					margin-bottom: 2rpx;
					font-weight: bold;
					font-size: 30rpx;
					line-height: 42rpx;
					color: #865622;
				}
			}
			.vip{
				width: 82rpx;
				height: 36rpx;
				position: relative;
				top: 5rpx;
				margin-left: 7rpx;
			}
			.expire {
				font-size: 22rpx;
				color: #865622;
			}
		}
		.avatar-box{
			position: relative;
			.image {
				width: 64rpx;
				height: 64rpx;
				border-radius: 50%;
				border: 3rpx solid rgb(255, 210, 104);
				margin-right: 20rpx;
			}
			.headwear {
				position: absolute;
				right: 18rpx;
				top: -18rpx;
				width: 18rpx;
				height: 18rpx;
				image {
					width: 100%;
					height: 100%;
				}
			}
		}
	}
	.header_count{
		margin-top: 20rpx;
		.vip_save{
			padding: 0 53rpx;
			.save_money{
				color: #666666;
				font-size: 24rpx;
				.money{
					font-size: 58rpx;
					color: #282828;
				}
			}
			.renew_btn{
				width: 160rpx;
				line-height: 60rpx;
				height: 60rpx;
				text-align: center;
				background: #282828;
				border-radius: 30rpx;
				color: #F7E1A6;
				font-size: 24rpx;
				font-weight: bold;
				position: relative;
				top: 30rpx;
			}
		}
	}
	.save_list{
		margin-top: 20rpx;
		padding: 0 30rpx 0 53rpx;
		display: flex;
		.item{
			width: 22%;
			display: inline-block;
			text-align: center;
			.pic{
				width: 84rpx;
				height: 84rpx;
				border-radius: 100%;
			}
			.text{
				margin-top: 10rpx;
				color: #282828;
				.name{
					font-size: 26rpx;
					font-weight: bold;
				}
				.info{
					color: #666666;
					font-size: 18rpx;
					margin-top: 4rpx;
				}
			}
		}
	}
	.vip_center{
		border-radius: 34rpx 34rpx 0 0;
		background: #F5F5F5;
		padding: 215rpx 20rpx 0;
		position: relative;
		margin-top: -260rpx;
		z-index: 5;
		.coupon-section {
			margin-top: 20rpx;
			background-color: #FFFFFF;
			background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAsYAAAC/BAMAAAAP9AemAAAAG1BMVEX//Pj//vr/////+/L+9+n+8eD+68/958H737AuJ9K9AAAAAnRSTlMDgl4IfPcAAB8mSURBVHja3FxRkuu4DZxNKv+pVE5gnSAk878biv+plOgbSL6B7BOs59gh0ABISvJW8jnkzNqyx7Mf/XqajQaory9av/zd3X7wcjfHy3s/+YsVfCzf/BD+7+VjLL9Yft3HOc68An/Lis13s+gz6a9ftn75yQBP03Rz020inKeJgTZko1wAXCBcwChohMjfDTaMYIz6kzjLTwgsQC3Ayq+keZlbyMMBZH71b4P4R5OYYS4Al/+868gbcBGJibYKYAXJCmR5R96PLfj0OfogvRP05/1aKsqf31Um/+dHA0wicZv4C5JR9GICyLKi/M2DyMQwRo3eJAwLA8PcQgx9sD96fufI0nnJqcB5AXEqIBvK8Z+A+M+3H78ci4UvUnElx8RkU2JQ2a5mpTfzlP4FALXADykgGQmqwEkeE62cCFUCdeGrhNcN+L8xxu7nQ0x6QYpcUJ5O215kiEFo+g64ICJ7wO0DLuUlfYDxxyt+sv0usRITrAthKk+QiELfpKAblQniv/x8Mb5BLqATF94iMNKqF0WMyWXQRjjPIho+grogdIy2xQXdBiuJgR7TOBXFYPJm5TFpiMAt69eC8d9+PI0nPBQOs6241gsRDbsIQUgeA37Aas3bI/s0r9YtxEYoTC9AZAAKdVBG87/Ckkwu/jGEVDC6gJj2uyrKkztyOkb1ygB1DoA74CdeNsIovC/XQVxHt7Hp5pYTgE36DOSZyWkGneMP98YsxpP5N5Lj6TOPQ2jRZr2AKnu9xgrQcOyDXvfEePIPumYFml8wsotesEf+0wA0ZoC11qsguxONma7MZBRuscIOERaX52XXozcBceylYgFhZRVCL7l8l68lY9tj6YZ2/DqAHNN2Rzsey7HzruOx66nbmg2gLNugFy0WZxdVKvTVWY9Tu+bckJpRznJBgvzzMRZBFohb5p78shQiQlTAi40QIAvOMHO1umvyCdnTGGLlsuixcjrxN31IEP/618+nMdIKQdkrzO7M5NiCLd4BaQYDHtqi24uZm6X+blBeZmiFcpcNRqsd9IM8i5krDtkNwWMoRSFurxM9raOyOAJZeAm80IytfWpToH7DW1QWciYdzqmXDi5BUKzQ09cQWx4yN/B4uhTjcBQNdhMmDWAxahErthXkOHfWbQGgZpATP9JDx+VZpGQEjKebeeOTH+5fV1cR4eRaCa6XcQa6Xe0R63anxTIjzH6iA7cKszjmEXgsTJ40pq8cnj4XfHDFlsZpyWEoXxH4yhyTW0s5XazyKVKSPIRWuFsjFr2VmC6KPNjj6FsbIQRXv3ZcmtVLlWw5G+Ob8XBaxO7MUv01AMQUCk26/EeIz3mnb7c5QX9mkJmgNTtr6Mz7WBLTQOEmAYnNj/e/huLg8bIMohVS5Dn3RwhXYQjC5FDxrUJRIBbEjlqsgds8my/OLMZEV1xUGgvE5f8yAsbskB03nDqUj87twGOt7Sxts66dopP7HqjyeIFXm2XPS1xCQzdSE3kqtZcRfMXtk1ZcbHRRNzoG2XTYo9Uhepzyfd3WNS+9TNSgomabyCi0FMlAWbAvr+4E8hBaoRDfHDohnAe5Y0rfXwLijtGzBBRFKlZeOalUaO7WZGxciWTWbYE8A/UMjc4M8b2gPIZWqB6DyWKTBeXYxZlB+aw81pq6ccbEY1pXglz7dyq7Wbt4SSFfTIqxvoahMYuyV/f2UTWCgR60/SGbX7QZAOPxcmzuJ2lIa2qcs8QVKhFQZaUx/qUG0QrzFTxjAQafmtRCYx0CaED2tXZmHt97HhuVVSDYWWCPk32NXRu9tbDFYONW/pHueR0BYwxWNGUIJUNVjmOM/tT+qDwOQQcwRCmIyqIVd9bjqOVekDxIA818XhzT44nXutL/ZZg9jxNORMgIjiHK8VDnVV2ODY+jhsVsLwrGjM2a53RK3FiByV6cAE6oQWAyaL8TwVlHwLhzb9QIIXuheUUIp25Ty2NtO81VkQuPV0K404qmAmnDCKjuut2VxQmFtbC4rG0QHsuWV/MK0eWGx7HV4xpaRKn5ZIgioO8BHt+zDlvFViikZCYMGcht3WgZmzWOI9+2seSM4t1uFWEnUgFJNj2Op6Ze9OaQ1R3Tkyc9LgAWCKEVoS1AsonEKqsAvO8Gco0v5GfrOoYeT1JIM77sj29Tg2xoAk0dlTUp1rEKSYy5mFa8rASJ4oxTNWXE36IEhPDz+dwbHvPHitQQwOVrjBpkusmcEO9zDkBryhkOIxaxQt7QuR2ejYbx0g1qVvlt1+NJa1/FwGXJNHnL20bhcS3ztPgoXzdXe/wXVTTwDdgBI1k4WLdZ+vynSIjfIvZi7SwQZTHA7xdhnJp0s/3wGFqBCYvKY5myOPM46hyWOjkg7CXWVPMmydvcTmsX0Iy6+5PICwI/X6/v1/sNHgv7weMMHo+BsSOQXavHzamFcBEMxaCVCEoQBBYyyt1Pt+nca86sC9um0GK9v3m9XvtqdYiYD2j1IBg7zZAlEHI2lPUhpG+g5s3Oe82DZsRv7cGEJIbtvjFpQd3n+/0q/CV0ATLxGGmbpELkSzZxHGPUIJNYNxlx06mhD/G8dvI8mk3IK+qG141eLbqHlb3tJYBerPduzo3a/sxj2hv38rUO02tSHpNOfOJxDN0YoYT2UdPjWeeCcOAGNDY38YD4vq8x3laL27SWpj3v8SggD5AJTbWS9izJSDgn96lnKu0QGIyozVPd9CR7Ozg2+sN/8Gp1uK6tJvPiK/hX9gLyOL5Cu3nTxQhAH9JH2wCtUYrZQmlSNydBZi06VnNij+1Rd71X5fFdCsBFeSwV4BA8hq+w+QojsfvD1r+GQnVuSBKNelqP5lgKWJScZSBMNN6e9ETXTzHHtPYNraW8aKMav0I83saopXmORQ7dXEwBfEZZe9JBhjjrbDccHLKdzNmO8bh8kV1AEf18PMrTIRTiPY/EYhA95lKaXMSBx4dm0wWpoxwhU3WuHk4be7NGP/dagDxqKVJV47GtliJ3dd4+DI+n2/+kx8dqJCjMcroMMM/WFJmRwFm+9mDIKso7EVpQJiLfzb/xdSlCdvrMEDzGgZCpNvWca/XY+U+Y247nm0MgwSoSdm6cs1vR1q6dERaQd2p51HgzSyk9Do81FZrqcpdHQi6HWoTHArNFQ5EGNNHZI4jvqsa7EHnnHW3X8m+nzFkaesn8Hin3CD1TdKWFzNZw6rT40mTEes8FLyfI6m0reMtLNdgRKX40uryzXX5w8FZQPvJYzMgw/hhyXCcLZbxiMohPp02DSoXyGCj7emeFwGFbIbHEwPKXj2ATTG7STYo3TY9Tkx8PoRXq2xqhOEzIOu/trHo8eDc9fQPYK49ndRUQiVXVgRDmja/4411COMqIvr85els6Hq+D8JinNhnim2ukwgmLJxbkz0NDQXksgmGxkLgKdJNqNL/rC9rxCsgPofH393O19Dh1YjFKDdIz+XwM0vnLEcPYznD6hscRPO78BJXRG2959PTYzbe9X89ST/9+1GNpmuZBzjXVWwodR5C9jbRc13mhQozOSMNjNrloLoPOBV/yEmSLH1TfPcRVGI+lpbe0A2/rILNYt06NW6Hwx9M3OhJbd73K4xi6Y/6J1PguYiy7HHuLHRmc8fhNevy7Govavaa/g1FmsUQprA5hUKfrefrzEGc0iL3yeJYjC2oNIBnEY3pgLhvCr4bHOXU8xijMEP54utWjCu5wbvqDSpgkx2D903rTITmYl4XHVjrv+17V2fqmoHHV41Rn4djODZO7oQip1q2rQT6lcDbJ4pXHOsuCsRUC2ai8EXNLzbFR45QQlkTo/QTGz1WOLbSDhusQPCZ9gHfrAosK8x+nnFGqPbvVAm5XEY3HTT7xPKx3K8ctjxcT5JHOg+BYulgLVmOHCU4kyhdAY9Qiejk5LS/0RmTc0eMqrxEH6TPVRtNb5JjfsRqkjsqOclYBvmKS3KK5kQUmZHFPPaH1dL6HE25GFmzTk1sp8D3z0tqNXXFZ92JQteevoBPIO4BNuYN6DB4rxDfhcc3qGWQZ+z4xWW4oFGySRe4aybckw5Bsru2Pmk4QyDYF8OYChHn83jKmj7HnJSPyMOdMJ+k1YRQZ87E2yzI18jwdxBgAq240YlEec20waTuPQG7nLFgpWCre60kkMKK8DKIV8nCr6aZw2E+mzwfnJvOEob2TodzLAnrMWrEKwGiBlBKEtaGiTADjFWOcUjMDnmQHHOVcU8vjJraYRI3Fzdn9TsUfBx1KjnZsoR13k95y08kjsXi30xWQ5ldrK/LSKPIQ969ACaJHm1r75l0lc82Qp/5eLLEe2QsyXegZZD7eRNaNc6BHU0nTNmc0psEh8Hi/C39TpxnLGGfS9f4KbmpjC3VtkyZCzpLOeigdYoHeqVfZ0NtVJMjxrv3R1sFVqRB3/P17DY8XueMC5gDmUbybIKwh542n3jBP78y69Qcjg7g32fSCjGfxLSxk5Jj1eD90/XfUeBjbpAWMN4uDUn9kb4x7NuG0Qk9jTFg4GAx/HhzSXS/aeV69C5lOu6Vckd3b5E3ToPebB9+EyFsN3JptLw1xHxZRC4e7WPT9f8T1csxJbnKqNV8ItQoxiFFXRx3ZtENLmKV4oBMiKL/JxZE3fpF0FHu8ZDnPm5ZaiQxyrxvc1VSjTYktpAoBm//L3bWeKY7EwFysDLo9EdhEMIwzADLwEMExYR8tVUlqAxtAc/vt7ez9Ezq1HvXQJ6+8Q2JxumPFqJxB2qHpFRrU1kFXQioemEfuDVzYWrfz+Ug8HaQeG+dGpKsVU6EUWeORAdOCNiNj3bilAIyzpkPT6acb8vBbA1Skg789ee0N3K8/0LxJC87zMH2FTNG5TT1SSINd5Y3ydPb9WAgUmiv9LTTEHt9bBFnnaS6HHkjj/doIeidL5HNaIDc+2RB9ha6DQnOzn0KwG7Lzf24sZgqaIo9tCDGtQr/7WzXe0+qtzdN7nD9+/xQj1E5+XVcRe4vTIH0Fl/Ql67EAUB/7ze6QujhV2q9MYJ3anPdjVNLfnaCg3X5pgHcrFRriu4V460sFEd/nIWpFYS7He5cQnJXiNw6WZT3WewdOIAs4C9Yt57v/vu9eKLSfiANIW7i1ivy779ejjAUSWik46yhc3mIb+njzSE8vtXRKnJKIYyu13kIewML9jDHWmrfd70yKnAd6/gb8vDZuu4GPja5+StT056/TaRQtSD86AV7ISNduCYdbtXg4gTzmVc9gACuePOBXboSvBAzW8VcI8u4A7zfKLOP0FRZef/z8+WNjbJMHS4dWCuX0u/ACmOrk3KwE+QTznNPdvU12f49G4EXndr2+ja4G+LSelmHqMRecmEDyHtk7jJTHJJLOvqoHN5Lg7ouepC85yBbitNj0WvEhh40cMkatKF6TJ8EP3cWpGG/P8pidmzHOef0gIwTC0j8bzqWbj3fAXfVHEA3yFaDY7Y2A03mIPEaQwYUMqbfUINs8jTw2+IUJl66oFVAVAsgb6mO9TAWAsI/MfnxolBuC/k2IT+Q4DdK7eVC1LGdySJW0RE7It3lVKdI1dOgxURuCRQkzl2eB2OMm3Y7SD79IWx7/aT2+WIS3bXvRymoykaPg6Ckea3Ys8eb5WtPF9SAzpApXz0Seuzy2LUY8eX+/BqG/ARqkd/+cxneN8cUBK5eg3vycBtrRl8nXx8c85lGvFrosCMuxykiv4bOw2PJNq0UrFa0U3+6/PkWjWHR53P65ax5vplihAb4EhUx9QgbZHxN/LFNfjnEjFR71xJEsRgxbAQ5ykdMKoUIwmbxW3JyKl8AVVjkabcw0CX+MZfZzSe3xeRSt9OJxbkZ6fm2aCo3IIKnnhxCVQ3+WinUJFm88enaQzoy8tAx6RJBVaUG1hFrybgCDbwxykzkdxFdBeAiJalF8BRdkBbPLckDWvNqbtyysFV6PrRwf+I6GErrdnJrQ6rGBV3aVKXSu5OXiUR4lj715iw4jmHrs2ko5uN4QQuEkUyqcaq0w9aBjHoOb8GhBttZYg/x89IyUcCWT76INs6rejOFzU4RpnDQhuzyuIeydNpxQeXRxSCeQLYY7fs3jkAhp24pfHqRVvCLz8VJJHiiPhS0cQPVBWsCiwlWGaqrIiyMryFZAGq8/UY5vvPffYmVhL98jxITsufMv5GKJbHPeQPVYoqUo4jjZwBFiSS9HK1kT8fYQ60iCO9MWOXxjOUYmc+dmQd6vl8NcaE1cO+YN0lek1kIkn08B4LT5uZh4oXSYzRdclq6FTl05vrGt4JVJV/N/qVF+5CdyRyZbrTiN0x+zYIilcN4J4ZDHFdw7rwWYTlNEfW7tcYKt2IUJW3pE+S8rZD2uTs65UaNlG6weozXmlJfXFVhnpnla3pNvAl+4aB7f7Ajt2G40Fn72z4uL56OHSrGb2BATWQe9dRwdb4cfTz7w4ZUDz4knvfLBsBfH6WcyK3xlV6IYsUG/t91veY+Gju2CTHkLaz3smdygPDvI7Z93Jq6Ri3Qnp+rckFo/WVpA501v1M++gkPHfsMUjdfuxqZCK4UvOq85yJb9uiLSPF5G4Sq4AbLESN2jLKqdQqy7kPcm6nDrbb3bTVuJRsfbWY53xxIa6jiru22UaYk83sbJY0a51CkwWZNkbVMX7K2vrIXEhiTira3ovZWIK+mer6V/gMayVmwXfxvttdwuI+UxBhAhloV9mxuRSSWkBUS99+pvAHy39uL56Gmntr/yHrEUuhPabXlsiHv/YoxhfYES+Chz3rMYVwpkGWBISqfSa8v6j6RTuqdroG3Q2xPvMUi7HD7uuR6Dj2ottMFe7FitJi6DvHl2MCWLDCUjo70h1WvX/49mTgs7uNWBsTveuLuG9W7hteW81+P/9Ih99dJ981FvnDzuhhCqLHQhNr0Fkfpi3IsBGzJv8CIDFstOpQjy32f14/8IxrBCATmcbZw8niYXHzN1U6F7UwbUG3STtblTw5GXPJ4rhY8NWXHPi/k3n50hZovseTxKjCVtkcN2s3PqlYyo72NbepMhe/ggZ/qjQv87eOePj5msKyGTlNY8xqTXblnnZZA89kWFrzU7np44MwRNRXELkQPJyckLYN1QY/ewzHwR8d64cFYFTg7Tl6HePFxARCYvFZj0rDBTsze6tpfFRei86X1vpj0sRB3x8L0vx3pe2jasKyzEVzx58zh5bJjCWM8fKL2CDs7m6lIIH3LyqSO9K8GxFmQemJVeev99fCrHsdykHGeb81pbMS+j4DbRGRNmgYQOrJD3Fkks66DTAiIvkMlwB1mhiHeBgtC7XG7hZJAJCN+sdVuHyuNJnHeT5PSyB6eDCsWrRurlsLJfUCqo+t88d0+utNuy+XF/07ltL5ds7IQGyWOy84S29AeCExQWnN0kDpKV406IUnrN7ybMbs7Pt89cC3WNcfQJucBTMx+bzA7VPLXqQHr0vDsdRpDo3jyVq7XJXiVKJVWaKhbq24RcPsP08YJcvWVDBeWiE1EYR1Pb0bfb/zLMDAJ8kB1CfI2cODhwwLECIZJJC4c8Rq3oTJvWQGJuiHLc8ujVbRgWS2JzMm3GZfNSR6rHGuhXFTJwyCpXFo5DLvH8+eqYzBCK/msahzlhw01cuMb4c7o/tDWvhhS6oFS0PF7Gqcci4nRTkSnNex5uwSBtCLjcvZVejtMSefY8Pq+nc3BHHRBknXASJNRKYnHGWVqr8Sh5XLi1MEEW0hc67mmJUaQwvFKz096B6QvTprOlcqhSRAfBQIa2pj585niso7Q6uoyy2yzGaxIKsojvLDyPMe/V4ERakOvLxh7Km7CLbfeiBsHEAuOH6ukth2MWpBIv3L8vsENtB++BdpviJDKJHk5ynBW4mbs55vGruN5CSXrmsRtKbx37rtkjo1hv4SXyc6EdarvFDsIzLQKaKVtlIRxZkquFbzljmq7cKx+wFrPJCs1hP3Z+cUY/HyZuBpnfQovwkHks4n56nbZ3x8BBpKurUZdX9dNlWVz8fz31crCdYW+4kwGuSX8FXVY8v6+R6rGrN6VxrxMZqhKJXLvrU6UoZ+qV5zkUZLVkIJRnajolO85T0uLdPM2XdaA8FuaxwpDB7JVebmFCQa452gcOtfQmOMjjOczo1xUi34uPgUjzV5ppa9yaWWodxIte2CBbHh91ZF3yjRJZocIJebIuxHNq3/j6tfvTTJK1EX7DLvL8Wqx/vlY1th8kxv1ZD3B6O51OBBmm20fpfqu9hKHkDnmG0B6kkjFgP1O7/UA3HC0cX+v3d/8efp8VRD5GjCFmymOT12cO1UmHs7peiG8wCgFa/OGNDLURfNFntAqN1RzG7YX+valefLdt0DJMjNPDN8XK2CfqXkA9rnuuEVlK1iUrvUOyozkrjU5NtnepNIFzB9+vr9NXKhTr90ov61GwsVjJd6eRDiILOTKXAtDoliT9xhXzAT00Y4GxeL9s4iKtIM/QrtdM/j57Vf5un5XutGWkejx1+m5M4izjxCpRbX8hn9T10m3EbVuWJRwMlUPiBRnl4lmU0V80gZuv8LEeoz9mgXDdGxv3SqdcCGWhABhyjMbyHnne+7NAa2ixPIb3EEVG3Fydk4ruNizewYQYK481yv7hbpMwQ68byfaUFz7Akst7mL13yws/8YPpa6kH6vezl1BzadtTLOxWBumPHYxV3uQxd8n1CM9i64ZxxC19P5skW6jtGVQecAu+BTkdTuZlmeMNLWPtK2RK8Hm/Ulf/CwmKug0kKB++jftUlanvDRdOTV+zJ+Om2fsLpe+uVlJsFTIKH8S0hKbUWvQuWYxoAcFJHF4Ydsm1M3pKNXmh6re2Ex5NjH/WM68rj1MrxjvuQMpIfJBDQQ5QVjbhFDdTDzCyjSqISv2YzQsEAqgkYk1GtdWFQTIYZa0V0EWUYTSm6aNXchpz6cZJL0S9JQxEcO2L9ec/rL+NLan/sgphU/WKNnm25Ca9EmpRo7x5nsdxWwoR9eOgh71mtydymPIHu73l4NC5dJ3ynHTWZ7YUvH8Pgtv0K0hxOPLkhtM4izh+E62wK0W+1OX3XFSjr3PCZo8xU5lhcYVqpfoVig2UcfoKAVgonT44kZSYRKAWgoGvHERmeYNKOPAPxbl6gzxHHkND2ds2rJtkmP4YU7NMkoH1vp6frHNzq7c0h0iKL80uBFfVf3zw8GWGKo22Zle21t+H0bopuS57gzxNvIpklOzhvWO89Q8TzfaMOlk/cKC0Miz0jsSAPXuUYaNqsg7D3PPYCfM6jYJsa2UQ1dEcdynsaK3SFWnI771albm5CK3h5lj+ZMJUkkgcB0cfcizcvwUD1Zu34J0m9zcs4nz9WZySGqtminayQJt0/eLF+V2Y6TA3ChaLNz02cVGPJ99blPrSF6eNJ/K4qxwEg3PP7H5PS3R0sQLNHwqUjNJXFEzTk2MLC8FZsGYRavceI8jZpB5Q992DGKKdUv79DvZpbGo7w9RjiTCjw2AeT1PaI2smTh5B1vDqyd0Rodg/T6mk1Pf4w8qrStRjCIhP4/THKBTIXgm0LOcQ1GNdcTKT/T/V2kEPpa8nvr4XZ5G8S9uMOGK5GKge+8aY2cvKLHRoEfYV2p2lWuC6yRRF7W21UtEGiPmjsT2kMUKdnX8YxqNQuDxOehaOMOQeo04UnM7buXjt5J8fl559V5OpVuQ0k4A7j6F/7EA374rD43RiRZj6yW6i3AWjm/zh5Gj75F/LC8/68MzVWqUevpuBeKalz2M2cQKq+kud1f/1U3zlxb1MjviMuJ2Ut4VCuAoK9+VnpR/Gi77rK+zp44DtrVs5VAqBgmQks99Yy8GAtmSf1Ora1eVYjWt/G5QB+4rJt20Icgld74AR9Y/dVNxRBEnPyfv/9q4lt4IYhPUscAPP/e/WRcA4mVd1WSk1q/fTLCxeIAZM7h6OWa+V3fSJxhrSCDoME27Jj8FZ0wzZQBYkN1P3LoiQ4VRJmC4zryj242MgHD9mGyLq8vzM71G3kGvqedD8OEUvBDj/+FKmbrfFhLo6V3rh06iZidxvc0igWup6BUncCt+7OCE2HjefTP+O0VB/NK+AdHWy4WWb0nn2xUS7Mxcxx8HKVulTablb/Dgb4pADNiA3j3cEmxOjVQ3Hj+VsmUaYM6ObImxWTrygTREduMqPs0iKwTybi5P2Cw43PeLHoKjIQlGWX6w4CQ2PKolBNYGedO9+5t3dr/BjxObHdc52A30yFNKtiFdSHIeacFXIVhmM9dzoIakMnceuRb85z33eAfIqrRvQj9urs1dlrQT5oDUD3IvDVGTuLFU/IffxFqTt0JbSPfBmO26p58nEQrcLzaVvEZx6Y0su5pyJyXJTdhcF/X12j2g8bAIDc6OT52sW83UJwkU+NG0BSCkk5tDITQOnboJFtmXXXfsDLpWc1IQrJ38mjt5fXdW3ufwsehaEpRDynNj4tmlxAbs8ZfSscpQOeEH5w02Tdqu9rvcHp3RPvxsw5wXzCcq80Y+PEghjGf0YMrOKyt0iZoaH/5mjtI1P3MY1HP30UdSsNHOwmYuMjXFoFxZBkQY6yCKh+7q6eJV5zq5+tjMXf+6aufktw/sb+y8YhzE2xjZjbIyNsSEwxsbYZoyNsTG2GWNjbDPGxtgY24yxMTbGNmNsjG3G2BgbY5sxNsb/2L4BCGMdC/15BMEAAAAASUVORK5CYII=");
			background-size: 100%;
			background-repeat: no-repeat;
			border-radius: 16rpx;
			
			.section-bd {
				white-space: nowrap;
				padding: 0 20rpx;
				.item {
					display: inline-flex;
					align-items: center;
					width: 160rpx;
					height: 190rpx;
					margin: 26rpx 20rpx 30rpx 0;
					background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAAC+BAMAAABAPRn1AAAAHlBMVEX/7L//7MP/8tD/78j/68D/6Lj22JzHmFifZCLjvn8ahf/yAAAAAnRSTlMGnjd+1P0AAAcYSURBVGje7VvZcts2FL3u8t7JJO8N0fQDQE6emxB4bzKU3ptWUvQDlvQDkf0DsvW3xV2wUKQSLkjTTn1J4GI9OHcBPZ6xAeDmWdGWV+uB8v5i48ufwMlNUeQCLApE1DkBVR/BQg0F7HJxFL/rDhZxy+a2DbFZb2/XB9972936Mzz7LOD+yDh3Tm7pgM3t9pOf7dn6sseFCeD200eiuDkJWTdw+nj6LGDxOcD9en1MAYkpc70CWPQCLmXDI2LcJyZvz+fd+XwWiquxgBtit2cggdneRwePBdzenZHY4S5C7Ha7oyu7iQzFsq1jSa5brx92d7vdfncYC/jrZQYTpcc1ezTk5l+DAV/zhocdyQEBXT4j4P7k4Z38OZbhZrdHj90ixIYAH49o+lEC82G8yS6HD2yyaznAe5fZ7n0YC/gq8d2jAErLMd16H45niLeWbu55vd+ctsI5BOX9aIaPp/X2ge/e/YYu3PbI93AiIEZg51DPu6ODxiuzP23P+/VowF9kB922rQvHQW6dc9/m7jAesBj2wS6GAy6H4K1GAL4eAvhhBOCgH1NvRwB2Pw9DCV4DLOyX8JpiHKAz2z3SKHzTi1ZXt10HnChPgP8koAusxkrNAtSF7ozMAAyJqFvs1GhAnT4q8tLpq/rZAs6o5D6o5IkjyFJdQGJRyT3iPSCMcI0vLX9pCYf4U4c6rOaWtJGhJveQk4JWisZpTsKr/d7CU/X4/tbTCvAYfkbLDuUZCovEYK0iamBCFIlhoS/wkB3RSlkUHoj2FdLSmu1TcrarQQzThCNGxeVhTtERPEFjHlv20TzOQXC9DhbFdpwLWR7N5FiosIkxgY8nQqzTNklsCdlkvPC2sSluEjCKSgKLNeVlGGOTaET5Whd+qR8thBRW4F0bnKOCt5mRjIsHk3mOlt9TiLtB6GgVmXiCWlzA41pmfIR8r+BVwhUZ+jwJrILzZGHsJVaURdvT4lYtQVGRmq9ppdLeQRK6dLXvFSEK6EOVcuuK0tclBlzr0sMAdwi8VF3R6qpEvgET0yYyLAs9SkoVHJO4EvQ8KYVhsA7KzALaX7ccRX8NhiqzQKkdbMYCMUZ5NDJ0zVJn0pTYpSpdp8yhVemiTEzlBE29qRpboDSHu62maYVpU8qtKfkmlXqGLul72DpKe6ITNTHkEHFVztMOK1w9Gld6ltb0ceA4ebNnBQWVZ8hJlLbGayoXX5s5BLUEhfK8PT3r89UzNpVm8KFKgj9HdD/DGfyumZzdh0+A3x6wrvB1FT0TNG6WXl1ClcLj/BTNbSpkclXKgXFqjC5lb80m1zXzZ8p1xfRH6CoxuK6hZoalOIJ7ozTvrUpvsvcwMxfTx+qy9FYCglCMnYRY1yM07ia7EaOsQYxPI1Unjh6iqxgiZkhnkchJ1SAtu8S6WgYhTepavDhUl+yv1mbAgegK1NgYoBmrXdwU8JFsAB8rDbmSV/u+m2rMw0Cw8gSJc13VX+gLyYDMbnRBqdMFoUeOlc1VlZwa+hLGVouC4tdEv6R7+ZIFYqEfeCU9KmDiGVkEqirmeUinwDraKNmXznQ8ID4kMemSHnHzgwga6MCYqk8G+wXqzAJVZoHa5BUwuQGzM8weFGMqk7MAJywmXx7tfFjhUxt6+J2jgYAqulqu4DtPQ+0R8XFc65kag0KZ48fNPE03hb8JmRABubL4cfTEZF2BWFsnJxmhO0G7m1JRQhpOzEoe7k7QFacN45twrcPAWO3e+LWpLhvTNJiQMzVlUGWkPVHn/x5KgDpST9H11/hi95D6l/1MeQL8XwA29Iiipu+O1fR4hoLjxMoSM1ozQ3jexGOauGIaxTf4R5x+ryUoa62R5mg8axEPvsd2nGCjhWQjc4O0Mb8R4I0/Ql7Ga8YztJb+bBWgaswC/z7FzqqQAeO5QLv+cnlZLQaOSYVBEEBnY4Pfwp7KGl9djHXWOYNdEgpDjqvtqXAZVxdjnXVUGO8GGTaW6lR4IFYXYz1iOCg/IBbh2eTMxvKwn+Q5f7IsMX6Hxfy1ltOm4b2Np7gwwoXBTEKNVFgabKIdlNmI95yPb9d0HsNZYmFtnLWBfBgzMvjO8bPNNY9cm2js9akGLB/VFbOwUwTax10/2nRnWxE30oL2muusemZbO3wLrG2yCtjMAovMkh+wyQ2YOSaYNguJOVfzSuMYutYiqeYURAWHg9RCNac4xAYB8aHYuMrOKYgASAzdR9do5tMQQ0Lmai4iMWSi5NbZDBELJBzswfnioizhYKKz6DHDRepEOWViIQXkzFA13JpSBOQ/8Pliy623etGk3hwVX9znfNifLc2E8jVNfgJ8AnwC/CaAy2wPAa5yElzCKq/Fb+BFVrzVO/iRfIjvKkf9O9yQK1ccm7n1YuF+HxUnLrPU7/DX5Zw+5H++fbHiI1Zk+Yz6D4f3N8MQz3+p1x4TAAAAAElFTkSuQmCC");
					background-size: cover;
					background-repeat: no-repeat;
					position: relative;
					>view{
						width: 160rpx;
					}
					&:last-child {
						margin-right: 0;
					}
					&.gray {
						&::before{
							content: "";
							display: block;
							width: 160rpx;
							height: 190rpx;
							background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAAC+BAMAAABAPRn1AAAAJFBMVEVHcEzvypbsyZXsypTtyZXwzpPtypXsyZXsyZXsyZXsyZXsyZUx55mvAAAAC3RSTlMAJqVDehFfv9vwj03dKpUAAAVNSURBVGje7VjLU9tGGF9Zlm3IRaGZOMAFE/IAXww2kISLzRhaqoubmmcuCu/WF2xKAtUFSEiZ6JKZ0CapLqSdJJ1wQjb2mu+f6+5KNjaTzlTrTk/7O0i7q9Fv9nvu9y1CvFiw8MRMb188Hl/9tpBS1uAFagl+qxJ7cDvjzhIDahietcInGZXhdKxhPq6Pwq0WCKeqK5/J9ia/Z7vVEVLW9HUc4+Z7CFvLVFwNk0fgZI+urQ2flLgFNstZlbxlyybPdgC2tc+yySv0ffxVkr7bLaC8UGarcn6ukuHboHWw5Iy6U5To5WtnNjtsbHARdtoLqjMKOK9p98PtYIWHTzG3IggNf+GLb8XgIQziBVUqFL/06eMcD6F28B4hy3b1LzVu1TfIYxJIxJBiVXUq/Y+f0uk/+i4cmsdvQuddxLI7Z9S+vWx70mKk7vEchCcHPZSEPOS+mtt1HDNrkSUOG0PC9Rmlr9mN5QKXE7ZXFtxRWG3mM4ArTrpPP7gETQbIvjCwofMQntxyf1ts4rMA62M9PGEC11zvOW7mi+JM2ysOwkAl62aCTCOfbayYx8FTnrgrP2YZGkUasw9Wx3Y7y/4iB+Gjs2NZyxOTJOtLQ2gb1M6yDMs8GVvLJ/00QwfrK6OgI7MAGOVsHsJoWkUW+XH1gu8og3JwZOoB4CE0hxDCRFc9db7z6RgKVTK5XZTDKofX+JCiDtadJghvy1O/okB1WisjGWzPjDJ23NDP/vTf9B1lgUpq7gAOZDF4PgL8tnM8+djzCmx+F4XSO6rEiGGOlzrAK6GvlGogfLQP23BY1pIoZBMN3iiiLu+ETmpwBB/b6gBYxfNEiXDVKne/4gkUx7wJh3AnOartmtShTRPjk2OO/O8SXkUKCRVtB8dC5dzBWzKsDsJfKgdh0XVAZYrUH9EV7Vkfbitquh/2UD9POqztUJkisYZM1Q8lc/H8Xkw6IvVDgCvZMD1JU/DE0tE9kvZLuecYv0dU2iAPYYkSSlHYRNoukRkGiiEborBx4Use3eY85fKheaLEHyb8xUABlPVdXsJ2EimEj2ZXP1GiIvlOSWZAKHPhnB5PABLLMuNTvqF169i7UxStJWpS8kx4L2xIsZFSmJk3afEOsA+1KpO8vZdzMESzrMr45KdEzGi1q1aHJcnp4j3BLhIHid5i+1MsMpbSdYOpJD16P+c3STx0V+EmOw+agreDRrdnwrEzoikfOIfoWFONTtfaPRO2lSPUNE6JqTXmq0CSq/jyVWjmim44B9TxJYk5IEOYlmBFxtfY0Sq8XZRxU6f7RGi9uUOeVTkJc6cbTImX+KQIb+MYspkSDy918KMZ92j1Hs0wRH6cv8T3kJg49IbPzsYelXmSinm7tnaNCCybxJkUDsL58+X6bgeYlMoQixuN9LpBLpk7YhdXDQPpxHjvilNH9OroI5fMB/mGWTxes0XgcmfwbzGHw//UkKxxdaOSld+6fKnh7nHL4PNtu9ZESe49kOFo9etZ4CL0Q/6JM7qSZtVCN9gscfQYRb5oOamEHe13AyMMAWtQn8+CjjijZW89xrTpJLB51uWtL5mveQP6PqQKVI2z2Cl1JDIJf9Awb8ZBkolH9snf8kW72BUJw1YLt31gX99v3M9aPgu/tXLfdwMqI09TtdnM3Ui2fk/CiXXAqbVf/hycVq4m7vwce2DZKmoNowA/DSY+3ykMTKoz/fB7q3wkCZoALyeX4vGRu4Q7g1qH3A8u3kyg/wbXP22/qx4WHiMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQGB/wd/A1K7dDGJQCorAAAAAElFTkSuQmCC");
							background-size: cover;
							background-repeat: no-repeat;
							position: absolute;
							top: 0;
							left: 0;
							z-index: 2;
						}
					}
					.coupon-btn {
						position: absolute;
						bottom: 10rpx;
						color: #8F5C11;
						font-size: 22rpx;
						font-weight: bold;
						display: block;
						width: 100%;
						text-align: center;
						z-index: 3;
					}
					.text {
						max-width: 194rpx;
						margin-left: 14rpx;
						display: block;
					}
					.name {
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
						font-weight: bold;
						font-size: 28rpx;
						line-height: 40rpx;
						color: #5D3324;
					}
					.mark {
						display: inline-block;
						height: 35rpx;
						font-size: 22rpx;
						line-height: 35rpx;
						color: #8F5C11;
					}
					.money {
						max-width: 170rpx;
						text-align: center;
						font-size: 22rpx;
						font-weight: 800;
						color: #8F5C11;
						margin-top: -20rpx;
					}
					.num {
						position: relative;
						font-size: 44rpx;
					}
				}
			}
		}
		.type-section {
		  margin-top: 30rpx;
			border-radius: 20rpx;
			background-color: #FFFFFF;
			padding-bottom: 30rpx;
			background-size: 100%;
			background-repeat: no-repeat;
			.title_bd {
				padding: 26rpx 40rpx 0 0;
				font-size: 24rpx;
				color: #797979;
				.bold {
					display: inline-block;
					margin-right: 14rpx;
					font-weight: bold;
					font-size: 32rpx;
					line-height: 45rpx;
					color: #333333;
					+view {
						display: inline-block;
					}
				}
				.time {
					margin-left: 14rpx;
					font-size: 24rpx;
					color: #AE5A2A;
				}
			}
			.scroll {
				white-space: nowrap;
				padding: 0 30rpx;
			}
			.item {
				display: inline-flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				width: 210rpx;
				height: 232rpx;
				border-radius: 12rpx;
				margin: 32rpx 20rpx 30rpx 0;
				border: 1px solid #CFCFCF;
				line-height: 42rpx;
				&:last-child {
					margin-right: 0;
				}
				&.on {
					border: 3rpx solid #FCC282;
					background-color: #FEF7EC;
					.new {
						color: #DBAA4D;
					}
				}
				.title{
					color: #282828;
					font-weight: bold;
					font-size: 30rpx;
					width: 180rpx;
					text-align: center;
				}
			}
			.new {
				margin-top: 22rpx;
				font-weight: 600;
				font-size: 34rpx;
				color: #E7BE7D;
				.num {
					font-size: 48rpx;
					line-height: 48rpx;
				}
			}
			.old {
				margin-top: 13rpx;
				text-decoration: line-through;
				font-size: 24rpx;
				color: #999999;
			}
			.info {
				margin-top: 13rpx;
				font-size: 24rpx;
			}
			.agree {
				font-size: 22rpx;
				text-align: center;
				color: #797979;
				margin-top: 30rpx;
				.link {
					display: inline-block;
				}
				.mark {
					color: #AE5A2A;
				}
			}
			.buy {
				height: 80rpx;
				border-radius: 12rpx;
				margin: 0 30rpx;
				background: linear-gradient(270deg, #E5BA62 0%, #ECCA7F 51%, #F3D99B 100%);
				font-size: 30rpx;
				font-weight: bold;
				line-height: 80rpx;
				text-align: center;
				color: #865622;
				border-radius:: 43rpx;
			}
			.cash {
				padding-top: 26rpx;
				padding-bottom: 29rpx;
				font-size: 28rpx;
				text-align: center;
				color: #754E19;
			}
		}
		.section-hd {
			padding: 30rpx 30rpx 0;
			.title {
				font-weight: bold;
				font-size: 32rpx;
				line-height: 45rpx;
				color: #333333;
			}
			.desc {
				font-size: 20rpx;
				color: #999999;
			}
		}
	}
	.goods-section {
		margin-top: 30rpx;
		background-color: #ffffff;
		background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAsYAAAC/BAMAAAAP9AemAAAAG1BMVEX//Pn//fr/////+vH/9+j/8t7+7tL96MX74bRGRLI/AAAAAnRSTlMDgl4IfPcAACAASURBVHja1FxbkuO4Eey1fQCHwycgTrAgDrA2wf8NB8kbkLwBqROs+thGVVYVClQ7HPYf0NMSpdbMR3ZOVtaLX190fvl7HPo6IcSR/zwP3h1Huhpxgl39HyfpxVSupmnKU870yl2knCc7/HdSondS/uuXnV+G/g7gHYMeehWGoNiHIB8YI8ENlEP8X9FOiWADejklBrmcNMkFvZky3sIlvc8/o1/C9LtBHPuDWJAdxiEOMQ5RnozKI+PLh3H+8UyGpL0ztR8gkiacPIGygFaOvJ71NYFef1h+Q8rkf3VI46GQlplL6A71miGmr0JYJjXzNwjKIbYQT6oCepFUIOhSIFUVINAUVD6LQruUq2XOzVkAeQLEf+4RYoI1DMEIXC75WlQDfIYYx3H8DxIxsXSSAkBrgTrhmZjCk7GVvypDASxwnOkwyi3F5fyDMY59QqxCTNAGeT1AoumbwI1RQA4/BrPJ4ARtRRSY16oLBUmFGBcNVemn5WFZZzkCdGbIcU0Q/2Xok8cMqHJZCR1DAKbxv4Q3h2lKSUJafSlgFqi81CptAf5CFwshvM4LHwJ2riDjg78VjP/WJ8aEqz4C6cCPQDfAR4zm3iABnsTqFQAuQyjYTvr/HTgti+MumEocZYGQQzCvyuT25F97lQoWX6hDCKLOwWzFTzxO/DUKtngSysI8ZCAuvgsM/SGWqSRUgVjL8VzOin1e6e9OfXpj4bGohDJ4kEBHYhE/1TeBvOZ6J2My7AL5hkfEWuS//MxQEynL1SxvEXvnlaGGXBCVATyjXN5jHuffv/409HsA8MCuIgqpKdqxRfMwh1FYPGpYm7xWgLmTd7xM2AwmM1KL+GAmqfAYiC7C43JBX+sil7NI92/9yjEcMQSDZQK+bRSvFn5gsriG1EY3b9IePCZMwdsF/ox4LCLNIDOWYixWoM1I0zukIQTyr91iLA45mi025xYsd/4x4dAjBk2l4mltmYMMMgRD/nDQA5XL8yqKAWFgzKHOi8bAQv/56599Q1wQZXA1BgbW4hCeFZ3RCYQxWRKNlGoinHyaBgth1lc8A6ccBC/BCh4Ll/klQGYWrxwJc6+2QkGW4CdaTESWgBdaiAuLJew9BINRbiWC/dks7lc02YwZPxBLIQ/MYxEOiIXBC0KXf+WrY4gDVJn0Ai4DEQ/FuA8ikzowlxs9znj8qOdkx2PJ2mbVZhAZUoyHuUa65yEe92wqYhQeA28hsncUyV1w0pycTkzmiJ9FBlEITj80mbAEg3zvzHydRXiXNbOPW3845S/1izFqFgK1OozA2QckQ5BNVY8fGfQoKOeHHiO0aejTvFhpzPUJNsCiD6Cz+OTZSwVA7hdjVIOCFjljVJBhK2JbIvZZhzljmGO5fh7JMp6pMRi9KI0t83gAu2/rtu4Qi671mNNo9ROc51ktzmrHSWBOlj0nrbzXJG+aPiFG1SfP2Qc7NcYc2GavyA+I1wKxKXK3GCONBsiWjKhFHrU6L9ndqJ5NVRjw4uqDx/AV2co7yPc81mqJ19XI3JxtI4j3fe+bx6HyGGl0NP82Auoa9JKV4p+eQgD/iccPdGtFTcpA5oNnMNtxeWOx2Bnm8tCxVrAeB0mrY627SUfPpILrQG3+IUxWgBNXg6ZGKYTHNe/I9uJTHGZL70Qr6DCZt561ggOeFI/jYPCGKslIQxqALd5pL3R6ZHpOKkR97VsKmfJIbN3NAregF3A3Rnk/jsLnfnkM3irIMWhqLUMXrmCB0oRzbFUs1CBPP0U8NWpeK1Z+ExAfhzPBDzku8ALoo2ceayathYvKYJ22YLXglvOUxk8m67fP9PJSUZ5dlNPsg1MP4TGRdPcQV5wLwMexMY0p7nWe51EqrSA7pWhCnpTYrBnqOkx4zg8eM6az5NBLBXjmMtCiXD2uY2OLttQQCC0uEBcSE8LH1rlWBLSZalNawt4YbKCiTku0yR0S6CQODple8lohMjxbH0RprIQtEN5HkYL9YY3JU5Sf1bPtPfNYFRmFC3EWUOMYx4cef6Z56t6QgyQ/OWG8tevceLZC4oMwJprujbcQoain/Bp69m41vRuG+BBkP2716H2MFVonzB9iITT2gkzBbBPjQBhfBxzavrtw9wR52/rVCumZDlIQGqpFHp0gS673oHJ2ri25OTZFeM01wTNBJq3YhZt8zns/2DscmzKZEW4gLp/uuO5mPB5kvMJ1mx59JiBcfdtkVEbVeHI6ofXhmumZwWDDdhhN7yIWx0qYViJv+DWcx1X+XBd/vGMexzogFMxbiFKE8Bi7mqZHQVOglcmVVIOd9ptzTaUN5wLnycCd5Rznu2BLND5r6CufoF/BxSCXz/TNY007bJ5QYx6mjNsJzabh7yevcmp4PGtWrDLhaUx6zOieN0F8nbeQuhgMq2mSaTuZwxd9in4jPdc2JY3mVNqqblHSj4AJgKha8SwH1cZS5TGcA/3Hr8bYPbJhY/SuuwBYtOIiiO/yvG2N4zgZ3fIZkou985iHwYohujLyD3rMCI+1fpx9XajSuCR5QGlfrYzp7Nu8gscHGHqyeaPId79uqxfDcgiL+XN98xgzWAN3/tUsQ4mFwNKkVnyrWGTRCx2rUD1m50Dpb1ul0Gkg0LgAR9SlJ3pdIP6+tlpwYzVmQSk0vonIHdcrpNcknX9JpQcenx9tvDtYSo3CkIoGSm9iLer8lfBwXWwCSJI9RlDhYxqDpOXF+/v7cjSWX8TNPCa1ODrOpXWwAjweqj3GUkKb6aU0pue8sUwS1tFtojHOag5utunMjYWW0ONDIPOL1/dbeLwpj4m/8qHr7lgrVCpC0H0QyLEbdovWc5pGX33TmhAmNX2dYkVVcl9nG37NWqkgv3B/ntf7+304e2w8ll/F2TGPBxnYHGqGV/PoCEmWph4EeXSdENEIKQbV0ibzmKoQ0stfzLsVGfhA+P26XwViwniDGmvIuyvId98xD2Ih1Xkpu9n2EjxydAuMzehKATZ99vs3drjCY61TaIpHGL/v9/v7JQwup7wqGO8ouHmxqES+esU4BCOz+Tat1OvQcRjrLIsvH9u8PGaPxSlTcBOUih7nOnfMzo2koigvH0b5/aanF7917zXNK86vgfjuW4+j+Iq2AwIzoeu8Ni7UtvUwwZLbqjGDvDPMq40PQpdX8JgRLfor8JYrBv2PnctxbEq2lVMQoPymh6vjHAQ8VttmDSeff6hYtK6Cy0GT+je3bzfrjM+6SpmeOns8osnmGIL8fr/A39e3EPsSHu9ol5Jphq4wyD3zONRKhe/+27pNcLV6XiV1qYjtKLQTFTNmfAhjTp+1USqlCDZvSlDWYvD4oprQvlkT5JRPQbevnv0xQLZVSODcbO1qbSjV8uZjH8+QFtWVSSrr5M3a1edYiKqmZHoF5Zsxfl+1trk7kF8Aue88b5BVkNFHvIAlU39TBdojHX0qrcWKRowpxNVhSzXGGTSG4aDyvFaPFekS8qhI76NeyQZd1Ls6n/FWiKtW6J0UgpkL5bHfaNJ6kFbf1KopxmwneJhlrSK9+9KatkKo+Ha4xukuPFaQO86ltRvN0W8M3ruNNc0zsKc0Ppd3s9u2mW1XTFr4fjNvgQSwDOzKaOB8n8eJ1ikZik1ALjw+ahZyHt3z2E+toHRc549j3QuZxCLX7dKa61kvWtdGfUvaDWLuTb7MFbjrRoFzNWOxanFTU+mzcz2Ora/gNSdduIGEVD2eaq9J6hW6KV1nKuZZ1sH8ro22m3fhqka/U/pJJBau2bS68ibX83uuVwjIZipqiT5I7ViTkY/GdK7eYvLWzaa4ZS1hxba5TWJKWY7j3smdUTLC3OB3EyxoW1slf+96NlY3msLnnUGEzppY16DXdpuqdeP9Grg13PPDWeNVS55HSTCo1Q+QT8b55KhnYkJbCtJv0sZ07zz207Cx+jgtvdmAbMNjN0nopgnn2UawSDHAZ5lh48GUzYaswGPIAYc16v63vRBiMr47n/GOg4S9oZ0+5hwvPLem02dp6DHnpmULu7VKNb1gcZ1kO6V5ir5TVQtlfR132/uuu1mtItoQC7hsd1jwMDclC4l3detx8YNCGDS2RTAOcjxVbNhhRqVAfMIE06iFryLD3LHb67t+rDx+0DjAUkSTYyykp0e3SRK9pBAvWDhnM9HwmL0CT22vbsZKWYwCpvJYNFnlmwJl330Qrc7rwo3cJgR5SLByxWSbIc8hluy9my0+rtbtt5B37Br2MO92nqeB/HrdNMWyuZrFhjonSp595yA6GVvn6AfLQ4JMybZ6PPlMb8p296AltyNv2H6sndCdlRUQSy5N9YpTe07XsX2s6GHxpuv9vFoVck1p64SE0U3I8p3cJAtp5pFlqlBWQOrKP4yFmxNEL9UrRcGXevuA+L6aWe+dB+F0sKXrWSx+sMnYaM9jvY9FcLd7bEOebdqkeneQRTTDNvGgrZugvD/EWHl8v6W8aXFvRVKNOmnPNSHZ9w+D3b/CYh429LReMfHtK9q5QtfJgybPuoM+m6/QmiaDKzUK1QmZUWGAy7mOj5WF/nd5jcc2313FQm6wEGrd7ePGFXUpD2MWdq8KTvmQQ9OgJscunQg4MH7FA1gYx5L+9Pt9H40We+XoWo91GEvvJ2RDhqPcUsjdKcTv3MhungKcZRprlo0xm+3m8atNDvOYR1JYhV/3v7m7AiPHcRy4sYgZkMpAUgayMxgrA9kRvB32m0A3ANK+AOiZ26vb2aq5KgwWBBqNbq8Tsqe+tckbNELGzuNsgrEOvhlmkYLmTX9zE+A2C/dOec3aWKC3uDDCGD7qOyeLpNquESF+PF7vRAZO7xCon5ONzhNCE5dyc6RHlrcxsYSyMnfnvOun+sq6kd4tcJBFWOc2yVwbO1CNX5Up9Lqfl4svnP5+I48VdrP6EIAhbd6cymLqFa4XHfKYbG+pxVsUrLhsmD5u2ORpHT61PgTCm1Atwt60rRQjv3n63lEIORyaTtZR+MmCQcaOB61fP0BbIVVTYYobemMG9RUizP1/Lch/3lP8/YDWTQJ8HMgrsXsrRpE1OGhtj9LXKIY12xCyYiMtTTIvc31/B2LKK2TxXaks9xsB5JjE8nYOfTumKoWhr4iIBZgsGQyWtSzR/iDql8725OmZ9LqzVCjeVvP4T6883m/d6xUfvPv9JbTCd0G+kmPUxHlkzSbo52WT5WWEdd+Uc++PsM4ttumNBd+/3cRiNxV9lHLM3u0GRvc91OJnbTCUkPU8P4sxmOKD30szj3O8aqJYYTazCs3jRqp7Xda15xRuK8XyVsAVV0vimyJsDwT5NMog8li49Nc2jXHvMLK+GylveTKO90Swor38L0GgSW9u9Ehh+SJPSMVzhd3k0ZM8PjSHnxUB0gbuIS3Fg3n813VtFwj0riPv8xDkKQYZAm8aYexBhL+y6vxcliABuXzKP0aVEG3drlhEn0oSfIZi8ay1QmnelbzZVwronQ6tU5i5bvIgu2hTwhVks2Zq3jwrFLyH1HArtXsFtQLgPAeQhwzOINI/2Bxb89b1xqPnscOagUjPLE5kVxASUrEVH6RBFQoM5HAIaY0yG2ThFKMe15BqIkvluBuZ/nn7MoQISjp2PeaZ3sQTSFYLGitkR+jXmMdrYNKjjFgeUyd21WMm1oobAKDaDbM1rmxvrRSB6R3UsvTAb2Aulv8r58ZWwWpyoix9L6C32AGk070/KQABsXgH+WTqvjTGGmEPcS0Wf5+92zqy3qbNHtxRhzfP+ELWXDRikAQuliB7PEfWEIoFNT+uuPeX9WgtDWiOnw9/8mqxuHURrhV5cG3egA7FQURLRcOt+BRK10EPFbmZSUyyabUzGsMqZMJ72AQiH5bHtbNwcq3qIW9Dv3nksKQUfIWipR6fPO3dusU/1YTixqnXFdoVFdK+4pCBQ/G2xwPb6EdbLGTftDelYh9cY5rHeeZzE2a9ksixaGlYbSLLmml2Vla0bNtUzYKdW0XiawfxCEemksVtHovGqetkjd67+ZyXeG6aqRvbGG3aZVO4M6VarOtitbqbUD5W4O0qQiAa0BDl5wPdsufxXxQ5hR3ANvoMkpjHqVcfy9FZU04VvjBjoSYEVpYRs7bYHyv/6pCVkmYti7EcnHZ57FJvzON9dNxtmlwuPQWZQusrkilYfFEfW71WaGmeCXOq98oOVqy+eU+EGAi9jCOexH2DvF3ocDF2rUi85/0CWITFP2VNZ2MAaITX2cX0VkftzZlJaoUqZ9YYW8re0Sq/dK62GHupgJq6mgr9QO+WWp839hU50is6VSGNL/J4la8z4vbqgUd/MTqsBPlhtUKnkZjHT6O87eqAA2eLsf1BJmqkT01HQYJFb9rUMWNRhLl9WuOwt7F3u1ztuuP+4uquQpvPvlK4Uoh0xuozJNTEofM4c/tPGYsGp4/1eKE/bHRpsv5iLgtVb5wEoNe8yONT27c65WmIUY5jlP/318CaGuJ9aJ8bxjnnMIV4Pc5BU2gpLZHFrB9lAilWjuULdNMUKotdlVYOIfA2DfG9aduaJ09KxU5o8xf2eVNyf+lGlF43TkFCtrHCWlQpvfh6pAPsJcpVtuLKs11tKE4yCV+vr6ViM6PCFV6ow2P0Sq7wc5AIIxcuRBwYMgBu9YvecKPe4RamFFuFHyutQoTHTgwgbYzJ8oZ1nl6fSWkfvnczeDPnkM2UpG/UTd3npsEsXAhg+fCPljfvqlTNurM7KTj2kcd3iMeaOySk1gfPY8JuehiSwvIftaLg8sak9BxGXrnVW0Ob0RosCAmAeSxCN/dTdfHqNrrrKnwLonnMS9V16BjDtwJluVWZ9h4u5rFNelKFfU1t3lj9BrXaF6N3OwR50xtoPVB4dpUCrGOd7cSccMMNz/i9WzKvm+6EDLxNPH3BUE/napGvWILa9PyFzCmSx9K71QQ+T7k1P6Vz6ytFs8JTEhaiPPju3xGhoN1kct4pt4c3YkImeVxihVij+E1HaBGRzQPd22lqpfcGnH+eNz9rMm9v87EfGj+eSBOaIi82KKZDiSw1/sfvQK/hapqJPH/L4x214kCIIbsrxO4mxLeGurLT71t2WaP3FROdsQLhLaKbmVoW5HoXF7EwblZ0LIzL0yp1I7XilIIsIcYdekjjepLuivQbQryrcFkdHv9NoxcLxZFzs2+y1q1BkbsGzq3dgmEhqC0zr3tdPejUM34V570/2yxWohsb5Hegral4f/+x/UxVhCUK6WWrFfqJq4XEo95FK7LPIYA8gxQnPoFaXPno3TSRDxELuj+aNL6qKaE0FnoRBYrGXpcAo/fHyOOpu+aNuEXDAfC1nol595zZOfI5L9Ygn0hkyWMf8lAp/tSU8M8aZA2w4HpD6wnBOS+aFLbOY7iETCW4eoO/Qqz+05Es+KVXuZsL05j9BXDOGGIxwQp+NxsHaaGVD5/HwDftyTPVTb27SXazkIqLIRfa532clM2y4fONCAe9I8pWeDl+3tUuSLng8GRQmz0uuOcyeIyN5R06Crx9xSe+WCvseLp0VcJ0yVZhJ3OBqg3yEa7Ra63w2UPTWE4a/jyPvTkeuVbkxENpO4X0USSZK32IcPIAF1H15n1IIzWE0FqjXGXoY4Rl4HvESiFP3p95kIHltvktxPh57CrIndR0vFAPIYaLLF47E1wIpmR0GVLa0AXeNibWdD8sxCcssgBq3FCRt9q7sVSMX4/T1NixtAXDtyGNvyn1kLumoixBbsFFyS5eKnTkO0zP+y5vIRXJtLmQQrFbqVjGzmOasGT+BlBcblmyiULT0e1Nh5G+b2t4ROR/X8REDGFWWpal8cnYI4+vAIWMKV43LWVwTAgiLDp/4NYp3OsFxZDS+wu1TRtknSgYKVtUSej9XSvOk9EUDoD1FKzG5pRX83jbKNSAJ68Mr1+R2j4O2tOuyOLVIpydNkQAGi400r2mS7Zt0hFbmI/DKsURQ+95rMuPX8hjG0OCNdaUzcXCUCGL8wfdItCRVWMovnxamhexZZEQH9pdHNZUiPVY7DeADAGZ3ziBlPH742Q0C+VlwVQvhdsFGmR9epE1yayi9Q5maB7vG3zE6vBR/dwsxDAXC6J6EmNoU9uLN3CMUygWatg0TcF2s9tQu9JpDk2cx5muWZ3kUMjjWhcOZ73J2knUeY8bFUyPiiLv3hkjxIPncWIeo2awFE89CSDxlixFNkAwAuilvoupym4XCObBnemJ+U5We+w38EPQPF6DNsYyeD1m12ZuLN/yGOS3TFHvFAQifU1dyneVZPEiU31/vYFUZuxJs0fZjxzUk5Y83ppr97HzOEMqnXmMmwUYIrO3KHoZkh15c0GyUBvWYKhelrAn0QYZJ/9Sih/SFtPtsXq3SZilNEseE3ITdK8M/+Y5hZ68wkQvWZ/0wEbWUhF8Wbwgk6C8fGZy7RCuquCvj91DFKUrGoeNyEFWS439u3Pjg6dEuqX8wAySLNohj6NjoeIVthgpn6bIktKlMVQ3bqcUZKz7OUBfYWABrcITSgtVBbnmsTVus4a4DO1RqKd5KjadmkM9KAwp6JajgFOrHsI2omG5uAGcVouL3kqDewxFwpu5gLhQ1nkLLx5e0uH7CkOQgXKiq8iJHkMKbpIkm5tRb7bEBYKhNbo1U5f2TYQVkMWn7Ef1EocGFea3cqsSTda5aTUe+s3Dk5d0cWp5bMWCCrJQWshs4KKHus3QZpxl01+4y7kSlX/eyVZR84qjMcp7v3max/XRsywuefjeTfsIluTw6E2qvBn2phrvth5j9xT75fZy/f3H71fvgH6COiio4kpj9yhne+/ebdtCb1yb4/fP9d/gVQInvdSQhe60w5vY/4Pw/QG/zbx1ipVDgYsAfdaKDObgTQ2FRJNM3zs3I6xP3m51Ypn5Pxmcw5JIoceol6wzJtWipNzUY6/OgQsQuFrBWRbczlLez56gbXdhZyKPpVqYd6wI4IgvtT15/LZpcC6WwxY55LHx6m2nl+Kg12FDXioERXbIgp3dUqksh9YCWDepCciJG7IH87i2x4LWLTPzOA/dHyeDhDh1uGohvqYcAGfIeheXwuaJ/bHDbobVa5SFL2ScNt0/Q9OiKi08RMoitm7zbO3g+wn4Af2KDubkO5i+fhSunzoo2XB71orwhdojq+y0eQtd9dGDbAj9K7QczyHC0qL/SoyJwCU/OM1cNzlSrwNIbvZ6zZaP5LfCN4v3kWqXJSxDi7Lbm97DkyfcmHl2B7/0A7v/FCpzk8dTdlZWvNv7nKntgG8OaCeMWwpUvlVWb9WLMjV8gzB9E2IBmDSPtUT9Sq3IJAFMyR89uwqBEkCJZ9SfadwgFqwe2mfY5WnD/tYo2/xRsYpNl6RMYpgE/wK/AoQsm6qDLQsGEU1fNMoptdvTpo2T7libOBu3Jco+W8BPBArU4u0mNAuF54WB5OhI/ecn7v6BvwndIrE0B7pQoFsoBJfKf3zMvGeY28VfBCHITt4ADYGrdRXIzQbzQqvr4WOcm2zGNqQhI/t1SCb9zeW9ywfP3vGhorAyeYZM4kAh2jTGshQRppv8DIoZAqup0Q/U4zxRz5sETq6mw2VIZpXAf39ZU+Oe+lsJWcJt5OJGDNWmXtVwdLzeMEMvcHUwha5fqRUI8kR+Vuzf3IGaPAtzq+8t9rpeQ4/NwpUO5PcgO6Tmb7hS2LVS+HNn/p8/wD+2e4UMZ8gE3DM4Zfm1XrK9CHREUgd3fn0LqRWgO5PVPOGCmtsOxgr8ahPpjdNv9G44NDVroWnKfr7gN04sE/L3uFCiLLntacn/EWJAyyvNOpclCkaqd339LYtN9LAdvx6ncENGvnfIY2uSS1RzYv6mZH+tSyMH10FzBecNCPVMjZwZffNG4tVsz10J7kb/fiKLmb8e5Eion9xCHaVCgOUw9qUAgfbOhu4za+Jac2guVpXxbTDj9zfwY7acfgWvYNuWjcrJEWRCmVBHsqIcgWK/cjjNkRw0kfVu/CvMY4GQ5JzET3P0fscb4+LFavqBNy/z4QvELLhk/b+9q81tY4eBPgt5Ayo3yP3v1NcV50Oyg/59EbQoErsw7IDmUsMhOQTXGdZm37tkkR/89yPAF40ZO96JuS9baN/bZwdn+7wK3UxbFXQ0HnRzCl+BZqxi61Bv+FbLUGlNy0ib9jVMNyRDVDtGNvD8NemjqcM3Z3dQ9agONtojFXUCX2GcPRuzOhyajlPYPoA0pT0TV0emnfuQNcdI2pTf6JUbUKBl3jjfnz13Z5x51fjYN3k7sEBnlq8bakWAFhLhxCRKrB8s/NVDZ3LstQt/GDBuI7ML4Zg6SG5RuuFyUNBpkybjlllY/seiyfjMhLLw/I1GCuYetrz977f9Os3Ayaw6Jfz2GH20LT3zW1aKrM/GP66vQSTxbbF4JNsP5j12CEdflpAUaqhoaXnzY7ks3doqJkAYsvqPGbZF6u+Oxfgiidv+WvqYeh7bhR7KIqwA1bRy7SuoY9EV0ZBOe7is+ZNTr9Gjhu6Flr6u2a50Tl16oS7QjOzOLbScxmN4/I3PkWMbifpYqcJ2HX52qfvjdUaoyI2G20GH8hF0hKd329c+Yo3FDN20nAMSDbZEZ2iTTgtDceEnygRxTjyGMj1Izvmw10TinwQY0HpfVip5c+YnJEtrZPSvTk/UCsN57HSyr4Anz8EVKz/0LCJLVVOnjkgnttPkZXpw65WrrH0TG5AO6JQwFacnzZ/+Bta2+3za66A4vFf4ir8YKsBjgGY2FLsg57VCJag3isfi6JzQX4ByLTYczQ88yY8ZfFXlk5VZjWpwxyDdwK2WdoG2FBKVZkabTeplW5hIY84oDRjWvJ4/5Jh4rKMOMAJNRCWrVwpRceA3wzrvg8UTc84nJQmyc/3/M05EmQSMZdBMOH8zX5Efn1XaM8CMavEsyg+hGyNgGYJlGJnhhUfhwMqGykGeY4vjIxB5hCt+dzzOzZmXEeogdNlY4QAAAlZJREFUYcEQgdUAM/pytCHE9Fb6GuVNgX0wPexSioPoDM5e9mfrow+Jx/lmaURkRuHuvADSyHXUrDYJ5ag3XaJw5KAwsqjVMt3kUEr8dm6zPj6EWoj5cTFIEiEnY4mxn0pOWBjs8P3GHo3F/JwJZGlcxa/XEaGiYKzuX+GN6/g4vEEgLLUGtdD9GXgAZ6aCjoilxa0VbToKkf07wo//7eiW6pW0cDgCPJl8lbFJ0aHPNmohm72UUorguCt4jvY7/3o/3g+8vvUTS2TZ/d0oAT2zmmFvdweuY8LdALowKCU5WkcgyciNc67fAuAaN9dBuCIkaKFX5LoFbmU40CKHJjlA3OKOSXx3gh/rGag8sUKjVaq/PI8PihWLgdtWVnwSaLapBoFo2CspSVuF2AqJl1xnpnhb4MBsgGiLSyIP4isWU5dFkDKMnPJpg7N9i6vTE18D0m7BD7GhKa40xFTPMzMlrPH8fB1kWvPOcum3dGAn7FEut15FqZwQrlgRnjXnh1AxJ+FTwSXZEH1SrWkP06QrVjd8eykzEwMUJUopubkhsICLfRPCZ9zMhe4O+8pP8mMdNNupJ4sTdYjA4VeSkoYLskVBb0+syPAOL6YzjA/dpcRdDzNcvI7zYHfRsmN+DRnMtjHgUDT/JHPWVro+x3g4Sk8VBZel206nXx1UM11xWbrkqbMYXj/147GxGwNwWi8zdHQqcCKW3wuedpSMXtTKPz3P+19c18bXxtfG97o2vja+Nr7XtfG18b2uja+Nr43vdW18bXxtfK9r42vje10bXxufev0BTtRpaFoxtGIAAAAASUVORK5CYII=");
		background-size: 100%;
		background-repeat: no-repeat;
		border-radius: 16rpx;
		.section-hd {
			padding: 26rpx 30rpx 0;
			font-weight: bold;
			font-size: 32rpx;
			line-height: 45rpx;
			color: #333333;
			text {
				color: #999999;
				font-size: 24rpx;
				font-weight: normal;
			}
		}
		.section-bd {
			margin-top: 26rpx;
			.item {
				width: 325rpx;
				padding-bottom: 24rpx;
				margin-left: 20rpx;
			}
			/deep/image, /deep/uni-image, /deep/.easy-loadimage {
				width: 325rpx;
				height: 325rpx;
				border-radius: 16rpx 16rpx 0 0;
			}
			.name {
				margin-top: 10rpx;
				overflow: hidden;
				text-overflow: ellipsis;
				display: -webkit-box;
				-webkit-line-clamp: 2;
				-webkit-box-orient: vertical;
				font-size: 30rpx;
				line-height: 37rpx;
				color: #282828;
			}
			.svip-price {
				margin-top: 6rpx;
				font-size: 28rpx;
				color: #282828;
				font-weight: bold;
				image {
					width: 65rpx;
					height: 28rpx;
					margin-left: 6rpx;
					position:  relative;
					top: 5rpx;
				}
			}
			.shop-price {
				margin-top: 4rpx;
				font-size: 18rpx;
				color: #999999;
			}
		}
	}
</style>
